<?php
/**
 * Apagar dados de teste de um funil: visitas, cliques e conversões num período, para zerar os números
 * depois dos testes e antes de divulgar os links. Etapas e links ficam como estão (anúncio não quebra).
 *
 * Cuidados (a exclusão é definitiva):
 * - Visita do funil ligada a conversão de OUTRO funil (primeiro/último clique) ou com cliques de outro funil
 *   fica, para não estragar a atribuição dele. A prévia mostra quantas ficaram.
 * - Clique usado por conversão que fica (ex.: venda aprovada depois do período) também fica.
 * - Ponteiros do visitante (primeira visita, último toque, última paga) que apontavam para visitas apagadas
 *   são refeitos com as visitas que sobraram; senão a próxima conversão dele sairia sem origem.
 * - Eventos ainda não enviados ao Meta das conversões apagadas são cancelados; os já enviados ficam no log.
 *
 * Só consultas simples (SELECT com JOIN e DELETE/UPDATE por id): rodam no MySQL e no SQLite do Playground.
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_Cleanup
{
    const LOG_OPTION = 'iwt_cleanup_log';
    const LOG_MAX = 30;
    const CHUNK = 500;

    /** Período normalizado: datas locais do site (padrão: do dia em que o funil foi criado até hoje) e limites UTC. */
    public static function range(object $funnel, array $in): array
    {
        $today = wp_date('Y-m-d');
        $created = substr(IWT_Helpers::to_local_iso($funnel->created_at), 0, 10) ?: $today;
        $ok = function ($v) {
            return is_string($v) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $v);
        };
        $from = $ok($in['from'] ?? null) ? $in['from'] : $created;
        $to = $ok($in['to'] ?? null) ? $in['to'] : $today;
        if ($from > $to) {
            [$from, $to] = [$to, $from];
        }
        return [
            'from' => $from,
            'to' => $to,
            'from_utc' => IWT_Helpers::local_date_to_utc($from),
            'to_utc' => IWT_Helpers::local_date_to_utc($to, true),
        ];
    }

    /** O que seria apagado, com os ids. Reaproveitado pela prévia e pela exclusão. */
    private static function scope(int $funnel_id, array $r): array
    {
        global $wpdb;
        $S = IWT_DB::t('sessions');
        $H = IWT_DB::t('hits');
        $C = IWT_DB::t('conversions');
        $O = IWT_DB::t('outbox');
        $a = $r['from_utc'];
        $b = $r['to_utc'];
        // "Fica" = conversão fora do que vai ser apagado (outro funil ou fora do período).
        $kept_conv = "NOT (c.funnel_id = %d AND c.converted_at BETWEEN %s AND %s)";

        $conversions = array_map('intval', $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM $C WHERE funnel_id = %d AND converted_at BETWEEN %s AND %s",
            $funnel_id, $a, $b
        )));

        $sessions = array_map('intval', $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM $S WHERE funnel_id = %d AND started_at BETWEEN %s AND %s",
            $funnel_id, $a, $b
        )));
        $protected = [];
        if ($sessions) {
            $by_conversion = $wpdb->get_col($wpdb->prepare(
                "SELECT DISTINCT s.id FROM $S s JOIN $C c ON (c.first_session_id = s.id OR c.last_session_id = s.id OR c.paid_session_id = s.id)
                 WHERE s.funnel_id = %d AND s.started_at BETWEEN %s AND %s AND $kept_conv",
                $funnel_id, $a, $b, $funnel_id, $a, $b
            ));
            $by_other_funnel = $wpdb->get_col($wpdb->prepare(
                "SELECT DISTINCT s.id FROM $S s JOIN $H h ON h.session_id = s.id
                 WHERE s.funnel_id = %d AND s.started_at BETWEEN %s AND %s AND h.funnel_id <> 0 AND h.funnel_id <> %d",
                $funnel_id, $a, $b, $funnel_id
            ));
            $protected = array_map('intval', array_unique(array_merge($by_conversion, $by_other_funnel)));
        }
        $sessions = array_values(array_diff($sessions, $protected));

        // Cliques do funil no período + páginas vistas/eventos das visitas apagadas (esses têm funnel_id 0).
        $hits = array_map('intval', $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM $H WHERE funnel_id = %d AND created_at BETWEEN %s AND %s",
            $funnel_id, $a, $b
        )));
        foreach (array_chunk($sessions, self::CHUNK) as $chunk) {
            $in = implode(',', array_fill(0, count($chunk), '%d'));
            $hits = array_merge($hits, array_map('intval', $wpdb->get_col($wpdb->prepare(
                "SELECT id FROM $H WHERE session_id IN ($in) AND funnel_id IN (0, %d)",
                array_merge($chunk, [$funnel_id])
            ))));
        }
        $kept_hits = array_map('intval', $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT c.hit_id FROM $C c JOIN $H h ON h.id = c.hit_id
             WHERE h.funnel_id = %d AND h.created_at BETWEEN %s AND %s AND $kept_conv",
            $funnel_id, $a, $b, $funnel_id, $a, $b
        )));
        $hits = array_values(array_diff(array_unique($hits), $kept_hits));

        $clicks = 0;
        foreach (array_chunk($hits, self::CHUNK) as $chunk) {
            $in = implode(',', array_fill(0, count($chunk), '%d'));
            $clicks += (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $H WHERE id IN ($in) AND type = 'click'", $chunk));
        }

        // Eventos do Meta ainda não enviados: das conversões apagadas e os InitiateCheckout dos cliques do período.
        $outbox = array_map('intval', $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM $O WHERE status <> 'sent' AND conversion_id = 0 AND funnel_id = %d AND created_at BETWEEN %s AND %s",
            $funnel_id, $a, $b
        )));
        foreach (array_chunk($conversions, self::CHUNK) as $chunk) {
            $in = implode(',', array_fill(0, count($chunk), '%d'));
            $outbox = array_merge($outbox, array_map('intval', $wpdb->get_col($wpdb->prepare(
                "SELECT id FROM $O WHERE status <> 'sent' AND conversion_id IN ($in)",
                $chunk
            ))));
        }

        return [
            'sessions' => $sessions,
            'hits' => $hits,
            'clicks' => $clicks,
            'conversions' => $conversions,
            'outbox' => array_values(array_unique($outbox)),
            'kept_sessions' => count($protected),
        ];
    }

    private static function counts(array $scope): array
    {
        return [
            'visits' => count($scope['sessions']),
            'clicks' => (int) $scope['clicks'],
            'other_hits' => count($scope['hits']) - (int) $scope['clicks'],
            'conversions' => count($scope['conversions']),
            'outbox' => count($scope['outbox']),
            'kept_visits' => (int) $scope['kept_sessions'],
        ];
    }

    public static function preview(object $funnel, array $in): array
    {
        $r = self::range($funnel, $in);
        $counts = self::counts(self::scope((int) $funnel->id, $r));
        return [
            'from' => $r['from'],
            'to' => $r['to'],
            'counts' => $counts,
            'total' => $counts['visits'] + $counts['clicks'] + $counts['other_hits'] + $counts['conversions'],
            'last' => self::last_for((int) $funnel->id),
        ];
    }

    /** Apaga de verdade. Ordem pensada para que uma interrupção no meio não deixe nada inconsistente para a frente. */
    public static function run(object $funnel, array $in): array
    {
        global $wpdb;
        if (function_exists('set_time_limit')) {
            @set_time_limit(300); // phpcs:ignore WordPress.PHP.NoSilencedErrors
        }
        $r = self::range($funnel, $in);
        $scope = self::scope((int) $funnel->id, $r);
        $counts = self::counts($scope);

        self::delete_ids('outbox', $scope['outbox']);
        self::delete_ids('conversions', $scope['conversions']);
        self::delete_ids('hits', $scope['hits']);

        foreach (array_chunk($scope['sessions'], self::CHUNK) as $chunk) {
            $in_sql = implode(',', array_fill(0, count($chunk), '%d'));
            $visitors = array_map('intval', $wpdb->get_col($wpdb->prepare(
                'SELECT DISTINCT visitor_id FROM ' . IWT_DB::t('sessions') . " WHERE id IN ($in_sql)",
                $chunk
            )));
            self::delete_ids('sessions', $chunk);
            foreach ($visitors as $vid) {
                self::repair_visitor($vid);
            }
        }

        // Os números do roteamento (A/B fixo, distribuição) saem direto dos cliques; o cache do grafo não muda,
        // mas invalidar é barato e garante que nada lido antes da limpeza sobreviva.
        IWT_Funnels::flush_cache();

        $entry = [
            'funnel_id' => (int) $funnel->id,
            'funnel_name' => (string) $funnel->name,
            'user' => wp_get_current_user()->display_name ?: '',
            'at' => IWT_Helpers::now(),
            'from' => $r['from'],
            'to' => $r['to'],
            'counts' => $counts,
        ];
        $log = get_option(self::LOG_OPTION, []);
        $log = is_array($log) ? $log : [];
        array_unshift($log, $entry);
        update_option(self::LOG_OPTION, array_slice($log, 0, self::LOG_MAX), false);

        return ['from' => $r['from'], 'to' => $r['to'], 'counts' => $counts, 'last' => self::export_entry($entry)];
    }

    private static function delete_ids(string $table, array $ids): void
    {
        global $wpdb;
        foreach (array_chunk($ids, self::CHUNK) as $chunk) {
            $in = implode(',', array_fill(0, count($chunk), '%d'));
            $wpdb->query($wpdb->prepare('DELETE FROM ' . IWT_DB::t($table) . " WHERE id IN ($in)", $chunk));
        }
    }

    /** Refaz contagem e ponteiros do visitante que apontavam para visitas que não existem mais. */
    private static function repair_visitor(int $visitor_id): void
    {
        global $wpdb;
        $V = IWT_DB::t('visitors');
        $S = IWT_DB::t('sessions');
        $v = $wpdb->get_row($wpdb->prepare(
            "SELECT current_session_id, first_session_id, last_touch_session_id, paid_session_id FROM $V WHERE id = %d",
            $visitor_id
        ));
        if (!$v) {
            return;
        }
        $agg = $wpdb->get_row($wpdb->prepare(
            "SELECT COUNT(*) AS n, MIN(id) AS first_id, MAX(id) AS last_id,
                    MAX(CASE WHEN channel <> 'direct' THEN id ELSE 0 END) AS touch_id,
                    MAX(CASE WHEN is_paid = 1 THEN id ELSE 0 END) AS paid_id
             FROM $S WHERE visitor_id = %d",
            $visitor_id
        ));
        $pointers = array_filter(array_map('intval', (array) $v));
        $existing = [];
        if ($pointers) {
            $in = implode(',', array_fill(0, count($pointers), '%d'));
            $existing = array_map('intval', $wpdb->get_col($wpdb->prepare("SELECT id FROM $S WHERE id IN ($in)", array_values($pointers))));
        }
        $pick = function (string $col, $fallback) use ($v, $existing) {
            $cur = (int) $v->$col;
            return ($cur && in_array($cur, $existing, true)) ? $cur : (int) $fallback;
        };
        $wpdb->update($V, [
            'sessions' => (int) ($agg->n ?? 0),
            'current_session_id' => $pick('current_session_id', $agg->last_id ?? 0),
            'first_session_id' => $pick('first_session_id', $agg->first_id ?? 0),
            'last_touch_session_id' => $pick('last_touch_session_id', $agg->touch_id ?? 0),
            'paid_session_id' => $pick('paid_session_id', $agg->paid_id ?? 0),
        ], ['id' => $visitor_id]);
    }

    private static function last_for(int $funnel_id): ?array
    {
        foreach ((array) get_option(self::LOG_OPTION, []) as $e) {
            if (is_array($e) && (int) ($e['funnel_id'] ?? 0) === $funnel_id) {
                return self::export_entry($e);
            }
        }
        return null;
    }

    private static function export_entry(array $e): array
    {
        return [
            'at' => IWT_Helpers::to_local_iso((string) ($e['at'] ?? '')),
            'user' => (string) ($e['user'] ?? ''),
            'from' => (string) ($e['from'] ?? ''),
            'to' => (string) ($e['to'] ?? ''),
            'counts' => (array) ($e['counts'] ?? []),
        ];
    }
}
