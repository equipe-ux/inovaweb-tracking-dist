<?php
/**
 * Redirecionamento rápido dos links /go/ (as duas otimizações do Smart Funnel, mais uma):
 *
 *  1. Cache do roteamento: link, etapas, saídas e funil ficam no cache de objetos do WordPress (Redis/Memcached) ou,
 *     sem ele, no APCu do servidor. Chaves com versão: salvar um funil troca a versão e invalida tudo de uma vez.
 *  2. "Desabilitar outros plugins no redirect": um mu-plugin gerado em wp-content/mu-plugins faz o WordPress carregar só
 *     este plugin quando a URL é um link /go/. Criado e removido pela opção em Configurações (e na ativação/desativação).
 *  3. (sempre) O roteador responde em plugins_loaded, antes do tema e das rotinas "init" dos outros plugins.
 *
 * O redirecionamento responde com X-IWT-Fast (1 = só este plugin carregado) e Server-Timing (tempo no servidor).
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_Fast
{
    const MU_FILE = 'iwt-redirecionamento-rapido.php';
    const VERSION_OPTION = 'iwt_routes_ver';
    const CACHE_GROUP = 'iwt_routes';
    const CACHE_TTL = 21600; // 6 h: a versão já invalida a cada alteração; o prazo só limpa sobras
    const ERROR_OPTION = 'iwt_fast_error';

    /** Cache por requisição (vale mesmo sem cache persistente). */
    private static $local = [];
    private static $backend = null;
    private static $prefix = null;

    /* ------------------------------------------------------------------ cache do roteamento */

    /** 'object' (Redis/Memcached do WordPress), 'apcu' ou 'none'. */
    public static function backend(): string
    {
        if (self::$backend === null) {
            if (wp_using_ext_object_cache()) {
                self::$backend = 'object';
            } elseif (function_exists('apcu_fetch') && function_exists('apcu_enabled') && apcu_enabled()) {
                self::$backend = 'apcu';
            } else {
                self::$backend = 'none';
            }
        }
        return self::$backend;
    }

    /**
     * Devolve o valor guardado ou calcula com $load e guarda. null vira "não existe" e também é guardado
     * (robôs testando links inexistentes não vão ao banco toda vez).
     */
    public static function remember(string $key, callable $load)
    {
        $full = self::key($key);
        if (array_key_exists($full, self::$local)) {
            return self::$local[$full];
        }
        $found = false;
        $value = null;
        switch (self::backend()) {
            case 'object':
                $value = wp_cache_get($full, self::CACHE_GROUP, false, $found);
                break;
            case 'apcu':
                $value = apcu_fetch($full, $found);
                break;
        }
        if (!$found) {
            $value = $load();
            $stored = $value === null ? '__none__' : $value;
            if (self::backend() === 'object') {
                wp_cache_set($full, $stored, self::CACHE_GROUP, self::CACHE_TTL);
            } elseif (self::backend() === 'apcu') {
                apcu_store($full, $stored, self::CACHE_TTL);
            }
        } elseif ($value === '__none__') {
            $value = null;
        }
        self::$local[$full] = $value;
        return $value;
    }

    /** Invalida todo o cache do roteamento (funil salvo, pausado, excluído, prefixo trocado…). */
    public static function bump(): void
    {
        update_option(self::VERSION_OPTION, (int) get_option(self::VERSION_OPTION, 0) + 1, true);
        self::$local = [];
        self::$prefix = null;
    }

    private static function key(string $key): string
    {
        if (self::$prefix === null) {
            global $wpdb;
            // APCu é do servidor inteiro: vários WordPress na mesma hospedagem não podem misturar chaves.
            $site = substr(md5(home_url('/') . '|' . $wpdb->prefix), 0, 10);
            self::$prefix = 'iwt:' . $site . ':' . (int) get_option(self::VERSION_OPTION, 0) . ':';
        }
        return self::$prefix . $key;
    }

    /* ------------------------------------------------------------------ mu-plugin "só este plugin no redirect" */

    public static function mu_path(): string
    {
        return trailingslashit(WPMU_PLUGIN_DIR) . self::MU_FILE;
    }

    /** Cria, atualiza ou remove o mu-plugin conforme a opção. Chamado ao salvar, ativar, atualizar e abrir o painel. */
    public static function sync(): void
    {
        $path = self::mu_path();
        if (!IWT_Settings::get('fast_redirect')) {
            self::remove();
            return;
        }
        $code = self::mu_code();
        if (is_readable($path) && (string) file_get_contents($path) === $code) {
            delete_option(self::ERROR_OPTION);
            return;
        }
        if (!is_dir(WPMU_PLUGIN_DIR)) {
            wp_mkdir_p(WPMU_PLUGIN_DIR);
        }
        $ok = is_dir(WPMU_PLUGIN_DIR) && is_writable(WPMU_PLUGIN_DIR) && @file_put_contents($path, $code, LOCK_EX) !== false; // phpcs:ignore
        if ($ok) {
            delete_option(self::ERROR_OPTION);
        } else {
            update_option(self::ERROR_OPTION, 'Não foi possível gravar ' . self::relative($path) . '. Peça à hospedagem permissão de escrita na pasta wp-content/mu-plugins.', false);
        }
    }

    public static function remove(): void
    {
        $path = self::mu_path();
        if (file_exists($path)) {
            @unlink($path); // phpcs:ignore
        }
        delete_option(self::ERROR_OPTION);
    }

    /** Situação para Configurações e Diagnóstico. */
    public static function status(): array
    {
        $path = self::mu_path();
        $exists = is_readable($path);
        $current = $exists && (string) file_get_contents($path) === self::mu_code();
        $labels = [
            'object' => 'Cache de objetos do WordPress (Redis/Memcached): o link é resolvido sem consultar o banco.',
            'apcu' => 'APCu do servidor: o link é resolvido sem consultar o banco.',
            'none' => 'Sem cache persistente no servidor: cada clique consulta o banco (continua rápido). Para o máximo, peça à hospedagem Redis, Memcached ou APCu.',
        ];
        return [
            'enabled' => (bool) IWT_Settings::get('fast_redirect'),
            'installed' => $exists,
            'current' => $current,
            'file' => self::relative($path),
            'error' => (string) get_option(self::ERROR_OPTION, ''),
            'cache' => self::backend(),
            'cache_label' => $labels[self::backend()],
        ];
    }

    private static function relative(string $path): string
    {
        return ltrim(str_replace(wp_normalize_path(ABSPATH), '', wp_normalize_path($path)), '/');
    }

    /** Código do mu-plugin. O caminho dos links e o arquivo do plugin vão embutidos (o mu-plugin roda antes de tudo). */
    private static function mu_code(): string
    {
        $home_path = rtrim((string) wp_parse_url(home_url('/'), PHP_URL_PATH), '/');
        $base = $home_path . '/' . IWT_Settings::route_prefix() . '/';
        $plugin = plugin_basename(IWT_FILE);
        return '<?php
/**
 * Plugin Name: INOVAWEB Tracking — redirecionamento rápido
 * Description: Nos links rastreáveis (' . $base . '…) o WordPress carrega só o INOVAWEB Tracking. Criado e removido pelo próprio plugin (Tracking → Configurações → Links e redirecionamento). Não edite: é refeito a cada atualização.
 * Version: ' . IWT_VERSION . '
 */

if (!defined(\'ABSPATH\')) {
    exit;
}

(function () {
    $base = ' . var_export($base, true) . ';
    $plugin = ' . var_export($plugin, true) . ';
    $uri = isset($_SERVER[\'REQUEST_URI\']) ? (string) $_SERVER[\'REQUEST_URI\'] : \'\';
    $path = (string) parse_url($uri, PHP_URL_PATH);
    $is_link = stripos($path, $base) === 0 && trim(substr($path, strlen($base)), \'/\') !== \'\';
    if (!$is_link && isset($_GET[\'iwt_go\']) && stripos($path, \'/wp-admin\') === false && stripos($path, \'/wp-json\') === false) {
        $is_link = true;
    }
    if (!$is_link || (defined(\'WP_CLI\') && WP_CLI) || (defined(\'DOING_CRON\') && DOING_CRON)) {
        return;
    }
    define(\'IWT_FAST_REDIRECT\', true);
    // Só remove os outros se o INOVAWEB Tracking estiver ativo (desativado, nada muda).
    add_filter(\'option_active_plugins\', function ($plugins) use ($plugin) {
        return is_array($plugins) && in_array($plugin, $plugins, true) ? [$plugin] : $plugins;
    }, PHP_INT_MAX);
    add_filter(\'site_option_active_sitewide_plugins\', function ($plugins) use ($plugin) {
        if (!is_array($plugins)) {
            return $plugins;
        }
        return isset($plugins[$plugin]) ? [$plugin => $plugins[$plugin]] : [];
    }, PHP_INT_MAX);
})();
';
    }

    /* ------------------------------------------------------------------ teste de velocidade */

    /**
     * Mede o redirecionamento chamando um link do próprio site 3 vezes com ?iwt_test=1 (não registra nada).
     * Tempo no servidor vem do cabeçalho Server-Timing; o total inclui a rede entre o servidor e ele mesmo.
     */
    public static function speed_test(): array
    {
        global $wpdb;
        $key = (string) $wpdb->get_var(
            'SELECT l.id FROM ' . IWT_DB::t('links') . ' l JOIN ' . IWT_DB::t('funnels') . " f ON f.id = l.funnel_id
             WHERE l.deleted = 0 AND f.status = 'active' AND f.deleted_at IS NULL ORDER BY l.id DESC LIMIT 1"
        );
        $url = add_query_arg('iwt_test', '1', IWT_Funnels::link_url((object) ['id' => $key !== '' ? (int) $key : 0, 'alias' => $key !== '' ? '' : 'teste-de-velocidade']));
        $runs = [];
        for ($i = 0; $i < 3; $i++) {
            $t = microtime(true);
            $res = wp_remote_get($url, ['redirection' => 0, 'timeout' => 15, 'sslverify' => false, 'headers' => ['Cache-Control' => 'no-cache']]);
            $total = (microtime(true) - $t) * 1000;
            if (is_wp_error($res)) {
                return ['ok' => false, 'error' => 'O servidor não conseguiu chamar o próprio site (' . $res->get_error_message() . '). Teste um link no navegador.', 'url' => $url];
            }
            $timing = (string) wp_remote_retrieve_header($res, 'server-timing');
            $server = preg_match('/dur=([0-9.]+)/', $timing, $m) ? (float) $m[1] : null;
            $runs[] = [
                'status' => (int) wp_remote_retrieve_response_code($res),
                'total_ms' => round($total),
                'server_ms' => $server !== null ? round($server) : null,
                'fast' => wp_remote_retrieve_header($res, 'x-iwt-fast') === '1',
            ];
        }
        $median = function (array $values) {
            $values = array_values(array_filter($values, 'is_numeric'));
            if (!$values) {
                return null;
            }
            sort($values);
            return $values[(int) floor(count($values) / 2)];
        };
        $redirected = count(array_filter($runs, function ($r) {
            return $r['status'] >= 300 && $r['status'] < 400;
        })) === count($runs);
        return [
            'ok' => $redirected,
            'error' => $redirected ? '' : 'O link não redirecionou (HTTP ' . $runs[0]['status'] . '). Um plugin de segurança ou de cache pode estar interferindo em /' . IWT_Settings::route_prefix() . '/.',
            'url' => $url,
            'runs' => $runs,
            'server_ms' => $median(array_column($runs, 'server_ms')),
            'total_ms' => $median(array_column($runs, 'total_ms')),
            'fast' => $runs[count($runs) - 1]['fast'],
            'cache' => self::backend(),
        ];
    }
}
