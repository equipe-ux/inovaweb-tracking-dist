<?php
/**
 * Desinstalação (Plugins → Excluir). Por padrão PRESERVA os dados: só apaga tabelas e configurações
 * se "Apagar todos os dados ao excluir o plugin" estiver marcado em Configurações.
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

require_once __DIR__ . '/includes/class-iwt-helpers.php';
require_once __DIR__ . '/includes/class-iwt-db.php';

wp_clear_scheduled_hook('iwt_cron_hourly');
wp_clear_scheduled_hook('iwt_cron_daily');

foreach (wp_roles()->role_objects as $role) {
    $role->remove_cap('iwt_view');
    $role->remove_cap('iwt_manage');
}

$settings = get_option('iwt_settings', []);
if (is_array($settings) && !empty($settings['delete_on_uninstall'])) {
    IWT_DB::drop_all();
    delete_option('iwt_settings');
    delete_transient('iwt_thankyou_targets');
    delete_transient('iwt_page_targets');
    delete_site_transient('iwt_update_manifest');
    delete_option('iwt_update_check');
    delete_option('iwt_endpoints');
    delete_metadata('user', 0, 'iwt_theme', '', true);
}
