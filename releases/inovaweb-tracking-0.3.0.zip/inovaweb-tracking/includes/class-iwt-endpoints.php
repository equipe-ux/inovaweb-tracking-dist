<?php
/**
 * Endpoints de dados para dashboards (painel da agência).
 *
 * Cada endpoint é um link com chave própria, limitado a um funil e/ou a uma campanha (utm_campaign):
 *
 *   GET /wp-json/inovaweb-tracking/v1/data/{chave}?days=7
 *
 * Devolve em JSON os números daquele escopo, calculados na hora (cache de 15 s para aguentar várias telas abertas):
 * visitantes online, hoje, totais com comparação, série diária, quebras, etapas do funil, testes A/B e últimas conversões.
 * Somente leitura e sem dados pessoais. O escopo é do endpoint e não pode ser ampliado pela URL: filtros extras só estreitam.
 * Contrato completo em docs/API-DASHBOARD.md.
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_Endpoints
{
    const OPTION = 'iwt_endpoints';
    const CACHE_SECONDS = 15;
    const SECTIONS = ['live', 'totals', 'series', 'breakdowns', 'funnel', 'conversions'];
    const DEFAULT_DIMENSIONS = ['channel', 'temperature', 'source_node', 'campaign', 'content', 'term', 'device'];

    public static function register_routes(): void
    {
        register_rest_route(IWT_REST_NS, '/data/(?P<key>[A-Za-z0-9]{16,64})', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'serve'],
            'permission_callback' => '__return_true', // a chave do endpoint é conferida dentro do handler
        ]);
    }

    /* ------------------------------------------------------------------ cadastro */

    /** @return array<string,array> por id */
    public static function all(): array
    {
        $list = get_option(self::OPTION, []);
        return is_array($list) ? $list : [];
    }

    private static function save(array $list): void
    {
        update_option(self::OPTION, $list, false);
    }

    public static function get(string $id): ?array
    {
        $list = self::all();
        return $list[$id] ?? null;
    }

    /** @return array|string endpoint criado ou mensagem de erro */
    public static function create(array $in)
    {
        $clean = self::sanitize($in);
        if (is_string($clean)) {
            return $clean;
        }
        $list = self::all();
        do {
            $id = 'ep' . IWT_Helpers::random_key(10);
        } while (isset($list[$id]));
        $list[$id] = $clean + ['id' => $id, 'key' => IWT_Helpers::random_key(32), 'created_at' => IWT_Helpers::now(), 'last_used_at' => ''];
        self::save($list);
        return $list[$id];
    }

    /** Muda nome/escopo (a chave e o link continuam os mesmos). @return array|string */
    public static function update(string $id, array $in)
    {
        $list = self::all();
        if (!isset($list[$id])) {
            return 'Endpoint não encontrado.';
        }
        $clean = self::sanitize($in + $list[$id]);
        if (is_string($clean)) {
            return $clean;
        }
        $list[$id] = array_merge($list[$id], $clean);
        self::save($list);
        return $list[$id];
    }

    /** Troca a chave: o link antigo para de funcionar na hora. */
    public static function rotate(string $id): ?array
    {
        $list = self::all();
        if (!isset($list[$id])) {
            return null;
        }
        $list[$id]['key'] = IWT_Helpers::random_key(32);
        self::save($list);
        return $list[$id];
    }

    public static function delete(string $id): bool
    {
        $list = self::all();
        if (!isset($list[$id])) {
            return false;
        }
        unset($list[$id]);
        self::save($list);
        return true;
    }

    /** @return array|string */
    private static function sanitize(array $in)
    {
        $name = trim(sanitize_text_field((string) ($in['name'] ?? '')));
        $funnel = max(0, (int) ($in['funnel'] ?? 0));
        $campaign = trim(sanitize_text_field((string) ($in['campaign'] ?? '')));
        if ($funnel && !IWT_Funnels::get($funnel)) {
            return 'Funil não encontrado.';
        }
        if ($name === '') {
            $f = $funnel ? IWT_Funnels::get($funnel) : null;
            $name = trim(($f ? $f->name : 'Site inteiro') . ($campaign !== '' ? ' — ' . $campaign : ''));
        }
        return [
            'name' => function_exists('mb_substr') ? mb_substr($name, 0, 120) : substr($name, 0, 120),
            'funnel' => $funnel,
            'campaign' => substr($campaign, 0, 191),
        ];
    }

    public static function find_by_key(string $key): ?array
    {
        if ($key === '') {
            return null;
        }
        foreach (self::all() as $ep) {
            if (isset($ep['key']) && hash_equals((string) $ep['key'], $key)) {
                return $ep;
            }
        }
        return null;
    }

    public static function url(array $ep): string
    {
        return rest_url(IWT_REST_NS . '/data/' . $ep['key']);
    }

    /** Lista para o painel (o link aparece inteiro: quem gerencia precisa copiá-lo de novo). */
    public static function for_admin(): array
    {
        $out = [];
        foreach (self::all() as $ep) {
            $f = $ep['funnel'] ? IWT_Funnels::get((int) $ep['funnel']) : null;
            $out[] = [
                'id' => $ep['id'],
                'name' => $ep['name'],
                'funnel' => (int) $ep['funnel'],
                'funnel_name' => $f ? (string) $f->name : ($ep['funnel'] ? 'Funil removido' : ''),
                'campaign' => (string) $ep['campaign'],
                'url' => self::url($ep),
                'created_at' => IWT_Helpers::to_local_iso($ep['created_at']),
                'last_used_at' => $ep['last_used_at'] ? IWT_Helpers::to_local_iso($ep['last_used_at']) : '',
            ];
        }
        usort($out, function ($a, $b) {
            return strcmp($b['created_at'], $a['created_at']);
        });
        return $out;
    }

    /* ------------------------------------------------------------------ leitura */

    public static function serve(WP_REST_Request $r): WP_REST_Response
    {
        $ep = self::find_by_key((string) $r['key']);
        if (!$ep) {
            return self::response(['ok' => false, 'error' => 'Endpoint não encontrado. A chave pode ter sido trocada ou o endpoint excluído.'], 404);
        }
        if ($ep['funnel']) {
            $f = IWT_Funnels::get((int) $ep['funnel']);
            if (!$f || !empty($f->deleted_at)) {
                return self::response(['ok' => false, 'error' => 'O funil deste endpoint foi excluído.'], 410);
            }
        }
        $q = $r->get_query_params();

        // Período: from/to (AAAA-MM-DD, horário do site) ou days (últimos N dias, contando hoje). Padrão: 30 dias.
        $in = [];
        foreach (['from', 'to', 'model'] as $k) {
            if (isset($q[$k]) && is_scalar($q[$k])) {
                $in[$k] = (string) $q[$k];
            }
        }
        if (!isset($in['from']) && isset($q['days']) && is_scalar($q['days'])) {
            $days = max(1, min(366, (int) $q['days']));
            $in['from'] = wp_date('Y-m-d', time() - ($days - 1) * DAY_IN_SECONDS);
            $in['to'] = wp_date('Y-m-d');
        }
        // Filtros extras da URL só estreitam; o escopo do endpoint sempre vence.
        foreach (IWT_Reports::FILTERS as $f) {
            if (isset($q[$f]) && is_scalar($q[$f]) && $q[$f] !== '') {
                $in[$f] = (string) $q[$f];
            }
        }
        if ($ep['funnel']) {
            $in['funnel'] = (string) $ep['funnel'];
        }
        if ($ep['campaign'] !== '') {
            $in['campaign'] = $ep['campaign'];
        }

        $sections = self::SECTIONS;
        if (isset($q['sections']) && is_scalar($q['sections'])) {
            $sections = array_values(array_intersect(self::SECTIONS, array_map('trim', explode(',', strtolower((string) $q['sections'])))));
        }
        $dims = self::DEFAULT_DIMENSIONS;
        if (isset($q['dimensions']) && is_scalar($q['dimensions'])) {
            $dims = array_slice(array_values(array_intersect(array_map('trim', explode(',', (string) $q['dimensions'])), array_keys(IWT_Reports::dimensions()))), 0, 12);
        }
        $limit = isset($q['limit']) ? max(1, min(100, (int) $q['limit'])) : 10;
        $conv_limit = isset($q['conversions']) ? max(1, min(100, (int) $q['conversions'])) : 20;

        self::touch($ep);
        $cache_key = 'iwt_ep_' . md5($ep['id'] . '|' . $ep['key'] . '|' . wp_json_encode([$in, $sections, $dims, $limit, $conv_limit, wp_date('Y-m-d')]));
        $cached = get_transient($cache_key);
        if (is_array($cached)) {
            return self::response($cached, 200, 'hit');
        }
        $data = self::build($ep, $in, $sections, $dims, $limit, $conv_limit);
        set_transient($cache_key, $data, self::CACHE_SECONDS);
        return self::response($data, 200, 'miss');
    }

    private static function build(array $ep, array $in, array $sections, array $dims, int $limit, int $conv_limit): array
    {
        $a = IWT_Reports::args($in);
        $funnel = $ep['funnel'] ? IWT_Funnels::get((int) $ep['funnel']) : null;
        $currency = $funnel && !empty($funnel->currency) ? (string) $funnel->currency : (string) IWT_Settings::get('currency');
        $out = [
            'ok' => true,
            'endpoint' => [
                'name' => $ep['name'],
                'funnel' => $funnel ? ['id' => (int) $funnel->id, 'name' => (string) $funnel->name, 'goal' => (string) $funnel->goal, 'status' => (string) $funnel->status] : null,
                'campaign' => $ep['campaign'] !== '' ? $ep['campaign'] : null,
            ],
            'generated_at' => IWT_Helpers::to_local_iso(IWT_Helpers::now()),
            'timezone' => wp_timezone_string(),
            'currency' => $currency,
            'range' => ['from' => $a['from'], 'to' => $a['to'], 'days' => $a['days']],
            'filters' => $a['filters'],
            'model' => $a['model'],
        ];
        if (in_array('live', $sections, true)) {
            $today = wp_date('Y-m-d');
            $out['live'] = [
                'active_visitors' => IWT_Reports::active_visitors($a['filters'], 5),
                'window_minutes' => 5,
                'today' => IWT_Reports::totals(IWT_Reports::args(['from' => $today, 'to' => $today, 'model' => $a['model']] + $a['filters'])),
            ];
        }
        if (in_array('totals', $sections, true)) {
            $ov = IWT_Reports::overview($a);
            $prev = IWT_Reports::previous($a);
            $out['totals'] = $ov['current'];
            $out['previous'] = $ov['previous'];
            $out['previous_range'] = ['from' => $prev['from'], 'to' => $prev['to'], 'days' => $prev['days']];
        }
        if (in_array('series', $sections, true)) {
            $out['series'] = IWT_Reports::timeseries($a);
        }
        if (in_array('breakdowns', $sections, true)) {
            $out['breakdowns'] = [];
            foreach ($dims as $d) {
                $out['breakdowns'][$d] = IWT_Reports::breakdown($d, $a, $limit);
            }
        }
        if (in_array('funnel', $sections, true) && isset($a['filters']['funnel'])) {
            $out['funnel'] = IWT_Reports::funnel_flow((int) $a['filters']['funnel'], $a);
        }
        if (in_array('conversions', $sections, true)) {
            $list = IWT_Reports::conversions_list($a, ['per_page' => 100]);
            $out['latest_conversions'] = array_map(function ($c) {
                unset($c['customer_name'], $c['customer_email'], $c['customer_phone'], $c['visitor_id']);
                return $c;
            }, array_slice($list['items'], 0, $conv_limit));
        }
        return $out;
    }

    /** Guarda o último acesso (no máximo a cada 5 min: o painel pode chamar a cada poucos segundos). */
    private static function touch(array $ep): void
    {
        $last = $ep['last_used_at'] ? strtotime($ep['last_used_at'] . ' UTC') : 0;
        if (time() - $last < 300) {
            return;
        }
        $list = self::all();
        if (isset($list[$ep['id']])) {
            $list[$ep['id']]['last_used_at'] = IWT_Helpers::now();
            self::save($list);
        }
    }

    private static function response(array $data, int $status, string $cache = ''): WP_REST_Response
    {
        $res = new WP_REST_Response($data, $status);
        $res->header('Cache-Control', 'no-store, max-age=0');
        $res->header('X-Robots-Tag', 'noindex');
        if ($cache !== '') {
            $res->header('X-IWT-Cache', $cache);
        }
        return $res;
    }
}
