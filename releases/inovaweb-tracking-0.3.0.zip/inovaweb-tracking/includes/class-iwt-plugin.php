<?php
/**
 * Inicialização: registra hooks de todos os módulos, ativação/desativação e capabilities.
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_Plugin
{
    const CAP_VIEW = 'iwt_view';     // ver relatórios
    const CAP_MANAGE = 'iwt_manage'; // criar funis, integrações, configurações

    public static function boot(): void
    {
        add_action('plugins_loaded', [__CLASS__, 'loaded'], 5);
        add_action('rest_api_init', [__CLASS__, 'register_rest']);
        add_action('wp_enqueue_scripts', ['IWT_Collector', 'enqueue']);

        IWT_Router::init();
        IWT_Collector::init();
        IWT_Cron::init();
        IWT_Meta_CAPI::init();
        IWT_Updater::init();
        add_action('plugins_loaded', ['IWT_WooCommerce', 'init'], 20);

        if (is_admin()) {
            IWT_Admin::init();
        }
    }

    public static function loaded(): void
    {
        // Atualização por zip/atualizador não dispara o hook de ativação: refaz aqui o que a ativação faria.
        if (IWT_DB::maybe_upgrade()) {
            self::sync_capabilities();
            IWT_Cron::schedule();
        }
    }

    public static function register_rest(): void
    {
        IWT_Collector::register_routes();
        IWT_Webhooks::register_routes();
        IWT_Admin_API::register_routes();
        IWT_Public_API::register_routes();
        IWT_Endpoints::register_routes();
    }

    public static function activate(): void
    {
        IWT_DB::install();
        IWT_Settings::all(); // gera a chave dos webhooks
        self::sync_capabilities();
        IWT_Cron::schedule();
    }

    public static function deactivate(): void
    {
        IWT_Cron::unschedule();
    }

    /** Administrador sempre pode tudo; papéis marcados em Configurações podem ver relatórios. */
    public static function sync_capabilities(): void
    {
        $view_roles = (array) IWT_Settings::get('view_roles');
        foreach (wp_roles()->role_objects as $key => $role) {
            if ($key === 'administrator') {
                $role->add_cap(self::CAP_VIEW);
                $role->add_cap(self::CAP_MANAGE);
                continue;
            }
            if (in_array($key, $view_roles, true)) {
                $role->add_cap(self::CAP_VIEW);
            } else {
                $role->remove_cap(self::CAP_VIEW);
            }
        }
    }
}
