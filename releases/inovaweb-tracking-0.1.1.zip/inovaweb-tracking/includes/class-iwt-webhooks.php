<?php
/**
 * Recebimento de vendas por webhook: POST /wp-json/inovaweb-tracking/v1/webhook/{plataforma}?key={chave}
 *
 * Autenticação (diferente do Smart Funnel, que aceitava qualquer postback):
 *  - sempre: ?key= igual à chave do site (Integrações → "Chave dos webhooks");
 *  - Hotmart: se o hottok estiver configurado, o cabeçalho X-HOTMART-HOTTOK precisa bater;
 *  - Kiwify: se o token estiver configurado, ?signature= precisa ser o HMAC-SHA1 do corpo.
 * Todo webhook recebido vai para o log (Integrações → Log de webhooks), inclusive os recusados.
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_Webhooks
{
    public static function register_routes(): void
    {
        register_rest_route(IWT_REST_NS, '/webhook/(?P<platform>[a-z0-9_]+)', [
            'methods' => ['POST', 'GET'],
            'callback' => [__CLASS__, 'handle'],
            'permission_callback' => '__return_true', // autenticação feita dentro do handler (chave + assinatura)
        ]);
    }

    public static function url(string $platform): string
    {
        return add_query_arg('key', IWT_Settings::get('webhook_key'), rest_url(IWT_REST_NS . '/webhook/' . $platform));
    }

    public static function handle(WP_REST_Request $request)
    {
        $platform = sanitize_key((string) $request['platform']);
        $preset = IWT_Platforms::get($platform);
        $raw = (string) $request->get_body();
        $payload = self::parse_payload($request, $raw);

        if (!$preset || !empty($preset['internal'])) {
            self::log($platform, 'error', 'Plataforma desconhecida.', 0, $raw);
            return new WP_REST_Response(['ok' => false, 'error' => 'unknown_platform'], 404);
        }

        $key = (string) $request->get_param('key');
        if ($key === '' || !hash_equals((string) IWT_Settings::get('webhook_key'), $key)) {
            self::log($platform, 'unauthorized', 'Chave do webhook ausente ou inválida.', 0, $raw);
            return new WP_REST_Response(['ok' => false, 'error' => 'unauthorized'], 401);
        }
        $auth_error = self::verify_platform($platform, $request, $raw, $payload);
        if ($auth_error !== '') {
            self::log($platform, 'unauthorized', $auth_error, 0, $raw);
            return new WP_REST_Response(['ok' => false, 'error' => 'unauthorized'], 401);
        }
        if (!$payload) {
            self::log($platform, 'ignored', 'Corpo vazio ou em formato não reconhecido (teste de conexão?).', 0, $raw);
            return new WP_REST_Response(['ok' => true, 'ignored' => true], 200);
        }

        $n = IWT_Platforms::normalize($platform, $payload);
        if (!$n || $n['status'] === '') {
            $raw_status = $n['raw_status'] ?? '';
            self::log($platform, 'ignored', 'Evento sem status de venda reconhecido' . ($raw_status !== '' ? " ($raw_status)" : '') . '.', 0, $raw);
            return new WP_REST_Response(['ok' => true, 'ignored' => true], 200);
        }

        $match = IWT_Conversions::match($n['token'], IWT_Helpers::hash_email($n['email']), (string) $n['product_id']);
        $result = IWT_Conversions::upsert_sale($platform, $n, $match);
        if (!$result['id']) {
            self::log($platform, 'error', 'Falha ao gravar a conversão no banco.', 0, $raw);
            return new WP_REST_Response(['ok' => false, 'error' => 'db_error'], 500);
        }

        self::log($platform, 'ok', self::describe($n, $match, $result), $result['id'], $raw);
        return new WP_REST_Response(['ok' => true, 'conversion_id' => $result['id'], 'status' => $result['status']], 200);
    }

    public static function parse_payload(WP_REST_Request $request, string $raw): array
    {
        $payload = [];
        $trim = ltrim($raw);
        if ($trim !== '' && ($trim[0] === '{' || $trim[0] === '[')) {
            $payload = json_decode($trim, true);
            $payload = is_array($payload) ? $payload : [];
        } elseif ($raw !== '') {
            parse_str($raw, $payload);
            // Postbacks antigos mandam JSON dentro de um campo de formulário.
            foreach ($payload as $k => $v) {
                if (is_string($v) && strlen($v) > 1 && ($v[0] === '{' || $v[0] === '[')) {
                    $decoded = json_decode(wp_unslash($v), true);
                    if (is_array($decoded)) {
                        $payload[$k] = $decoded;
                    }
                }
            }
        }
        if (!$payload) {
            // GET ou formulário já interpretado pelo WP.
            $payload = (array) $request->get_body_params() ?: (array) $request->get_query_params();
        }
        unset($payload['key'], $payload['signature']);
        return $payload;
    }

    /** @return string mensagem de erro, ou '' quando autenticado. */
    public static function verify_platform(string $platform, WP_REST_Request $request, string $raw, array $payload): string
    {
        if ($platform === 'hotmart') {
            $expected = (string) IWT_Settings::get('hotmart_hottok');
            if ($expected !== '') {
                $got = (string) ($request->get_header('x_hotmart_hottok') ?: ($payload['hottok'] ?? ''));
                if ($got === '' || !hash_equals($expected, $got)) {
                    return 'Hottok da Hotmart não confere.';
                }
            }
        }
        if ($platform === 'kiwify') {
            $token = (string) IWT_Settings::get('kiwify_token');
            if ($token !== '') {
                $sig = (string) $request->get_param('signature');
                if ($sig === '' || !hash_equals(hash_hmac('sha1', $raw, $token), strtolower($sig))) {
                    return 'Assinatura da Kiwify não confere.';
                }
            }
        }
        return '';
    }

    private static function describe(array $n, array $match, array $result): string
    {
        $statuses = IWT_Conversions::statuses();
        $status = $statuses[$result['status']] ?? $result['status'];
        $parts = [];
        $old = $statuses[$result['old_status']] ?? $result['old_status'];
        $parts[] = $result['created'] ? 'Nova conversão' : ('Atualizada' . ($result['old_status'] !== $result['status'] ? " ($old → $status)" : ''));
        $parts[] = $status;
        if ($n['value'] > 0) {
            $parts[] = number_format_i18n($n['value'], 2) . ' ' . ($n['currency'] ?: IWT_Settings::get('currency'));
        }
        $methods = ['hit' => 'atribuída pelo clique no checkout', 'visitor' => 'atribuída pelo visitante', 'email' => 'atribuída pelo e-mail', 'product' => 'funil pelo produto, sem visitante', 'none' => 'sem atribuição (o código de rastreio não veio no webhook)'];
        $parts[] = $methods[$match['method']] ?? $match['method'];
        return IWT_Helpers::truncate(implode(' · ', $parts), 255);
    }

    public static function log(string $platform, string $status, string $message, int $conversion_id, string $raw): void
    {
        global $wpdb;
        $wpdb->insert(IWT_DB::t('webhook_logs'), [
            'created_at' => IWT_Helpers::now(),
            'platform' => IWT_Helpers::truncate($platform, 32),
            'status' => $status,
            'message' => IWT_Helpers::truncate($message, 255),
            'conversion_id' => $conversion_id,
            'payload' => IWT_Helpers::truncate($raw, 60000),
        ]);
    }
}
