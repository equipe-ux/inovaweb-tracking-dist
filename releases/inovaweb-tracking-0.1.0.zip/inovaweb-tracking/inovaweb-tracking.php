<?php
/**
 * Plugin Name: INOVAWEB Tracking
 * Plugin URI:  https://github.com/equipe-ux/inovaweb-tracking-dist
 * Description: Rastreamento de visitas, fontes de tráfego, funis por redirecionamento e conversões (checkout, página de obrigado e WhatsApp), com envio para a API de Conversões do Meta.
 * Version:     0.1.0
 * Requires at least: 5.9
 * Requires PHP: 7.4
 * Tested up to: 7.1
 * Author:      Inova Web Design
 * Author URI:  https://inovawebdesign.com.br
 * License:     GPLv2 or later
 * Text Domain: inovaweb-tracking
 * Update URI:  https://raw.githubusercontent.com/equipe-ux/inovaweb-tracking-dist/main/update.json
 */

if (!defined('ABSPATH')) {
    exit;
}

// Versão em DOIS lugares: no header acima e nesta constante. O CI barra a Release se divergirem.
define('IWT_VERSION', '0.1.0');
define('IWT_FILE', __FILE__);
define('IWT_DIR', plugin_dir_path(__FILE__));
define('IWT_URL', plugin_dir_url(__FILE__));
define('IWT_SLUG', 'inovaweb-tracking');
define('IWT_REST_NS', 'inovaweb-tracking/v1');

require_once IWT_DIR . 'includes/class-iwt-helpers.php';
require_once IWT_DIR . 'includes/class-iwt-db.php';
require_once IWT_DIR . 'includes/class-iwt-settings.php';
require_once IWT_DIR . 'includes/class-iwt-request.php';
require_once IWT_DIR . 'includes/class-iwt-sources.php';
require_once IWT_DIR . 'includes/class-iwt-visitors.php';
require_once IWT_DIR . 'includes/class-iwt-funnels.php';
require_once IWT_DIR . 'includes/class-iwt-router.php';
require_once IWT_DIR . 'includes/class-iwt-collector.php';
require_once IWT_DIR . 'includes/class-iwt-conversions.php';
require_once IWT_DIR . 'includes/class-iwt-platforms.php';
require_once IWT_DIR . 'includes/class-iwt-webhooks.php';
require_once IWT_DIR . 'includes/class-iwt-woocommerce.php';
require_once IWT_DIR . 'includes/class-iwt-meta-capi.php';
require_once IWT_DIR . 'includes/class-iwt-reports.php';
require_once IWT_DIR . 'includes/class-iwt-admin-api.php';
require_once IWT_DIR . 'includes/class-iwt-public-api.php';
require_once IWT_DIR . 'includes/class-iwt-admin.php';
require_once IWT_DIR . 'includes/class-iwt-cron.php';
require_once IWT_DIR . 'includes/class-iwt-updater.php';
require_once IWT_DIR . 'includes/class-iwt-plugin.php';

register_activation_hook(__FILE__, ['IWT_Plugin', 'activate']);
register_deactivation_hook(__FILE__, ['IWT_Plugin', 'deactivate']);

IWT_Plugin::boot();
