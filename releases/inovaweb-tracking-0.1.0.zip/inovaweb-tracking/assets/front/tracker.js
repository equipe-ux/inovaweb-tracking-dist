/*!
 * INOVAWEB Tracking — script de rastreamento das páginas.
 * Registra a visita (com UTMs e referenciador), cliques em WhatsApp/telefone/e-mail/checkout e
 * marca os links de checkout (Hotmart, Kiwify, Eduzz…) com o código do visitante para a venda
 * voltar atribuída no webhook. Sem dependências. Configuração em window.IWT_CONFIG.
 *
 * API pública: window.iwtTracking.consent()  → libera o rastreamento (modo consentimento)
 *              window.iwtTracking.event(nome) → evento personalizado
 *              window.iwtTracking.vid()       → ID do visitante
 */
(function () {
  'use strict';

  var C = window.IWT_CONFIG;
  if (!C || !C.endpoint || window.__iwtLoaded) {
    return;
  }
  window.__iwtLoaded = true;

  var STORE_KEY = 'iwt_vid';
  var COOKIE = '_iwt_vid';
  var started = false;
  var useFallback = false;

  function readCookie(name) {
    var parts = document.cookie ? document.cookie.split('; ') : [];
    for (var i = 0; i < parts.length; i++) {
      var idx = parts[i].indexOf('=');
      if (parts[i].slice(0, idx) === name) {
        try { return decodeURIComponent(parts[i].slice(idx + 1)); } catch (e) { return ''; }
      }
    }
    return '';
  }

  function writeCookie(name, value, days) {
    var d = new Date();
    d.setTime(d.getTime() + days * 864e5);
    document.cookie = name + '=' + encodeURIComponent(value) + '; expires=' + d.toUTCString() +
      '; path=/; SameSite=Lax' + (location.protocol === 'https:' ? '; Secure' : '');
  }

  function lsGet(k) { try { return window.localStorage.getItem(k) || ''; } catch (e) { return ''; } }
  function lsSet(k, v) { try { window.localStorage.setItem(k, v); } catch (e) { /* modo privado */ } }

  function isUid(v) { return /^[a-z0-9]{20}$/.test(v || ''); }

  function urlParam(name) {
    try { return new URLSearchParams(window.location.search).get(name) || ''; } catch (e) { return ''; }
  }

  function onHomeDomain() {
    return homeHost() !== '' && window.location.hostname.replace(/^www\./, '') === homeHost();
  }

  // No domínio do WordPress o cookie (gravado pelo servidor) manda: iwt_vid na URL ali só aparece em link
  // compartilhado. Em landing page de OUTRO domínio, o iwt_vid vindo do redirecionamento manda.
  function getVid() {
    var p = urlParam('iwt_vid');
    var c = readCookie(COOKIE);
    if (onHomeDomain() && isUid(c)) { return c; }
    if (isUid(p)) { return p; }
    if (isUid(c)) { return c; }
    var l = lsGet(STORE_KEY);
    return isUid(l) ? l : '';
  }

  function setVid(v) {
    if (!isUid(v)) { return; }
    lsSet(STORE_KEY, v);
    if (readCookie(COOKIE) !== v) { writeCookie(COOKIE, v, C.cookieDays || 365); }
  }

  // Tira o iwt_vid da barra de endereço: quem copiar e compartilhar o link não leva o ID junto.
  function cleanAddressBar() {
    if (!urlParam('iwt_vid') || !window.history || !window.history.replaceState) { return; }
    try {
      var u = new URL(window.location.href);
      u.searchParams.delete('iwt_vid');
      window.history.replaceState(window.history.state, '', u.toString());
    } catch (e) { /* navegador antigo */ }
  }

  function endpoint() {
    return (useFallback || lsGet('iwt_fb') === '1') && C.fallback ? C.fallback : C.endpoint;
  }

  function send(payload, beacon) {
    payload.vid = getVid();
    var body = JSON.stringify(payload);
    var url = endpoint();
    if (beacon && navigator.sendBeacon) {
      try {
        if (navigator.sendBeacon(url, new Blob([body], { type: 'text/plain' }))) { return; }
      } catch (e) { /* segue para o fetch */ }
    }
    if (!window.fetch) { return; }
    window.fetch(url, {
      method: 'POST',
      body: body,
      headers: { 'Content-Type': 'text/plain' }, // evita preflight de CORS
      credentials: 'include',
      keepalive: true
    }).then(function (r) {
      if (!r.ok) { throw new Error('HTTP ' + r.status); }
      return r.json();
    }).then(function (d) {
      if (d && d.vid) {
        setVid(d.vid);
        decorate(document);
      }
    }).catch(function () {
      // REST bloqueada por plugin de segurança? Usa o endpoint reserva nas próximas vezes.
      if (url === C.endpoint && C.fallback && !useFallback) {
        useFallback = true;
        lsSet('iwt_fb', '1');
        send(payload, false);
      }
    });
  }

  function pageview() {
    send({
      t: 'pageview',
      u: window.location.href,
      r: document.referrer || '',
      ti: (document.title || '').slice(0, 150),
      fbp: readCookie('_fbp'),
      fbc: readCookie('_fbc')
    }, false);
  }

  function track(name, href) {
    send({ t: 'event', e: name, u: window.location.href, h: (href || '').slice(0, 300) }, true);
  }

  function homeHost() {
    try { return new URL(C.home).hostname.replace(/^www\./, ''); } catch (e) { return ''; }
  }

  function checkoutParams(host) {
    var map = C.checkouts || {};
    for (var domain in map) {
      if (Object.prototype.hasOwnProperty.call(map, domain)) {
        if (host === domain || host.slice(-(domain.length + 1)) === '.' + domain) {
          return map[domain];
        }
      }
    }
    return null;
  }

  // Marca links de checkout com o código do visitante (iwv…) e links do roteador em outro domínio com iwt_vid.
  function decorateLink(a) {
    var vid = getVid();
    if (!vid) { return; }
    var href = a.getAttribute('href') || '';
    if (!href || href.charAt(0) === '#' || /^(mailto|tel|javascript|whatsapp|sms):/i.test(href)) { return; }
    var u;
    try { u = new URL(href, window.location.href); } catch (e) { return; }
    if (!/^https?:$/.test(u.protocol)) { return; }
    var host = u.hostname.replace(/^www\./, '');
    var changed = false;

    if (C.prefix && u.pathname.indexOf(C.prefix) === 0 && host === homeHost() && host !== window.location.hostname.replace(/^www\./, '')) {
      if (u.searchParams.get('iwt_vid') !== vid) {
        u.searchParams.set('iwt_vid', vid);
        changed = true;
      }
    } else if (C.decorate) {
      var params = checkoutParams(host);
      if (params) {
        var token = 'iwv' + vid;
        for (var i = 0; i < params.length; i++) {
          var current = u.searchParams.get(params[i]);
          // Respeita valor que não é nosso (ex.: sck usado pelo próprio cliente).
          if (!current || /^iw[hv][a-z0-9]+$/.test(current)) {
            if (current !== token) {
              u.searchParams.set(params[i], token);
              changed = true;
            }
          }
        }
      }
    }
    if (changed) {
      a.setAttribute('href', u.toString());
    }
  }

  function decorate(root) {
    if (!getVid()) { return; }
    var links = (root || document).querySelectorAll ? (root || document).querySelectorAll('a[href]') : [];
    for (var i = 0; i < links.length; i++) { decorateLink(links[i]); }
  }

  function onClick(e) {
    var el = e.target;
    while (el && el.nodeType === 1 && el.tagName !== 'A') { el = el.parentNode; }
    if (!el || el.tagName !== 'A') { return; }
    var href = el.getAttribute('href') || '';
    if (C.whatsapp && /(^whatsapp:|wa\.me\/|api\.whatsapp\.com|web\.whatsapp\.com|chat\.whatsapp\.com)/i.test(href)) {
      track('whatsapp_click', href);
    } else if (C.phoneEmail && /^tel:/i.test(href)) {
      track('phone_click', href);
    } else if (C.phoneEmail && /^mailto:/i.test(href)) {
      track('email_click', href);
    } else {
      var host = '';
      try { host = new URL(href, window.location.href).hostname.replace(/^www\./, ''); } catch (err) { return; }
      if (checkoutParams(host)) {
        decorateLink(el); // garante a marcação mesmo em link criado depois
        track('checkout_click', el.getAttribute('href'));
      }
    }
  }

  function observe() {
    if (!window.MutationObserver) { return; }
    var timer = null;
    new MutationObserver(function () {
      if (timer) { return; }
      timer = setTimeout(function () { timer = null; decorate(document); }, 400);
    }).observe(document.documentElement, { childList: true, subtree: true });
  }

  function start() {
    if (started) { return; }
    started = true;
    var v = getVid();
    if (v) { setVid(v); }
    cleanAddressBar();
    pageview();
    decorate(document);
    document.addEventListener('click', onClick, true);
    observe();
  }

  // ---------------------------------------------------------------- consentimento (LGPD)
  function hasConsent() {
    if (window.iwtConsent === true) { return true; }
    var cy = readCookie('cookieyes-consent'); // CookieYes
    if (cy && /analytics:yes/.test(cy)) { return true; }
    if (readCookie('cmplz_statistics') === 'allow' || readCookie('cmplz_marketing') === 'allow') { return true; } // Complianz
    if (window.Cookiebot && window.Cookiebot.consent && window.Cookiebot.consent.statistics) { return true; }
    if (readCookie('moove_gdpr_popup') && /"thirdparty":"1"/.test(readCookie('moove_gdpr_popup'))) { return true; } // GDPR Cookie Compliance
    return false;
  }

  window.iwtTracking = {
    consent: start,
    event: function (name, href) { if (started) { track(name === 'custom' ? 'custom' : String(name || 'custom'), href); } },
    vid: getVid
  };

  function boot() {
    if (!C.consent || hasConsent()) {
      start();
      return;
    }
    ['cookieyes_consent_update', 'cmplz_status_change', 'CookiebotOnAccept'].forEach(function (ev) {
      window.addEventListener(ev, function () { if (hasConsent()) { start(); } });
      document.addEventListener(ev, function () { if (hasConsent()) { start(); } });
    });
    var tries = 0;
    var poll = setInterval(function () {
      tries++;
      if (hasConsent()) { clearInterval(poll); start(); } else if (tries > 300) { clearInterval(poll); }
    }, 1000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
