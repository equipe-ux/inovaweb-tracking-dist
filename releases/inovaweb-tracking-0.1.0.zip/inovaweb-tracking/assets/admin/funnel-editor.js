/*!
 * INOVAWEB Tracking — editor visual de funis (canvas de nós e conexões), JS puro.
 *
 * Responsabilidade: desenhar e manipular o grafo (arrastar nós, ligar saída → entrada, pan/zoom,
 * seleção, números sobrepostos). Formulários de configuração ficam no admin.js, que conversa com o
 * editor por: graph(), addNode(), updateNode(), updateLink(), remove(), select(), setStats(), fit().
 */
(function () {
  'use strict';

  var NODE_W = 224;
  var NODE_H = 74;
  var GRID = 8;
  var SVGNS = 'http://www.w3.org/2000/svg';

  // Ícones inline (sem fonte de ícones: evita conflito com tema/Elementor).
  var ICONS = {
    source: '<path d="M3 11l14-6v14L3 13z"/><path d="M7 13v5a2 2 0 0 0 4 0v-3.5"/>',
    page: '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/>',
    offer: '<circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l2.5 12h11L21 7H6.2"/>',
    thankyou: '<circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.5 2.5L16 9.5"/>',
    whatsapp: '<path d="M4 20l1.3-4A8 8 0 1 1 8 18.7z"/><path d="M9 9.5c0 3 2.5 5.5 5.5 5.5l1-1.5-2-1-1 1c-1-.5-2-1.5-2.5-2.5l1-1-1-2z"/>',
    condition: '<path d="M12 3l9 9-9 9-9-9z"/><path d="M12 8v5M12 16v.5"/>',
    rotator: '<path d="M4 7h11M15 3l4 4-4 4"/><path d="M20 17H9M9 13l-4 4 4 4"/>',
    distribution: '<path d="M4 12h6M10 12l4-6h6M10 12l4 6h6M14 12h6"/>',
    script: '<path d="M8 8l-4 4 4 4M16 8l4 4-4 4M14 5l-4 14"/>'
  };

  function icon(type) {
    return '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + (ICONS[type] || ICONS.page) + '</svg>';
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function snap(v) { return Math.round(v / GRID) * GRID; }

  function hostPath(url) {
    if (!url) { return ''; }
    try {
      var u = new URL(url);
      return u.hostname.replace(/^www\./, '') + (u.pathname === '/' ? '' : u.pathname);
    } catch (e) { return url; }
  }

  var OUT_PORTS = {
    source: [''], page: [''], thankyou: [''], rotator: [''], distribution: [''], script: [''],
    condition: ['yes', 'no'], offer: [], whatsapp: []
  };

  function create(root, opts) {
    opts = opts || {};
    var types = opts.types || {};
    var labels = opts.labels || {};
    var state = {
      nodes: [], links: [], tx: 40, ty: 40, k: 1,
      selected: null, stats: null, seq: 1, readOnly: !!opts.readOnly
    };
    var listeners = { change: [], select: [], notice: [] };

    root.classList.add('iwt-canvas');
    root.setAttribute('tabindex', '0'); // recebe Delete/Backspace para apagar a seleção
    root.innerHTML =
      '<div class="iwt-stage">' +
      '<svg class="iwt-wires" width="1" height="1"><g class="iwt-wires-g"></g><path class="iwt-wire-temp" d="" /></svg>' +
      '<div class="iwt-nodes"></div>' +
      '<div class="iwt-wire-labels"></div>' + // depois dos nós: rótulo de conexão curta fica legível por cima
      '</div>' +
      '<div class="iwt-canvas-tools">' +
      '<button type="button" class="iwt-icon-btn" data-act="zoom-in" title="Aproximar" aria-label="Aproximar">+</button>' +
      '<button type="button" class="iwt-icon-btn" data-act="zoom-out" title="Afastar" aria-label="Afastar">−</button>' +
      '<button type="button" class="iwt-icon-btn" data-act="fit" title="Enquadrar o funil" aria-label="Enquadrar o funil">⤢</button>' +
      '</div>' +
      '<div class="iwt-canvas-hint">Arraste da bolinha à direita de uma etapa até outra etapa para conectar. Ctrl + rolagem dá zoom.</div>';

    var stage = root.querySelector('.iwt-stage');
    var wiresG = root.querySelector('.iwt-wires-g');
    var temp = root.querySelector('.iwt-wire-temp');
    var labelsLayer = root.querySelector('.iwt-wire-labels');
    var nodesLayer = root.querySelector('.iwt-nodes');

    function emit(name, payload) {
      listeners[name].forEach(function (fn) { fn(payload); });
    }

    function applyTransform() {
      stage.style.transform = 'translate(' + state.tx + 'px,' + state.ty + 'px) scale(' + state.k + ')';
    }

    function nodeById(id) {
      for (var i = 0; i < state.nodes.length; i++) { if (String(state.nodes[i].id) === String(id)) { return state.nodes[i]; } }
      return null;
    }
    function linkById(id) {
      for (var i = 0; i < state.links.length; i++) { if (String(state.links[i].id) === String(id)) { return state.links[i]; } }
      return null;
    }

    function subtitle(n) {
      var c = n.config || {};
      switch (n.type) {
        case 'source': return (labels.platforms && labels.platforms[c.platform]) || c.platform || '';
        case 'page': case 'thankyou': case 'offer': return hostPath(c.url) || 'URL não configurada';
        case 'whatsapp': return c.phone ? (/^d+$/.test(c.phone) ? '+' + c.phone : c.phone) : (c.url ? hostPath(c.url) : 'Número não configurado');
        case 'condition':
          var field = c.field === 'param' ? (c.param || 'parâmetro') : (labels.fields && labels.fields[c.field]) || c.field;
          return field + ' ' + ((labels.operators && labels.operators[c.operator]) || c.operator) + ' ' + (c.value || '');
        case 'rotator': return c.sticky === false ? 'Sorteio a cada acesso' : 'Variação fixa por visitante';
        case 'distribution': return c.mode === 'balanced' ? 'Equilibrado' : 'Sequencial';
        case 'script': return 'Espera ' + (c.delay || 0) + ' ms';
      }
      return '';
    }

    function portY(n, branch) {
      if (n.type === 'condition') { return n.y + (branch === 'no' ? NODE_H * 0.74 : NODE_H * 0.3); }
      return n.y + NODE_H / 2;
    }

    function wirePath(x1, y1, x2, y2) {
      var dx = Math.max(40, Math.abs(x2 - x1) * 0.5);
      return 'M' + x1 + ',' + y1 + ' C' + (x1 + dx) + ',' + y1 + ' ' + (x2 - dx) + ',' + y2 + ' ' + x2 + ',' + y2;
    }

    function renderNode(n) {
      var div = document.createElement('div');
      div.className = 'iwt-node iwt-node--' + n.type;
      div.setAttribute('data-id', n.id);
      div.setAttribute('tabindex', '0');
      div.setAttribute('role', 'button');
      div.style.left = n.x + 'px';
      div.style.top = n.y + 'px';
      var outs = OUT_PORTS[n.type] || [];
      var html = '';
      if (n.type !== 'source') { html += '<span class="iwt-port iwt-port-in" data-port="in" aria-hidden="true"></span>'; }
      html += '<span class="iwt-node-icon">' + icon(n.type) + '</span>';
      html += '<span class="iwt-node-body"><span class="iwt-node-type">' + esc((types[n.type] && types[n.type].label) || n.type) + '</span>' +
        '<span class="iwt-node-name">' + esc(n.name || '(sem nome)') + '</span>' +
        '<span class="iwt-node-sub">' + esc(subtitle(n)) + '</span></span>';
      html += '<span class="iwt-node-stat" hidden></span>';
      outs.forEach(function (b) {
        html += '<span class="iwt-port iwt-port-out' + (b ? ' iwt-port-' + b : '') + '" data-port="out" data-branch="' + b + '" title="Arraste para conectar">' +
          (b ? '<em>' + (b === 'yes' ? 'Sim' : 'Não') + '</em>' : '') + '</span>';
      });
      div.innerHTML = html;
      return div;
    }

    function linkLabel(l) {
      var from = nodeById(l.from);
      var c = l.config || {};
      var parts = [];
      if (from && from.type === 'rotator') { parts.push((c.weight != null ? c.weight : 50) + '%'); }
      if (from && from.type === 'distribution') { parts.push(c.limit ? 'até ' + c.limit : 'sem limite'); if (c.is_default) { parts.push('padrão'); } }
      if (l.alias) { parts.push('/' + l.alias); }
      var s = state.stats && state.stats.links ? state.stats.links[l.id] : null;
      var stat = s ? '<b>' + s.clicks.toLocaleString('pt-BR') + '</b> ' + (s.clicks === 1 ? 'clique' : 'cliques') : '';
      return { text: parts.join(' · '), stat: stat };
    }

    function render() {
      nodesLayer.innerHTML = '';
      state.nodes.forEach(function (n) { nodesLayer.appendChild(renderNode(n)); });
      renderWires();
      renderStats();
      renderSelection();
    }

    function renderWires() {
      wiresG.innerHTML = '';
      labelsLayer.innerHTML = '';
      state.links.forEach(function (l) {
        var a = nodeById(l.from);
        var b = nodeById(l.to);
        if (!a || !b) { return; }
        var branch = (l.config && l.config.branch) || '';
        var x1 = a.x + NODE_W;
        var y1 = portY(a, a.type === 'condition' ? (branch || 'yes') : '');
        var x2 = b.x;
        var y2 = b.y + NODE_H / 2;
        var d = wirePath(x1, y1, x2, y2);
        var g = document.createElementNS(SVGNS, 'g');
        g.setAttribute('class', 'iwt-wire' + (branch ? ' iwt-wire-' + branch : ''));
        g.setAttribute('data-id', l.id);
        var hit = document.createElementNS(SVGNS, 'path');
        hit.setAttribute('d', d);
        hit.setAttribute('class', 'iwt-wire-hit');
        var line = document.createElementNS(SVGNS, 'path');
        line.setAttribute('d', d);
        line.setAttribute('class', 'iwt-wire-line');
        g.appendChild(hit);
        g.appendChild(line);
        wiresG.appendChild(g);

        var lab = linkLabel(l);
        // Conexão curta: só o número cabe entre os nós (o apelido continua no painel lateral).
        if (x2 - x1 < 170 && lab.stat) { lab.text = ''; }
        if (lab.text || lab.stat) {
          var div = document.createElement('div');
          div.className = 'iwt-wire-label';
          div.setAttribute('data-id', l.id);
          div.innerHTML = (lab.text ? '<span>' + esc(lab.text) + '</span>' : '') + (lab.stat ? '<span class="iwt-wire-stat">' + lab.stat + '</span>' : '');
          // Ponto médio da curva de Bézier (t = 0.5).
          div.style.left = ((x1 + x2) / 2) + 'px';
          div.style.top = ((y1 + y2) / 2) + 'px';
          labelsLayer.appendChild(div);
        }
      });
    }

    function renderStats() {
      var nodes = nodesLayer.querySelectorAll('.iwt-node');
      for (var i = 0; i < nodes.length; i++) {
        var id = nodes[i].getAttribute('data-id');
        var badge = nodes[i].querySelector('.iwt-node-stat');
        var s = state.stats && state.stats.nodes ? state.stats.nodes[id] : null;
        var conv = state.stats && state.stats.conversions ? state.stats.conversions[id] : null;
        if (!state.stats || (!s && !conv)) { badge.hidden = true; continue; }
        var text = s ? s.visitors.toLocaleString('pt-BR') + (s.visitors === 1 ? ' visitante' : ' visitantes') : '';
        if (conv && conv.count) { text += (text ? ' · ' : '') + conv.count.toLocaleString('pt-BR') + ' conv.'; }
        badge.textContent = text;
        badge.hidden = !text;
      }
    }

    function renderSelection() {
      var all = root.querySelectorAll('.is-selected');
      for (var i = 0; i < all.length; i++) { all[i].classList.remove('is-selected'); }
      if (!state.selected) { return; }
      var sel = state.selected.kind === 'node'
        ? root.querySelectorAll('.iwt-node[data-id="' + state.selected.id + '"]')
        : root.querySelectorAll('.iwt-wire[data-id="' + state.selected.id + '"], .iwt-wire-label[data-id="' + state.selected.id + '"]');
      for (var j = 0; j < sel.length; j++) { sel[j].classList.add('is-selected'); }
    }

    function updateNodeEl(n) {
      var el = nodesLayer.querySelector('.iwt-node[data-id="' + n.id + '"]');
      if (el) {
        el.style.left = n.x + 'px';
        el.style.top = n.y + 'px';
      }
    }

    function toStage(clientX, clientY) {
      var r = root.getBoundingClientRect();
      return { x: (clientX - r.left - state.tx) / state.k, y: (clientY - r.top - state.ty) / state.k };
    }

    function select(kind, id) {
      state.selected = kind ? { kind: kind, id: id } : null;
      renderSelection();
      emit('select', state.selected);
    }

    function changed() { emit('change', api.graph()); }

    function canConnect(from, to, branch) {
      if (!from || !to || from.id === to.id) { return 'Não dá para ligar uma etapa nela mesma.'; }
      if (to.type === 'source') { return 'Fonte de tráfego é sempre o começo do funil: não recebe conexões.'; }
      for (var i = 0; i < state.links.length; i++) {
        var l = state.links[i];
        if (String(l.from) === String(from.id) && String(l.to) === String(to.id) && ((l.config && l.config.branch) || '') === (branch || '')) {
          return 'Essas etapas já estão conectadas.';
        }
        if (branch && String(l.from) === String(from.id) && l.config && l.config.branch === branch) {
          return 'A saída "' + (branch === 'yes' ? 'Sim' : 'Não') + '" desta condição já está ligada. Apague a conexão antiga primeiro.';
        }
      }
      return '';
    }

    // ---------------------------------------------------------------- interação (Pointer Events)
    var drag = null;

    root.addEventListener('pointerdown', function (e) {
      if (e.button !== 0) { return; }
      var tool = e.target.closest('.iwt-canvas-tools');
      if (tool) { return; }
      var port = e.target.closest('.iwt-port-out');
      var nodeEl = e.target.closest('.iwt-node');
      var wire = e.target.closest('.iwt-wire, .iwt-wire-label');
      var p = toStage(e.clientX, e.clientY);

      if (port && nodeEl && !state.readOnly) {
        var from = nodeById(nodeEl.getAttribute('data-id'));
        drag = { mode: 'connect', from: from, branch: port.getAttribute('data-branch') || '' };
        root.setPointerCapture(e.pointerId);
        e.preventDefault();
        return;
      }
      if (nodeEl) {
        var n = nodeById(nodeEl.getAttribute('data-id'));
        select('node', n.id);
        if (!state.readOnly) {
          drag = { mode: 'node', node: n, dx: p.x - n.x, dy: p.y - n.y, moved: false };
          root.setPointerCapture(e.pointerId);
        }
        return;
      }
      if (wire) {
        root.focus({ preventScroll: true });
        select('link', wire.getAttribute('data-id'));
        return;
      }
      root.focus({ preventScroll: true });
      drag = { mode: 'pan', sx: e.clientX, sy: e.clientY, tx: state.tx, ty: state.ty, moved: false };
      root.setPointerCapture(e.pointerId);
      root.classList.add('is-panning');
    });

    root.addEventListener('pointermove', function (e) {
      if (!drag) { return; }
      var p = toStage(e.clientX, e.clientY);
      if (drag.mode === 'node') {
        var nx = snap(p.x - drag.dx);
        var ny = snap(p.y - drag.dy);
        if (nx !== drag.node.x || ny !== drag.node.y) {
          drag.node.x = nx;
          drag.node.y = ny;
          drag.moved = true;
          updateNodeEl(drag.node);
          renderWires();
          renderSelection();
        }
      } else if (drag.mode === 'pan') {
        state.tx = drag.tx + (e.clientX - drag.sx);
        state.ty = drag.ty + (e.clientY - drag.sy);
        if (Math.abs(e.clientX - drag.sx) + Math.abs(e.clientY - drag.sy) > 3) { drag.moved = true; }
        applyTransform();
      } else if (drag.mode === 'connect') {
        var a = drag.from;
        var y1 = portY(a, a.type === 'condition' ? (drag.branch || 'yes') : '');
        temp.setAttribute('d', wirePath(a.x + NODE_W, y1, p.x, p.y));
        var over = document.elementFromPoint(e.clientX, e.clientY);
        var targetEl = over && over.closest ? over.closest('.iwt-node') : null;
        var hover = root.querySelector('.iwt-node.is-target');
        if (hover && hover !== targetEl) { hover.classList.remove('is-target'); }
        if (targetEl && targetEl.getAttribute('data-id') !== String(a.id)) { targetEl.classList.add('is-target'); }
      }
    });

    function endDrag(e) {
      if (!drag) { return; }
      var d = drag;
      drag = null;
      root.classList.remove('is-panning');
      if (d.mode === 'node' && d.moved) { changed(); }
      if (d.mode === 'pan' && !d.moved) { select(null); }
      if (d.mode === 'connect') {
        temp.setAttribute('d', '');
        var hover = root.querySelector('.iwt-node.is-target');
        if (hover) { hover.classList.remove('is-target'); }
        var over = e && document.elementFromPoint(e.clientX, e.clientY);
        var targetEl = over && over.closest ? over.closest('.iwt-node') : null;
        if (!targetEl) { return; }
        var to = nodeById(targetEl.getAttribute('data-id'));
        var problem = canConnect(d.from, to, d.branch);
        if (problem) { emit('notice', problem); return; }
        var config = {};
        if (d.branch) { config.branch = d.branch; }
        if (d.from.type === 'rotator') { config.weight = 50; }
        if (d.from.type === 'distribution') { config.limit = 100; }
        var link = { id: 'l' + (state.seq++) + '_' + Date.now().toString(36), from: d.from.id, to: to.id, alias: '', config: config, url: '' };
        state.links.push(link);
        renderWires();
        renderStats();
        select('link', link.id);
        changed();
      }
    }
    root.addEventListener('pointerup', endDrag);
    root.addEventListener('pointercancel', function () { endDrag(null); });

    root.addEventListener('wheel', function (e) {
      if (!e.ctrlKey && !e.metaKey) { return; } // rolagem normal continua rolando a página
      e.preventDefault();
      zoomAt(e.deltaY < 0 ? 1.12 : 1 / 1.12, e.clientX, e.clientY);
    }, { passive: false });

    root.addEventListener('click', function (e) {
      var btn = e.target.closest('[data-act]');
      if (!btn) { return; }
      var act = btn.getAttribute('data-act');
      var r = root.getBoundingClientRect();
      if (act === 'zoom-in') { zoomAt(1.2, r.left + r.width / 2, r.top + r.height / 2); }
      if (act === 'zoom-out') { zoomAt(1 / 1.2, r.left + r.width / 2, r.top + r.height / 2); }
      if (act === 'fit') { api.fit(); }
    });

    root.addEventListener('keydown', function (e) {
      if (state.readOnly || !state.selected) { return; }
      var tag = (e.target.tagName || '').toLowerCase();
      if (tag === 'input' || tag === 'textarea' || tag === 'select') { return; }
      if (e.key === 'Delete' || e.key === 'Backspace') {
        e.preventDefault();
        api.remove(state.selected.kind, state.selected.id);
      }
      if (e.key === 'Enter' && e.target.classList.contains('iwt-node')) {
        select('node', e.target.getAttribute('data-id'));
      }
    });

    function zoomAt(factor, cx, cy) {
      var r = root.getBoundingClientRect();
      var k = Math.max(0.3, Math.min(1.8, state.k * factor));
      var px = cx - r.left;
      var py = cy - r.top;
      state.tx = px - (px - state.tx) * (k / state.k);
      state.ty = py - (py - state.ty) * (k / state.k);
      state.k = k;
      applyTransform();
    }

    // ---------------------------------------------------------------- API pública
    var api = {
      on: function (name, fn) { listeners[name].push(fn); return api; },

      load: function (graph) {
        state.nodes = (graph.nodes || []).map(function (n) {
          return { id: n.id, type: n.type, name: n.name, config: n.config || {}, x: +n.x || 0, y: +n.y || 0 };
        });
        state.links = (graph.links || []).map(function (l) {
          return { id: l.id, from: l.from, to: l.to, alias: l.alias || '', config: l.config || {}, url: l.url || '' };
        });
        if (state.selected) {
          var still = state.selected.kind === 'node' ? nodeById(state.selected.id) : linkById(state.selected.id);
          if (!still) { state.selected = null; }
        }
        render();
      },

      graph: function () {
        return {
          nodes: state.nodes.map(function (n) { return { id: n.id, type: n.type, name: n.name, config: n.config, x: n.x, y: n.y }; }),
          links: state.links.map(function (l) { return { id: l.id, from: l.from, to: l.to, alias: l.alias, config: l.config, url: l.url }; })
        };
      },

      node: nodeById,
      link: linkById,
      links: function () { return state.links.slice(); },
      nodes: function () { return state.nodes.slice(); },

      addNode: function (type, name, config) {
        var r = root.getBoundingClientRect();
        var c = toStage(r.left + r.width / 2, r.top + r.height / 2);
        // Desloca um pouco a cada nó novo para não empilhar.
        var offset = (state.seq % 5) * 24;
        var n = { id: 'n' + (state.seq++) + '_' + Date.now().toString(36), type: type, name: name || '', config: config || {},
          x: snap(c.x - NODE_W / 2 + offset), y: snap(c.y - NODE_H / 2 + offset) };
        state.nodes.push(n);
        render();
        select('node', n.id);
        changed();
        return n;
      },

      updateNode: function (id, patch) {
        var n = nodeById(id);
        if (!n) { return; }
        if (patch.name !== undefined) { n.name = patch.name; }
        if (patch.config) { n.config = Object.assign({}, n.config, patch.config); }
        var el = nodesLayer.querySelector('.iwt-node[data-id="' + n.id + '"]');
        if (el) {
          el.querySelector('.iwt-node-name').textContent = n.name || '(sem nome)';
          el.querySelector('.iwt-node-sub').textContent = subtitle(n);
        }
        renderWires();
        renderSelection();
        changed();
      },

      updateLink: function (id, patch) {
        var l = linkById(id);
        if (!l) { return; }
        if (patch.alias !== undefined) { l.alias = patch.alias; }
        if (patch.config) { l.config = Object.assign({}, l.config, patch.config); }
        renderWires();
        renderSelection();
        changed();
      },

      remove: function (kind, id) {
        if (kind === 'node') {
          state.nodes = state.nodes.filter(function (n) { return String(n.id) !== String(id); });
          state.links = state.links.filter(function (l) { return String(l.from) !== String(id) && String(l.to) !== String(id); });
        } else {
          state.links = state.links.filter(function (l) { return String(l.id) !== String(id); });
        }
        state.selected = null;
        render();
        emit('select', null);
        changed();
      },

      select: select,
      selected: function () { return state.selected; },

      setStats: function (stats) {
        state.stats = stats;
        root.classList.toggle('has-stats', !!stats);
        renderWires();
        renderStats();
        renderSelection();
      },

      fit: function () {
        if (!state.nodes.length) {
          state.tx = 40; state.ty = 40; state.k = 1;
          applyTransform();
          return;
        }
        var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        state.nodes.forEach(function (n) {
          minX = Math.min(minX, n.x); minY = Math.min(minY, n.y);
          maxX = Math.max(maxX, n.x + NODE_W); maxY = Math.max(maxY, n.y + NODE_H);
        });
        var r = root.getBoundingClientRect();
        var pad = 56;
        var k = Math.min(1.1, (r.width - pad * 2) / Math.max(1, maxX - minX), (r.height - pad * 2) / Math.max(1, maxY - minY));
        state.k = Math.max(0.3, k);
        state.tx = (r.width - (maxX - minX) * state.k) / 2 - minX * state.k;
        state.ty = (r.height - (maxY - minY) * state.k) / 2 - minY * state.k;
        applyTransform();
      },

      setReadOnly: function (v) { state.readOnly = !!v; root.classList.toggle('is-readonly', !!v); }
    };

    applyTransform();
    if (opts.graph) { api.load(opts.graph); }
    return api;
  }

  window.IWTEditor = { create: create, icon: icon };
})();
