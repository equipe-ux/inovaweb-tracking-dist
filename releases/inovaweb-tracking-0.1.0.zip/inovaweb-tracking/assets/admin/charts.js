/*!
 * INOVAWEB Tracking — gráficos em SVG puro (sem bibliotecas).
 * Regras: uma série por gráfico (um eixo só), linha 2px, área com ~10% de opacidade, grade em
 * linha fina sólida, rótulos em cor de texto (nunca na cor da série), cruz + tooltip no hover.
 */
(function () {
  'use strict';

  var NS = 'http://www.w3.org/2000/svg';

  function el(tag, attrs, parent) {
    var node = document.createElementNS(NS, tag);
    for (var k in attrs) {
      if (Object.prototype.hasOwnProperty.call(attrs, k)) { node.setAttribute(k, attrs[k]); }
    }
    if (parent) { parent.appendChild(node); }
    return node;
  }

  // Ticks "redondos": 0, 250, 500… sempre começando em zero.
  function niceTicks(max, count) {
    if (!(max > 0)) { return [0, 1]; }
    var raw = max / count;
    var mag = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10));
    var steps = [1, 2, 2.5, 5, 10];
    var step = mag;
    for (var i = 0; i < steps.length; i++) {
      if (raw <= steps[i] * mag) { step = steps[i] * mag; break; }
    }
    var ticks = [];
    for (var v = 0; v <= max + step * 0.001; v += step) { ticks.push(v); }
    if (ticks[ticks.length - 1] < max) { ticks.push(ticks[ticks.length - 1] + step); }
    return ticks;
  }

  function shortDate(iso) {
    var p = String(iso).split('-');
    return p.length === 3 ? p[2] + '/' + p[1] : iso;
  }

  /**
   * Linha de uma série.
   * opts: { data: [{date, value}], label: 'Visitas', format: fn(valor) → texto, color: css var }
   */
  function line(container, opts) {
    container.innerHTML = '';
    var data = opts.data || [];
    var fmt = opts.format || function (v) { return String(v); };
    var width = Math.max(320, container.clientWidth || 600);
    var height = opts.height || 240;
    var m = { top: 16, right: 16, bottom: 28, left: 56 };
    var w = width - m.left - m.right;
    var h = height - m.top - m.bottom;

    var max = 0;
    data.forEach(function (d) { if (d.value > max) { max = d.value; } });
    var ticks = niceTicks(max, 4);
    var top = ticks[ticks.length - 1] || 1;

    var svg = el('svg', { width: width, height: height, viewBox: '0 0 ' + width + ' ' + height, role: 'img', 'aria-label': (opts.label || '') + ' por dia', class: 'iwt-chart-svg' }, container);
    var g = el('g', { transform: 'translate(' + m.left + ',' + m.top + ')' }, svg);

    var x = function (i) { return data.length <= 1 ? w / 2 : (i / (data.length - 1)) * w; };
    var y = function (v) { return h - (v / top) * h; };

    ticks.forEach(function (t) {
      el('line', { x1: 0, x2: w, y1: y(t), y2: y(t), class: 'iwt-grid' }, g);
      var label = el('text', { x: -10, y: y(t), dy: '0.32em', 'text-anchor': 'end', class: 'iwt-axis' }, g);
      label.textContent = fmt(t, true);
    });

    // Rótulos do eixo X sem colidir: no máximo ~1 a cada 64px.
    var every = Math.max(1, Math.ceil(data.length / Math.max(1, Math.floor(w / 64))));
    data.forEach(function (d, i) {
      if (i % every !== 0 && i !== data.length - 1) { return; }
      if (i !== data.length - 1 && data.length - 1 - i < every) { return; }
      var t = el('text', { x: x(i), y: h + 20, 'text-anchor': 'middle', class: 'iwt-axis' }, g);
      t.textContent = shortDate(d.date);
    });

    if (!data.length) { return; }

    var path = '';
    var area = '';
    data.forEach(function (d, i) {
      path += (i ? 'L' : 'M') + x(i).toFixed(1) + ',' + y(d.value).toFixed(1);
    });
    area = path + 'L' + x(data.length - 1).toFixed(1) + ',' + h + 'L' + x(0).toFixed(1) + ',' + h + 'Z';
    el('path', { d: area, class: 'iwt-area' }, g);
    el('path', { d: path, class: 'iwt-line' }, g);

    // Marcador no último ponto (ancora a leitura do valor atual).
    var last = data[data.length - 1];
    el('circle', { cx: x(data.length - 1), cy: y(last.value), r: 4, class: 'iwt-dot' }, g);

    // Camada de hover: cruz + ponto + tooltip HTML.
    var cross = el('line', { y1: 0, y2: h, class: 'iwt-cross', visibility: 'hidden' }, g);
    var focus = el('circle', { r: 5, class: 'iwt-dot iwt-dot-focus', visibility: 'hidden' }, g);
    var tip = document.createElement('div');
    tip.className = 'iwt-tooltip';
    tip.hidden = true;
    container.appendChild(tip);
    var hit = el('rect', { x: 0, y: 0, width: w, height: h, fill: 'transparent' }, g);

    function show(evt) {
      var rect = svg.getBoundingClientRect();
      var px = (evt.touches ? evt.touches[0].clientX : evt.clientX) - rect.left - m.left;
      var i = data.length <= 1 ? 0 : Math.round((px / w) * (data.length - 1));
      i = Math.max(0, Math.min(data.length - 1, i));
      var d = data[i];
      cross.setAttribute('x1', x(i));
      cross.setAttribute('x2', x(i));
      cross.setAttribute('visibility', 'visible');
      focus.setAttribute('cx', x(i));
      focus.setAttribute('cy', y(d.value));
      focus.setAttribute('visibility', 'visible');
      tip.innerHTML = '<span class="iwt-tooltip-date">' + (opts.dateLabel ? opts.dateLabel(d.date) : shortDate(d.date)) + '</span>' +
        '<strong>' + fmt(d.value) + '</strong> <span>' + (opts.label || '') + '</span>';
      tip.hidden = false;
      var left = m.left + x(i);
      var tw = tip.offsetWidth;
      tip.style.left = Math.max(4, Math.min(width - tw - 4, left - tw / 2)) + 'px';
      tip.style.top = Math.max(0, m.top + y(d.value) - tip.offsetHeight - 12) + 'px';
    }
    function hide() {
      cross.setAttribute('visibility', 'hidden');
      focus.setAttribute('visibility', 'hidden');
      tip.hidden = true;
    }
    hit.addEventListener('mousemove', show);
    hit.addEventListener('touchstart', show, { passive: true });
    hit.addEventListener('touchmove', show, { passive: true });
    hit.addEventListener('mouseleave', hide);
  }

  window.IWTCharts = { line: line, niceTicks: niceTicks };
})();
