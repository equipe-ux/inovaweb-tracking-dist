<?php
/**
 * Conversões: venda (checkout), página de obrigado, WhatsApp e lead.
 *
 * - Idempotência pela coluna dedupe_key (UNIQUE): webhook repetido nunca duplica venda.
 * - A conversão guarda os três ponteiros de atribuição do visitante (primeiro toque, último toque
 *   não-direto e último toque pago) no momento em que acontece; os relatórios escolhem o modelo.
 * - A data da conversão (converted_at) é a data da APROVAÇÃO, não a do clique.
 * - Ao ser aprovada dispara do_action('iwt_conversion_approved', $id) — é onde o Meta CAPI escuta.
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_Conversions
{
    public static function types(): array
    {
        return ['sale' => 'Venda', 'thankyou' => 'Página de obrigado', 'whatsapp' => 'WhatsApp', 'lead' => 'Lead'];
    }

    public static function statuses(): array
    {
        return [
            'approved' => 'Aprovada',
            'pending' => 'Pendente (boleto/pix)',
            'refunded' => 'Reembolsada',
            'chargeback' => 'Chargeback',
            'canceled' => 'Cancelada',
        ];
    }

    public static function get(int $id): ?object
    {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . IWT_DB::t('conversions') . ' WHERE id = %d', $id));
        return $row ?: null;
    }

    public static function get_by_dedupe(string $key): ?object
    {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . IWT_DB::t('conversions') . ' WHERE dedupe_key = %s', $key));
        return $row ?: null;
    }

    /** Ponteiros de atribuição do visitante neste momento. */
    public static function attribution(?object $visitor): array
    {
        if (!$visitor) {
            return ['first_session_id' => 0, 'last_session_id' => 0, 'paid_session_id' => 0];
        }
        $last = (int) $visitor->last_touch_session_id ?: ((int) $visitor->current_session_id ?: (int) $visitor->first_session_id);
        return [
            'first_session_id' => (int) $visitor->first_session_id ?: $last,
            'last_session_id' => $last,
            'paid_session_id' => (int) $visitor->paid_session_id,
        ];
    }

    /**
     * Conversão gerada dentro do funil (chegou na página de obrigado ou passou pelo link do WhatsApp).
     * Com "1 conversão por visitante" ligado, o mesmo visitante conta uma vez por funil.
     */
    public static function record_funnel_event(string $type, object $funnel, ?object $node, ?object $link, int $hit_id, object $visitor, ?object $session): int
    {
        global $wpdb;
        $unique = (bool) IWT_Settings::get('unique_lead_per_visitor');
        $dedupe = $unique ? "{$type}:f{$funnel->id}:v{$visitor->id}" : "{$type}:h" . ($hit_id ?: uniqid());
        if (self::get_by_dedupe($dedupe)) {
            return 0;
        }
        $now = IWT_Helpers::now();
        $settings = is_array($funnel->settings) ? $funnel->settings : IWT_Helpers::json_decode_array($funnel->settings);
        $value = (float) ($settings['lead_value'] ?? 0);
        $row = [
            'created_at' => $now,
            'updated_at' => $now,
            'converted_at' => $now,
            'type' => $type,
            'status' => 'approved',
            'platform' => '',
            'transaction_id' => '',
            'dedupe_key' => $dedupe,
            'funnel_id' => (int) $funnel->id,
            'link_id' => $link ? (int) $link->id : 0,
            'node_id' => $node ? (int) $node->id : 0,
            'hit_id' => $hit_id,
            'visitor_id' => (int) $visitor->id,
            'match_method' => 'hit',
            'value' => $value,
            'net_value' => $value,
            'currency' => $funnel->currency ?: (string) IWT_Settings::get('currency'),
        ] + self::attribution($visitor);

        // INSERT IGNORE: duas requisições simultâneas não geram conversão dupla.
        $ok = self::insert_ignore($row);
        if (!$ok) {
            return 0;
        }
        $id = (int) $wpdb->insert_id;
        do_action('iwt_conversion_approved', $id);
        return $id;
    }

    /**
     * Descobre a quem pertence uma venda.
     * Ordem: token do clique (iwh…) → token do visitante (iwv…) → e-mail já conhecido → produto do funil.
     */
    public static function match(?array $token, string $email_hash, string $product_id): array
    {
        global $wpdb;
        $out = ['visitor' => null, 'hit_id' => 0, 'funnel_id' => 0, 'link_id' => 0, 'node_id' => 0, 'method' => 'none'];

        if ($token && $token['type'] === 'hit') {
            $hit = IWT_Visitors::get_hit((int) $token['value']);
            if ($hit) {
                $out['visitor'] = $hit->visitor_id ? IWT_Visitors::find((int) $hit->visitor_id) : null;
                $out['hit_id'] = (int) $hit->id;
                $out['funnel_id'] = (int) $hit->funnel_id;
                $out['link_id'] = (int) $hit->link_id;
                $out['node_id'] = (int) $hit->to_node_id;
                $out['method'] = 'hit';
                return $out;
            }
        }
        if ($token && $token['type'] === 'visitor') {
            $out['visitor'] = IWT_Visitors::find_by_uid($token['value']);
            if ($out['visitor']) {
                $out['method'] = 'visitor';
            }
        }
        if (!$out['visitor'] && $email_hash !== '') {
            $out['visitor'] = IWT_Visitors::find_by_email_hash($email_hash);
            if ($out['visitor']) {
                $out['method'] = 'email';
            }
        }
        if ($out['visitor']) {
            // Último clique em checkout deste visitante nos últimos 30 dias define o funil.
            $hit = $wpdb->get_row($wpdb->prepare(
                'SELECT h.* FROM ' . IWT_DB::t('hits') . ' h JOIN ' . IWT_DB::t('nodes') . " n ON n.id = h.to_node_id
                 WHERE h.visitor_id = %d AND n.type = 'offer' AND h.created_at >= %s ORDER BY h.id DESC LIMIT 1",
                (int) $out['visitor']->id,
                gmdate('Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS)
            ));
            if ($hit) {
                $out['hit_id'] = (int) $hit->id;
                $out['funnel_id'] = (int) $hit->funnel_id;
                $out['link_id'] = (int) $hit->link_id;
                $out['node_id'] = (int) $hit->to_node_id;
            } else {
                $session = IWT_Visitors::get_session((int) $out['visitor']->current_session_id);
                $out['funnel_id'] = $session ? (int) $session->funnel_id : 0;
            }
        }
        if (!$out['funnel_id'] && $product_id !== '') {
            $out['funnel_id'] = self::funnel_by_product($product_id);
            if ($out['funnel_id'] && $out['method'] === 'none') {
                $out['method'] = 'product';
            }
        }
        return $out;
    }

    /** Funil ativo que declara o ID de produto (configuração do funil ou do nó de checkout). */
    public static function funnel_by_product(string $product_id): int
    {
        foreach (IWT_Funnels::all() as $funnel) {
            $ids = array_filter(array_map('trim', explode(',', (string) ($funnel->settings['product_ids'] ?? ''))));
            if (in_array($product_id, $ids, true)) {
                return (int) $funnel->id;
            }
        }
        global $wpdb;
        $like = '%' . $wpdb->esc_like('"product_id":"' . $product_id . '"') . '%';
        $fid = $wpdb->get_var($wpdb->prepare(
            'SELECT funnel_id FROM ' . IWT_DB::t('nodes') . " WHERE type = 'offer' AND deleted = 0 AND config LIKE %s ORDER BY id DESC LIMIT 1",
            $like
        ));
        return (int) $fid;
    }

    /**
     * Cria ou atualiza uma venda vinda de webhook/WooCommerce.
     * @param array $n saída de IWT_Platforms::normalize() (ou equivalente)
     * @return array{id:int,created:bool,old_status:string,status:string}
     */
    public static function upsert_sale(string $platform, array $n, array $match, bool $retried = false): array
    {
        global $wpdb;
        $now = IWT_Helpers::now();
        $txn = (string) ($n['transaction_id'] ?? '');
        $token_key = $n['token'] ? $n['token']['type'] . $n['token']['value'] : '';
        $dedupe = $txn !== '' ? $platform . ':' . $txn : $platform . ':' . md5($token_key . '|' . ($n['product_id'] ?? '') . '|' . ($n['email'] ?? ''));
        $dedupe = IWT_Helpers::truncate($dedupe, 191);

        $store_pii = (bool) IWT_Settings::get('store_customer_pii');
        $email_hash = IWT_Helpers::hash_email($n['email'] ?? '');
        $phone_hash = IWT_Helpers::hash_phone($n['phone'] ?? '');
        $visitor = $match['visitor'];
        $type = ($n['type'] ?? 'sale') === 'lead' ? 'lead' : 'sale';
        $status = (string) $n['status'];

        $existing = self::get_by_dedupe($dedupe);
        if ($existing) {
            $old = (string) $existing->status;
            $update = ['updated_at' => $now];
            // Não rebaixa uma venda aprovada para pendente (alguns checkouts reenviam "boleto impresso").
            if ($status !== '' && $status !== $old && !($old === 'approved' && $status === 'pending')) {
                $update['status'] = $status;
                if ($status === 'approved' && $old !== 'approved') {
                    $update['converted_at'] = $now;
                }
            }
            foreach (['value', 'net_value'] as $k) {
                if ((float) ($n[$k] ?? 0) > 0) {
                    $update[$k] = (float) $n[$k];
                }
            }
            if (!(int) $existing->visitor_id && $visitor) {
                $update += ['visitor_id' => (int) $visitor->id, 'match_method' => $match['method']] + self::attribution($visitor);
            }
            if (!(int) $existing->funnel_id && $match['funnel_id']) {
                $update += ['funnel_id' => $match['funnel_id'], 'link_id' => $match['link_id'], 'node_id' => $match['node_id'], 'hit_id' => $match['hit_id']];
            }
            $wpdb->update(IWT_DB::t('conversions'), $update, ['id' => (int) $existing->id]);
            $new = $update['status'] ?? $old;
            if ($new !== $old) {
                do_action('iwt_conversion_status_changed', (int) $existing->id, $old, $new);
                if ($new === 'approved') {
                    do_action('iwt_conversion_approved', (int) $existing->id);
                }
            }
            return ['id' => (int) $existing->id, 'created' => false, 'old_status' => $old, 'status' => $new];
        }

        $row = [
            'created_at' => $now,
            'updated_at' => $now,
            'converted_at' => $now,
            'type' => $type,
            'status' => $status !== '' ? $status : 'approved',
            'platform' => $platform,
            'transaction_id' => $txn,
            'dedupe_key' => $dedupe,
            'funnel_id' => (int) $match['funnel_id'],
            'link_id' => (int) $match['link_id'],
            'node_id' => (int) $match['node_id'],
            'hit_id' => (int) $match['hit_id'],
            'visitor_id' => $visitor ? (int) $visitor->id : 0,
            'match_method' => $match['method'],
            'value' => (float) ($n['value'] ?? 0),
            'net_value' => (float) ($n['net_value'] ?? 0) ?: (float) ($n['value'] ?? 0),
            'currency' => ($n['currency'] ?? '') ?: self::funnel_currency((int) $match['funnel_id']),
            'product_id' => (string) ($n['product_id'] ?? ''),
            'product_name' => (string) ($n['product_name'] ?? ''),
            'payment_method' => (string) ($n['payment_method'] ?? ''),
            'customer_name' => $store_pii ? (string) ($n['name'] ?? '') : '',
            'customer_email' => $store_pii ? (string) ($n['email'] ?? '') : '',
            'customer_phone' => $store_pii ? (string) ($n['phone'] ?? '') : '',
            'email_hash' => $email_hash,
            'phone_hash' => $phone_hash,
            'meta' => wp_json_encode(['raw_status' => $n['raw_status'] ?? '', 'first_name' => self::first_name($n['name'] ?? '')]),
        ] + self::attribution($visitor);

        if (!self::insert_ignore($row)) {
            if ($retried) {
                return ['id' => 0, 'created' => false, 'old_status' => '', 'status' => ''];
            }
            // Corrida com outra entrega do mesmo webhook: trata como atualização.
            return self::upsert_sale($platform, $n, $match, true);
        }
        $id = (int) $wpdb->insert_id;
        if ($visitor) {
            IWT_Visitors::enrich((int) $visitor->id, $email_hash, $phone_hash);
        }
        if ($row['status'] === 'approved') {
            do_action('iwt_conversion_approved', $id);
        }
        return ['id' => $id, 'created' => true, 'old_status' => '', 'status' => $row['status']];
    }

    private static function insert_ignore(array $row): bool
    {
        global $wpdb;
        $table = IWT_DB::t('conversions');
        $cols = array_keys($row);
        $formats = [];
        foreach ($row as $v) {
            $formats[] = is_int($v) ? '%d' : (is_float($v) ? '%f' : '%s');
        }
        $sql = "INSERT IGNORE INTO $table (`" . implode('`,`', $cols) . '`) VALUES (' . implode(',', $formats) . ')';
        $result = $wpdb->query($wpdb->prepare($sql, array_values($row))); // phpcs:ignore WordPress.DB.PreparedSQL
        return (int) $result === 1 && (int) $wpdb->insert_id > 0;
    }

    private static function funnel_currency(int $funnel_id): string
    {
        if ($funnel_id) {
            $f = IWT_Funnels::get($funnel_id);
            if ($f && $f->currency) {
                return $f->currency;
            }
        }
        return (string) IWT_Settings::get('currency');
    }

    private static function first_name(string $name): string
    {
        $parts = preg_split('/\s+/', trim($name));
        return $parts ? (string) $parts[0] : '';
    }

    public static function delete(int $id): void
    {
        global $wpdb;
        $wpdb->delete(IWT_DB::t('conversions'), ['id' => $id]);
    }
}
