<?php
/**
 * Roteador dos links rastreáveis: {site}/{prefixo}/{id ou alias}  (ou ?iwt_go=… sem links permanentes).
 *
 * Para cada acesso:
 *  1. identifica o visitante (cookie _iwt_vid; ou ?iwt_vid= vindo de outro domínio);
 *  2. se o link sai de uma FONTE DE TRÁFEGO, registra a origem (canal/UTM/click ID) numa visita;
 *  3. registra um hit por link percorrido (condição/A-B/distribuição percorrem mais de um link);
 *  4. resolve o destino pelo tipo do nó e redireciona.
 *
 * Funil pausado/arquivado/excluído continua redirecionando, só deixa de contar.
 * ?iwt_test=1 navega sem registrar nada (para testar o funil).
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_Router
{
    const MAX_DEPTH = 12;

    /** Parâmetros internos que não são repassados ao destino. */
    const INTERNAL_PARAMS = ['iwt_go', 'iwt_test', 'iwt_vid'];

    public static function init(): void
    {
        add_action('init', [__CLASS__, 'maybe_handle'], 0);
    }

    public static function maybe_handle(): void
    {
        if (wp_doing_ajax() || wp_doing_cron() || (defined('REST_REQUEST') && REST_REQUEST)) {
            return;
        }
        $key = self::requested_key();
        if ($key === null) {
            return;
        }
        self::handle($key);
    }

    public static function requested_key(): ?string
    {
        if (isset($_GET['iwt_go']) && is_string($_GET['iwt_go'])) {
            $key = sanitize_text_field(wp_unslash($_GET['iwt_go']));
            return $key !== '' ? $key : null;
        }
        $uri = isset($_SERVER['REQUEST_URI']) ? (string) wp_unslash($_SERVER['REQUEST_URI']) : '';
        $path = (string) wp_parse_url($uri, PHP_URL_PATH);
        $home_path = rtrim((string) wp_parse_url(home_url('/'), PHP_URL_PATH), '/');
        $base = $home_path . '/' . IWT_Settings::route_prefix() . '/';
        if (stripos($path, $base) !== 0) {
            return null;
        }
        $rest = trim(rawurldecode(substr($path, strlen($base))), '/');
        if ($rest === '') {
            return null;
        }
        return explode('/', $rest)[0];
    }

    public static function handle(string $key): void
    {
        if (!defined('DONOTCACHEPAGE')) {
            define('DONOTCACHEPAGE', true); // WP Rocket, LiteSpeed, W3TC…
        }
        nocache_headers();
        header('X-Robots-Tag: noindex, nofollow', true);

        $link = IWT_Funnels::find_link_by_key($key);
        if (!$link) {
            self::redirect(self::fallback_url(), 302);
        }

        $ctx = self::context();
        $url = '';
        try {
            $url = self::traverse($link, $ctx, 0);
        } catch (Throwable $e) {
            // Nunca deixar o visitante numa tela de erro: segue para o fallback.
            error_log('[INOVAWEB Tracking] Falha no roteamento do link ' . $link->id . ': ' . $e->getMessage());
        }
        self::redirect($url !== '' ? $url : self::fallback_url(), (int) IWT_Settings::get('redirect_code'));
    }

    /** Contexto da requisição, compartilhado pelos saltos do roteamento. */
    public static function context(): object
    {
        $props = IWT_Request::props();
        $method = isset($_SERVER['REQUEST_METHOD']) ? strtoupper((string) $_SERVER['REQUEST_METHOD']) : 'GET';
        $test = isset($_GET['iwt_test']);
        $skip = $test || $method === 'HEAD' || IWT_Request::is_excluded_ip($props['ip']);
        $is_bot = (bool) $props['is_bot'];

        $explicit_vid = isset($_GET['iwt_vid']) && is_string($_GET['iwt_vid']) ? sanitize_key(wp_unslash($_GET['iwt_vid'])) : '';
        $visitor = null;
        if (!$is_bot) {
            $visitor = IWT_Visitors::identify($explicit_vid, !$skip);
        }

        return (object) [
            'props' => $props,
            'params' => self::incoming_params(),
            'skip' => $skip,
            'test' => $test,
            'is_bot' => $is_bot,
            'visitor' => $visitor,
            'session' => null,
            'funnel' => null,
            'funnel_hosts' => null,
            'last_hit_id' => 0,
        ];
    }

    public static function incoming_params(): array
    {
        $params = [];
        foreach ($_GET as $k => $v) {
            if (!is_string($k) || in_array($k, self::INTERNAL_PARAMS, true) || !is_scalar($v)) {
                continue;
            }
            $params[sanitize_text_field($k)] = sanitize_text_field(wp_unslash((string) $v));
        }
        return $params;
    }

    /** Percorre um link e devolve a URL final ('' = usar fallback). */
    public static function traverse(object $link, object $ctx, int $depth): string
    {
        if ($depth > self::MAX_DEPTH) {
            return '';
        }
        $from = IWT_Funnels::get_node((int) $link->from_node_id);
        $to = IWT_Funnels::get_node((int) $link->to_node_id);
        if (!$to) {
            return '';
        }
        if (!$ctx->funnel) {
            $ctx->funnel = IWT_Funnels::get((int) $link->funnel_id);
        }
        $funnel = $ctx->funnel;
        $counting = !$ctx->skip && $funnel && $funnel->status === 'active' && empty($funnel->deleted_at);
        $operators = ['condition', 'rotator', 'distribution'];

        // 1) Origem
        $cost = 0.0;
        if ($from && $from->type === 'source') {
            $cost = (float) ($from->config['cpc'] ?? 0);
            $cost_param = (string) ($from->config['cost_param'] ?? '');
            if ($cost_param !== '' && isset($ctx->params[$cost_param])) {
                $cost = IWT_Helpers::parse_money($ctx->params[$cost_param]);
            }
            if ($counting && $ctx->visitor) {
                $attr = IWT_Sources::classify([
                    'params' => $ctx->params,
                    'referrer' => $ctx->props['referrer'],
                    'in_app' => $ctx->props['in_app'],
                    'platform' => $from->config['platform'] ?? 'other',
                    'paid' => $from->config['paid'] ?? null,
                ]);
                $ctx->session = IWT_Visitors::touch($ctx->visitor, $attr, [
                    'landing' => self::describe_node($to),
                    'funnel_id' => (int) $funnel->id,
                    'link_id' => (int) $link->id,
                    'source_node_id' => (int) $from->id,
                    'entry' => true,
                ]);
            }
        }
        if ($counting && $ctx->visitor && !$ctx->session) {
            // Salto no meio do funil: o referenciador costuma ser a própria página do funil — não é origem nova.
            $referrer = $ctx->props['referrer'];
            if ($referrer !== '' && in_array(IWT_Helpers::host_of($referrer), self::funnel_hosts($ctx), true)) {
                $referrer = '';
            }
            $attr = IWT_Sources::classify(['params' => $ctx->params, 'referrer' => $referrer, 'in_app' => $ctx->props['in_app']]);
            $ctx->session = IWT_Visitors::touch($ctx->visitor, $attr, [
                'landing' => self::describe_node($to),
                'funnel_id' => (int) $funnel->id,
                'link_id' => (int) $link->id,
                'continue_if_active' => true,
            ]);
        }

        // 2) Hit
        $hit_id = 0;
        if ($counting && ($ctx->visitor || $ctx->is_bot)) {
            $hit_id = IWT_Visitors::log_hit([
                'visitor_id' => $ctx->visitor ? (int) $ctx->visitor->id : 0,
                'session_id' => $ctx->session ? (int) $ctx->session->id : 0,
                'type' => 'click',
                'event' => in_array($to->type, $operators, true) ? 'route' : '',
                'funnel_id' => (int) $link->funnel_id,
                'link_id' => (int) $link->id,
                'from_node_id' => (int) $link->from_node_id,
                'to_node_id' => (int) $to->id,
                'url' => self::describe_node($to),
                'cost' => $ctx->is_bot ? 0 : $cost,
                'is_bot' => $ctx->is_bot ? 1 : 0,
            ]);
            if ($ctx->is_bot) {
                $hit_id = 0; // robô não gera token nem conversão
            } else {
                $ctx->last_hit_id = $hit_id;
            }
        }
        $can_convert = $counting && $ctx->visitor && !$ctx->is_bot;

        // A visita que começou apontando para um operador (A/B, condição…) ganha como "entrada" a página final.
        if ($ctx->session && !in_array($to->type, $operators, true) && $to->type !== 'script'
            && preg_match('/^(condition|rotator|distribution):\d+$/', (string) $ctx->session->landing)) {
            global $wpdb;
            $landing = self::describe_node($to);
            $wpdb->update(IWT_DB::t('sessions'), ['landing' => $landing], ['id' => (int) $ctx->session->id]);
            $ctx->session->landing = $landing;
        }

        // 3) Destino
        switch ($to->type) {
            case 'page':
                return self::finalize((string) ($to->config['url'] ?? ''), $link, $ctx);

            case 'thankyou':
                if ($can_convert && $funnel->goal === 'thankyou') {
                    IWT_Conversions::record_funnel_event('thankyou', $funnel, $to, $link, $hit_id, $ctx->visitor, $ctx->session);
                }
                return self::finalize((string) ($to->config['url'] ?? ''), $link, $ctx);

            case 'whatsapp':
                if ($can_convert && $funnel->goal === 'whatsapp') {
                    IWT_Conversions::record_funnel_event('whatsapp', $funnel, $to, $link, $hit_id, $ctx->visitor, $ctx->session);
                }
                return self::whatsapp_url($to->config, $ctx, $hit_id);

            case 'offer':
                $url = (string) ($to->config['url'] ?? '');
                if ($url === '') {
                    $url = (string) ($to->config['backup_url'] ?? '');
                }
                if ($url === '') {
                    return '';
                }
                $token = $hit_id ? IWT_Helpers::hit_token($hit_id) : ($ctx->visitor ? IWT_Helpers::visitor_token($ctx->visitor->uid) : '');
                $url = self::finalize($url, $link, $ctx, $token);
                $platform = (string) ($to->config['platform'] ?? '') ?: (string) $funnel->platform;
                $preset = $platform !== '' ? IWT_Platforms::get($platform) : null;
                if ($token !== '' && $preset) {
                    $add = [];
                    foreach ((array) $preset['params'] as $param) {
                        $add[$param] = $token;
                    }
                    // Sobrescreve: o código de rastreio precisa chegar intacto no checkout.
                    $url = IWT_Helpers::add_params($url, $add, true);
                }
                if ($can_convert && $hit_id && $funnel->goal === 'checkout') {
                    IWT_Meta_CAPI::maybe_queue_initiate_checkout($funnel, $ctx->visitor, $hit_id, $url);
                }
                return $url;

            case 'condition':
                $outs = IWT_Funnels::outgoing((int) $to->id);
                if (!$outs) {
                    return '';
                }
                $branch = self::evaluate_condition($to->config, $ctx) ? 'yes' : 'no';
                foreach ($outs as $out) {
                    if (($out->config['branch'] ?? 'yes') === $branch) {
                        return self::traverse($out, $ctx, $depth + 1);
                    }
                }
                return self::traverse($outs[0], $ctx, $depth + 1);

            case 'rotator':
                $outs = IWT_Funnels::outgoing((int) $to->id);
                $out = self::pick_weighted($outs, $to, $ctx);
                return $out ? self::traverse($out, $ctx, $depth + 1) : '';

            case 'distribution':
                $outs = IWT_Funnels::outgoing((int) $to->id);
                $out = self::pick_distribution($outs, $to);
                return $out ? self::traverse($out, $ctx, $depth + 1) : '';

            case 'script':
                self::render_script($to, $ctx);
                exit;
        }
        return '';
    }

    /** Placeholders, repasse de parâmetros, parâmetros extras e iwt_vid para outro domínio. */
    public static function finalize(string $url, object $link, object $ctx, string $token = ''): string
    {
        if ($url === '') {
            return '';
        }
        $url = self::replace_placeholders($url, $ctx, $token);
        $config = is_array($link->config) ? $link->config : [];
        if (!isset($config['keep_params']) || $config['keep_params']) {
            $url = IWT_Helpers::add_params($url, $ctx->params);
        }
        if (!empty($config['extra_params'])) {
            $extra = [];
            wp_parse_str(self::replace_placeholders((string) $config['extra_params'], $ctx, $token, false), $extra);
            $url = IWT_Helpers::add_params($url, $extra);
        }
        if ($ctx->visitor && IWT_Settings::get('pass_vid') && !IWT_Helpers::is_same_site(IWT_Helpers::host_of($url))) {
            $url = IWT_Helpers::add_params($url, ['iwt_vid' => $ctx->visitor->uid], true);
        }
        if ($ctx->test) {
            $url = IWT_Helpers::add_params($url, ['iwt_test' => '1'], true);
        }
        return $url;
    }

    /**
     * {iwt_vid} {iwt_token} {iwt_click} e qualquer parâmetro recebido: {utm_source}, {gclid}…
     * Placeholder sem valor vira vazio.
     */
    public static function replace_placeholders(string $text, object $ctx, string $token = '', bool $encode = true): string
    {
        if (strpos($text, '{') === false) {
            return $text;
        }
        $values = $ctx->params;
        $values['iwt_vid'] = $ctx->visitor ? $ctx->visitor->uid : '';
        $values['iwt_token'] = $token !== '' ? $token : ($ctx->visitor ? IWT_Helpers::visitor_token($ctx->visitor->uid) : '');
        $values['iwt_click'] = $ctx->last_hit_id ? IWT_Helpers::hit_token($ctx->last_hit_id) : '';
        return preg_replace_callback('/\{([a-zA-Z0-9_\-]{1,40})\}/', function ($m) use ($values, $encode) {
            $v = (string) ($values[$m[1]] ?? $values[strtolower($m[1])] ?? '');
            return $encode ? rawurlencode($v) : $v;
        }, $text);
    }

    public static function whatsapp_url(array $config, object $ctx, int $hit_id): string
    {
        $message = (string) ($config['message'] ?? '');
        $message = self::replace_placeholders($message, $ctx, '', false);
        if (!empty($config['append_code'])) {
            $code = $hit_id ? IWT_Helpers::hit_token($hit_id) : ($ctx->visitor ? IWT_Helpers::visitor_token($ctx->visitor->uid) : '');
            if ($code !== '') {
                $message = trim($message . ' (ref: ' . $code . ')');
            }
        }
        if (!empty($config['url'])) {
            return self::replace_placeholders((string) $config['url'], $ctx);
        }
        $phone = preg_replace('/\D/', '', (string) ($config['phone'] ?? ''));
        if ($phone === '') {
            return '';
        }
        return 'https://wa.me/' . $phone . ($message !== '' ? '?text=' . rawurlencode($message) : '');
    }

    public static function evaluate_condition(array $c, object $ctx): bool
    {
        $field = (string) ($c['field'] ?? 'param');
        $op = (string) ($c['operator'] ?? 'equals');
        $expected = strtolower(trim((string) ($c['value'] ?? '')));

        if ($field === 'param') {
            $name = (string) ($c['param'] ?? '');
            $actual = isset($ctx->params[$name]) ? (string) $ctx->params[$name] : null;
        } elseif ($field === 'channel') {
            $actual = $ctx->session ? (string) $ctx->session->channel
                : IWT_Sources::classify(['params' => $ctx->params, 'referrer' => $ctx->props['referrer'], 'in_app' => $ctx->props['in_app']])['channel'];
        } else {
            $actual = (string) IWT_Request::property($field);
        }
        $a = strtolower(trim((string) $actual));
        $list = array_filter(array_map('trim', explode(',', $expected)), 'strlen');

        switch ($op) {
            case 'exists':
                return $actual !== null && $a !== '';
            case 'not_exists':
                return $actual === null || $a === '';
            case 'equals':
                return $a === $expected;
            case 'not_equals':
                return $a !== $expected;
            case 'contains':
                return $expected !== '' && strpos($a, $expected) !== false;
            case 'not_contains':
                return $expected === '' || strpos($a, $expected) === false;
            case 'in':
                return in_array($a, $list, true);
            case 'not_in':
                return !in_array($a, $list, true);
            case 'gt':
                return is_numeric($a) && is_numeric($expected) && (float) $a > (float) $expected;
            case 'lt':
                return is_numeric($a) && is_numeric($expected) && (float) $a < (float) $expected;
        }
        return false;
    }

    /** Teste A/B por peso. "Fixar variação": o mesmo visitante sempre cai na mesma saída (hash, sem consulta). */
    public static function pick_weighted(array $outs, object $node, object $ctx): ?object
    {
        if (!$outs) {
            return null;
        }
        $weights = [];
        $total = 0;
        foreach ($outs as $i => $out) {
            $w = isset($out->config['weight']) ? max(0, (int) $out->config['weight']) : 50;
            $weights[$i] = $w;
            $total += $w;
        }
        if ($total <= 0) {
            $weights = array_fill(0, count($outs), 1);
            $total = count($outs);
        }
        $sticky = !isset($node->config['sticky']) || $node->config['sticky'];
        if ($sticky && $ctx->visitor) {
            $roll = (crc32($ctx->visitor->uid . ':' . $node->id) % $total) + 1;
        } else {
            $roll = wp_rand(1, $total);
        }
        $acc = 0;
        foreach ($outs as $i => $out) {
            $acc += $weights[$i];
            if ($roll <= $acc) {
                return $out;
            }
        }
        return end($outs) ?: null;
    }

    /** Distribuição: N acessos por saída (sequencial) ou sempre para a que tem menos acessos (equilibrado). */
    public static function pick_distribution(array $outs, object $node): ?object
    {
        global $wpdb;
        if (!$outs) {
            return null;
        }
        $ids = array_map(function ($o) {
            return (int) $o->id;
        }, $outs);
        $placeholders = implode(',', array_fill(0, count($ids), '%d'));
        $counts = $wpdb->get_results($wpdb->prepare(
            'SELECT link_id, COUNT(*) AS n FROM ' . IWT_DB::t('hits') . " WHERE link_id IN ($placeholders) AND is_bot = 0 GROUP BY link_id",
            $ids
        ), OBJECT_K);
        $mode = $node->config['mode'] ?? 'sequential';
        $available = [];
        $default = null;
        foreach ($outs as $out) {
            $n = isset($counts[$out->id]) ? (int) $counts[$out->id]->n : 0;
            $limit = (int) ($out->config['limit'] ?? 0);
            if (!empty($out->config['is_default'])) {
                $default = $out;
            }
            if ($limit === 0 || $n < $limit) {
                $available[] = ['out' => $out, 'n' => $n];
            }
        }
        if (!$available) {
            return $default ?: end($outs);
        }
        if ($mode === 'balanced') {
            usort($available, function ($a, $b) {
                return $a['n'] <=> $b['n'];
            });
        }
        return $available[0]['out'];
    }

    /** Página intermediária: roda o código configurado e segue para o próximo link do funil. */
    public static function render_script(object $node, object $ctx): void
    {
        $outs = IWT_Funnels::outgoing((int) $node->id);
        $next = $outs ? IWT_Funnels::link_url($outs[0]) : self::fallback_url();
        $params = $ctx->params;
        if ($ctx->test) {
            $params['iwt_test'] = '1';
        }
        $next = IWT_Helpers::add_params($next, $params);
        $delay = (int) ($node->config['delay'] ?? 800);
        $message = (string) ($node->config['message'] ?? '');

        status_header(200);
        header('Content-Type: text/html; charset=utf-8');
        echo '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="robots" content="noindex,nofollow">';
        echo '<meta name="viewport" content="width=device-width,initial-scale=1"><title>' . esc_html($message ?: get_bloginfo('name')) . '</title>';
        echo '<style>body{margin:0;min-height:100vh;display:grid;place-items:center;font:16px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#333;background:#fafafa}</style></head><body>';
        echo '<p>' . esc_html($message) . '</p>';
        // Código configurado por usuário com unfiltered_html (validado em IWT_Funnels::save_graph).
        echo (string) ($node->config['code'] ?? ''); // phpcs:ignore WordPress.Security.EscapeOutput
        echo '<script>setTimeout(function(){window.location.replace(' . wp_json_encode($next) . ');},' . $delay . ');</script>';
        echo '<noscript><meta http-equiv="refresh" content="0;url=' . esc_attr($next) . '"></noscript>';
        echo '</body></html>';
    }

    /** Resumo do destino para gravar no hit/landing: host + path (ou wa.me/número). */
    public static function describe_node(object $node): string
    {
        $c = is_array($node->config) ? $node->config : [];
        switch ($node->type) {
            case 'page':
            case 'thankyou':
            case 'offer':
                $u = (string) ($c['url'] ?? '');
                $host = IWT_Helpers::host_of($u);
                $path = (string) wp_parse_url($u, PHP_URL_PATH);
                return IWT_Helpers::truncate($host . ($path ?: '/'), 255);
            case 'whatsapp':
                return 'wa.me/' . ($c['phone'] ?? '');
        }
        return $node->type . ':' . $node->id;
    }

    private static function funnel_hosts(object $ctx): array
    {
        if ($ctx->funnel_hosts !== null) {
            return $ctx->funnel_hosts;
        }
        global $wpdb;
        $rows = $wpdb->get_col($wpdb->prepare(
            'SELECT config FROM ' . IWT_DB::t('nodes') . " WHERE funnel_id = %d AND type IN ('page','thankyou','offer')",
            (int) $ctx->funnel->id
        ));
        $hosts = [];
        foreach ($rows as $config) {
            $c = IWT_Helpers::json_decode_array($config);
            if (!empty($c['url'])) {
                $hosts[] = IWT_Helpers::host_of($c['url']);
            }
        }
        $ctx->funnel_hosts = array_values(array_unique(array_filter($hosts)));
        return $ctx->funnel_hosts;
    }

    public static function fallback_url(): string
    {
        $url = (string) IWT_Settings::get('fallback_url');
        return $url !== '' ? $url : home_url('/');
    }

    public static function redirect(string $url, int $code): void
    {
        if (!in_array($code, [301, 302, 303, 307], true)) {
            $code = 302;
        }
        // wp_redirect (não wp_safe_redirect): o destino é externo por natureza e vem só da configuração do funil.
        wp_redirect($url, $code, 'INOVAWEB Tracking'); // phpcs:ignore WordPress.Security.SafeRedirect
        exit;
    }
}
