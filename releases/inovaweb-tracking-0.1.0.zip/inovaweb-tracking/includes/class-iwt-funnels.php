<?php
/**
 * Funis: cadastro, nós, links e salvamento do grafo vindo do editor visual.
 *
 * Modelo (inspirado no Smart Funnel): o funil é um grafo. NÓS são etapas (fonte de tráfego,
 * página, checkout, obrigado, WhatsApp, condição, teste A/B, distribuição, script). LINKS ligam
 * dois nós e cada link é uma URL rastreável: /{prefixo}/{id ou alias}. Quem acessa o link é
 * registrado e redirecionado conforme o tipo do nó de destino.
 *
 * Links e nós removidos no editor são apenas marcados (deleted=1) e CONTINUAM redirecionando,
 * para não quebrar anúncios que ainda usam a URL antiga.
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_Funnels
{
    /** Objetivo do funil = o que conta como conversão. Escolhido ao criar o funil. */
    public static function goals(): array
    {
        return [
            'checkout' => ['label' => 'Venda no checkout', 'help' => 'A venda volta pelo webhook da plataforma (Hotmart, Kiwify, Eduzz…) ou pelo pedido do WooCommerce.'],
            'thankyou' => ['label' => 'Página de obrigado', 'help' => 'Conta quando o visitante chega na página de obrigado do funil.'],
            'whatsapp' => ['label' => 'Contato no WhatsApp', 'help' => 'Conta quando o visitante passa pelo link de WhatsApp do funil.'],
        ];
    }

    public static function node_types(): array
    {
        return [
            'source'       => ['label' => 'Fonte de tráfego', 'help' => 'Onde o link será divulgado (anúncio, bio, e-mail…). Sempre o começo do funil.'],
            'page'         => ['label' => 'Página', 'help' => 'Landing page, advertorial, VSL, página de vendas.'],
            'offer'        => ['label' => 'Checkout', 'help' => 'Link de pagamento. O plugin acrescenta o código de rastreio que volta no webhook.'],
            'thankyou'     => ['label' => 'Página de obrigado', 'help' => 'Chegar aqui conta como conversão nos funis de "Página de obrigado".'],
            'whatsapp'     => ['label' => 'WhatsApp', 'help' => 'Abre conversa no WhatsApp. Conta como conversão nos funis de "Contato no WhatsApp".'],
            'condition'    => ['label' => 'Condição', 'help' => 'Divide o tráfego por regra (dispositivo, país, parâmetro da URL…): saída SIM e NÃO.'],
            'rotator'      => ['label' => 'Teste A/B', 'help' => 'Divide o tráfego por porcentagem entre as saídas.'],
            'distribution' => ['label' => 'Distribuição', 'help' => 'Envia N acessos para cada saída, em sequência ou equilibrando.'],
            'script'       => ['label' => 'Página com script', 'help' => 'Página intermediária que roda um código (pixel, tag) e segue para a próxima etapa.'],
        ];
    }

    const CONDITION_FIELDS = ['param', 'device', 'os', 'browser', 'country', 'language', 'referrer', 'hour', 'weekday', 'in_app', 'channel'];
    const CONDITION_OPERATORS = ['equals', 'not_equals', 'contains', 'not_contains', 'in', 'not_in', 'exists', 'not_exists', 'gt', 'lt'];

    /* ---------------------------------------------------------------- leitura */

    public static function get(int $id): ?object
    {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . IWT_DB::t('funnels') . ' WHERE id = %d', $id));
        if (!$row) {
            return null;
        }
        $row->settings = IWT_Helpers::json_decode_array($row->settings);
        return $row;
    }

    public static function all(bool $include_archived = false): array
    {
        global $wpdb;
        $where = 'deleted_at IS NULL' . ($include_archived ? '' : " AND status <> 'archived'");
        $rows = $wpdb->get_results('SELECT * FROM ' . IWT_DB::t('funnels') . " WHERE $where ORDER BY updated_at DESC");
        foreach ($rows as $row) {
            $row->settings = IWT_Helpers::json_decode_array($row->settings);
        }
        return $rows;
    }

    public static function get_node(int $id): ?object
    {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . IWT_DB::t('nodes') . ' WHERE id = %d', $id));
        if ($row) {
            $row->config = IWT_Helpers::json_decode_array($row->config);
        }
        return $row ?: null;
    }

    public static function get_link(int $id): ?object
    {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . IWT_DB::t('links') . ' WHERE id = %d', $id));
        if ($row) {
            $row->config = IWT_Helpers::json_decode_array($row->config);
        }
        return $row ?: null;
    }

    /** Link pelo que vem na URL: número (id) ou alias. Inclui removidos (ver nota no topo). */
    public static function find_link_by_key(string $key): ?object
    {
        global $wpdb;
        $key = trim(strtolower($key), "/ \t\n");
        if ($key === '') {
            return null;
        }
        if (ctype_digit($key)) {
            return self::get_link((int) $key);
        }
        // Alias: ativos primeiro.
        $id = $wpdb->get_var($wpdb->prepare(
            'SELECT id FROM ' . IWT_DB::t('links') . ' WHERE alias = %s ORDER BY deleted ASC, id DESC LIMIT 1',
            sanitize_title($key)
        ));
        return $id ? self::get_link((int) $id) : null;
    }

    /** Saídas de um nó (links ativos; se não houver nenhum ativo, usa os removidos para não quebrar o fluxo). */
    public static function outgoing(int $node_id): array
    {
        global $wpdb;
        $rows = $wpdb->get_results($wpdb->prepare(
            'SELECT * FROM ' . IWT_DB::t('links') . ' WHERE from_node_id = %d AND deleted = 0 ORDER BY id ASC',
            $node_id
        ));
        if (!$rows) {
            $rows = $wpdb->get_results($wpdb->prepare(
                'SELECT * FROM ' . IWT_DB::t('links') . ' WHERE from_node_id = %d ORDER BY id DESC',
                $node_id
            ));
        }
        foreach ($rows as $row) {
            $row->config = IWT_Helpers::json_decode_array($row->config);
        }
        return $rows;
    }

    /** Grafo completo para o editor. */
    public static function graph(int $funnel_id): ?array
    {
        global $wpdb;
        $funnel = self::get($funnel_id);
        if (!$funnel) {
            return null;
        }
        $nodes = $wpdb->get_results($wpdb->prepare(
            'SELECT * FROM ' . IWT_DB::t('nodes') . ' WHERE funnel_id = %d AND deleted = 0 ORDER BY id ASC',
            $funnel_id
        ));
        $links = $wpdb->get_results($wpdb->prepare(
            'SELECT * FROM ' . IWT_DB::t('links') . ' WHERE funnel_id = %d AND deleted = 0 ORDER BY id ASC',
            $funnel_id
        ));
        return [
            'funnel' => self::export_funnel($funnel),
            'nodes' => array_map(function ($n) {
                return [
                    'id' => (int) $n->id,
                    'type' => $n->type,
                    'name' => $n->name,
                    'config' => IWT_Helpers::json_decode_array($n->config),
                    'x' => (int) $n->pos_x,
                    'y' => (int) $n->pos_y,
                ];
            }, $nodes),
            'links' => array_map(function ($l) {
                return [
                    'id' => (int) $l->id,
                    'from' => (int) $l->from_node_id,
                    'to' => (int) $l->to_node_id,
                    'alias' => $l->alias,
                    'config' => IWT_Helpers::json_decode_array($l->config),
                    'url' => self::link_url($l),
                ];
            }, $links),
        ];
    }

    public static function export_funnel(object $f): array
    {
        return [
            'id' => (int) $f->id,
            'name' => $f->name,
            'status' => $f->status,
            'goal' => $f->goal,
            'platform' => $f->platform,
            'currency' => $f->currency,
            'settings' => is_array($f->settings) ? $f->settings : IWT_Helpers::json_decode_array($f->settings),
            'created_at' => IWT_Helpers::to_local_iso($f->created_at),
            'updated_at' => IWT_Helpers::to_local_iso($f->updated_at),
        ];
    }

    /** URL pública do link. Com links permanentes desligados usa ?iwt_go= (funciona em qualquer servidor). */
    public static function link_url($link): string
    {
        $key = (is_object($link) && $link->alias !== '') ? $link->alias : (string) (is_object($link) ? $link->id : $link);
        if (get_option('permalink_structure')) {
            return home_url('/' . IWT_Settings::route_prefix() . '/' . $key);
        }
        return add_query_arg('iwt_go', $key, home_url('/'));
    }

    /* ---------------------------------------------------------------- escrita */

    public static function create(array $data): int
    {
        global $wpdb;
        $now = IWT_Helpers::now();
        $clean = self::sanitize_funnel($data);
        $wpdb->insert(IWT_DB::t('funnels'), $clean + ['created_at' => $now, 'updated_at' => $now]);
        $id = (int) $wpdb->insert_id;
        if (!$id) {
            error_log('[INOVAWEB Tracking] Falha ao criar funil: ' . $wpdb->last_error);
            return 0;
        }

        // Funil novo já nasce com um esqueleto coerente com o objetivo escolhido.
        if (!empty($data['with_template'])) {
            self::apply_template($id, $clean['goal'], $clean['platform']);
        }
        return $id;
    }

    public static function sanitize_funnel(array $data): array
    {
        $goal = isset($data['goal'], self::goals()[$data['goal']]) ? $data['goal'] : 'checkout';
        $platform = sanitize_key((string) ($data['platform'] ?? ''));
        if ($goal === 'checkout' && !isset(IWT_Platforms::all()[$platform])) {
            $platform = 'hotmart';
        }
        if ($goal !== 'checkout') {
            $platform = '';
        }
        $status = (string) ($data['status'] ?? 'active');
        $status = in_array($status, ['active', 'paused', 'archived'], true) ? $status : 'active';
        $currency = strtoupper(preg_replace('/[^A-Za-z]/', '', (string) ($data['currency'] ?? IWT_Settings::get('currency'))));
        $settings = is_array($data['settings'] ?? null) ? $data['settings'] : [];
        $clean_settings = [
            // Padrão ligado: com o Meta configurado em Integrações, todo funil envia, salvo se desmarcado no funil.
            'capi_enabled' => array_key_exists('capi_enabled', $settings) ? (bool) $settings['capi_enabled'] : true,
            'capi_event' => sanitize_text_field((string) ($settings['capi_event'] ?? '')),
            'capi_pixel_id' => preg_replace('/\D/', '', (string) ($settings['capi_pixel_id'] ?? '')),
            'product_ids' => sanitize_text_field((string) ($settings['product_ids'] ?? '')),
            // Valor estimado de cada lead/contato (funis de obrigado e WhatsApp), para calcular ROAS/CPA.
            'lead_value' => max(0, IWT_Helpers::parse_money($settings['lead_value'] ?? 0)),
            'notes' => sanitize_textarea_field((string) ($settings['notes'] ?? '')),
        ];
        return [
            'name' => IWT_Helpers::clean_text($data['name'] ?? 'Novo funil', 191) ?: 'Novo funil',
            'status' => $status,
            'goal' => $goal,
            'platform' => $platform,
            'currency' => strlen($currency) === 3 ? $currency : 'BRL',
            'settings' => wp_json_encode($clean_settings),
        ];
    }

    private static function apply_template(int $funnel_id, string $goal, string $platform): void
    {
        $nodes = [
            ['tmp' => 'a', 'type' => 'source', 'name' => 'Meta Ads', 'config' => ['platform' => 'meta_ads'], 'x' => 40, 'y' => 160],
            ['tmp' => 'b', 'type' => 'page', 'name' => 'Landing page', 'config' => ['url' => home_url('/')], 'x' => 380, 'y' => 160],
        ];
        $links = [['from' => 'a', 'to' => 'b', 'config' => []]];
        if ($goal === 'checkout') {
            $nodes[] = ['tmp' => 'c', 'type' => 'offer', 'name' => 'Checkout', 'config' => ['url' => '', 'platform' => $platform], 'x' => 720, 'y' => 160];
            $links[] = ['from' => 'b', 'to' => 'c', 'config' => []];
        } elseif ($goal === 'thankyou') {
            $nodes[] = ['tmp' => 'c', 'type' => 'thankyou', 'name' => 'Obrigado', 'config' => ['url' => ''], 'x' => 720, 'y' => 160];
            $links[] = ['from' => 'b', 'to' => 'c', 'config' => []];
        } else {
            $nodes[] = ['tmp' => 'c', 'type' => 'whatsapp', 'name' => 'WhatsApp', 'config' => ['phone' => '', 'message' => 'Olá! Vim pelo site.'], 'x' => 720, 'y' => 160];
            $links[] = ['from' => 'b', 'to' => 'c', 'config' => []];
        }
        $funnel = self::get($funnel_id);
        self::save_graph($funnel_id, ['funnel' => (array) self::export_funnel($funnel), 'nodes' => array_map(function ($n) {
            return ['id' => $n['tmp'], 'type' => $n['type'], 'name' => $n['name'], 'config' => $n['config'], 'x' => $n['x'], 'y' => $n['y']];
        }, $nodes), 'links' => array_map(function ($l) {
            return ['id' => 'l' . $l['from'] . $l['to'], 'from' => $l['from'], 'to' => $l['to'], 'config' => $l['config']];
        }, $links)], true);
    }

    /**
     * Salva o grafo inteiro enviado pelo editor.
     * Nós/links novos chegam com id temporário (string); a resposta devolve o mapa tmp → id real.
     *
     * @return array{ok:bool,errors:array,map:array}
     */
    public static function save_graph(int $funnel_id, array $payload, bool $allow_unfiltered = false): array
    {
        global $wpdb;
        $funnel = self::get($funnel_id);
        if (!$funnel) {
            return ['ok' => false, 'errors' => ['Funil não encontrado.'], 'map' => []];
        }
        $now = IWT_Helpers::now();
        $errors = [];
        $can_script = $allow_unfiltered || current_user_can('unfiltered_html');

        // 1) Dados do funil
        if (isset($payload['funnel']) && is_array($payload['funnel'])) {
            $clean = self::sanitize_funnel(array_merge(self::export_funnel($funnel), $payload['funnel']));
            $wpdb->update(IWT_DB::t('funnels'), $clean + ['updated_at' => $now], ['id' => $funnel_id]);
        } else {
            $wpdb->update(IWT_DB::t('funnels'), ['updated_at' => $now], ['id' => $funnel_id]);
        }

        // 2) Nós
        $existing_nodes = $wpdb->get_results($wpdb->prepare(
            'SELECT id, type, config FROM ' . IWT_DB::t('nodes') . ' WHERE funnel_id = %d AND deleted = 0',
            $funnel_id
        ), OBJECT_K);
        $map = [];
        $types = [];
        $kept_nodes = [];
        foreach ((array) ($payload['nodes'] ?? []) as $n) {
            if (!is_array($n) || !isset(self::node_types()[$n['type'] ?? ''])) {
                continue;
            }
            $config = self::sanitize_node_config((string) $n['type'], (array) ($n['config'] ?? []), $can_script, $errors, (string) ($n['name'] ?? ''));
            $row = [
                'type' => $n['type'],
                'name' => IWT_Helpers::clean_text($n['name'] ?? '', 191),
                'config' => wp_json_encode($config),
                'pos_x' => (int) ($n['x'] ?? 0),
                'pos_y' => (int) ($n['y'] ?? 0),
                'updated_at' => $now,
            ];
            $id = $n['id'] ?? '';
            if (is_numeric($id) && isset($existing_nodes[(int) $id])) {
                // Script só pode ser alterado por quem tem unfiltered_html; senão mantém o código salvo.
                if ($n['type'] === 'script' && !$can_script) {
                    $old = IWT_Helpers::json_decode_array($existing_nodes[(int) $id]->config);
                    $config['code'] = $old['code'] ?? '';
                    $row['config'] = wp_json_encode($config);
                }
                $wpdb->update(IWT_DB::t('nodes'), $row, ['id' => (int) $id, 'funnel_id' => $funnel_id]);
                $real = (int) $id;
            } else {
                $wpdb->insert(IWT_DB::t('nodes'), $row + ['funnel_id' => $funnel_id, 'created_at' => $now]);
                $real = (int) $wpdb->insert_id;
            }
            $map[(string) $id] = $real;
            $types[$real] = $n['type'];
            $kept_nodes[] = $real;
        }
        foreach (array_keys($existing_nodes) as $old_id) {
            if (!in_array((int) $old_id, $kept_nodes, true)) {
                $wpdb->update(IWT_DB::t('nodes'), ['deleted' => 1, 'updated_at' => $now], ['id' => (int) $old_id]);
            }
        }

        // 3) Links
        $existing_links = $wpdb->get_results($wpdb->prepare(
            'SELECT id FROM ' . IWT_DB::t('links') . ' WHERE funnel_id = %d AND deleted = 0',
            $funnel_id
        ), OBJECT_K);
        $kept_links = [];
        $seen_pairs = [];
        foreach ((array) ($payload['links'] ?? []) as $l) {
            if (!is_array($l)) {
                continue;
            }
            $from = $map[(string) ($l['from'] ?? '')] ?? 0;
            $to = $map[(string) ($l['to'] ?? '')] ?? 0;
            if (!$from || !$to || $from === $to) {
                continue;
            }
            if ($types[$to] === 'source') {
                $errors[] = 'Uma fonte de tráfego não pode receber conexões (ela é sempre o começo do funil).';
                continue;
            }
            $config = self::sanitize_link_config((array) ($l['config'] ?? []), $types[$from]);
            $pair = $from . '-' . $to . '-' . ($config['branch'] ?? '');
            if (isset($seen_pairs[$pair])) {
                continue;
            }
            $seen_pairs[$pair] = true;

            $id = $l['id'] ?? '';
            $alias = self::sanitize_alias((string) ($l['alias'] ?? ''), is_numeric($id) ? (int) $id : 0, $errors);
            $row = [
                'from_node_id' => $from,
                'to_node_id' => $to,
                'alias' => $alias,
                'config' => wp_json_encode($config),
                'updated_at' => $now,
            ];
            if (is_numeric($id) && isset($existing_links[(int) $id])) {
                $wpdb->update(IWT_DB::t('links'), $row, ['id' => (int) $id, 'funnel_id' => $funnel_id]);
                $real = (int) $id;
            } else {
                $wpdb->insert(IWT_DB::t('links'), $row + ['funnel_id' => $funnel_id, 'created_at' => $now]);
                $real = (int) $wpdb->insert_id;
            }
            $map[(string) $id] = $real;
            $kept_links[] = $real;
        }
        foreach (array_keys($existing_links) as $old_id) {
            if (!in_array((int) $old_id, $kept_links, true)) {
                $wpdb->update(IWT_DB::t('links'), ['deleted' => 1, 'updated_at' => $now], ['id' => (int) $old_id]);
            }
        }

        self::flush_cache();
        return ['ok' => true, 'errors' => array_values(array_unique($errors)), 'map' => $map];
    }

    public static function sanitize_alias(string $alias, int $link_id, array &$errors): string
    {
        global $wpdb;
        $alias = sanitize_title($alias);
        if ($alias === '') {
            return '';
        }
        if (ctype_digit($alias) || strlen($alias) < 2) {
            $errors[] = "O apelido \"$alias\" precisa ter letras (números puros são reservados para o ID do link).";
            return '';
        }
        $alias = substr($alias, 0, 100);
        $taken = $wpdb->get_var($wpdb->prepare(
            'SELECT id FROM ' . IWT_DB::t('links') . ' WHERE alias = %s AND deleted = 0 AND id <> %d LIMIT 1',
            $alias,
            $link_id
        ));
        if ($taken) {
            $errors[] = "O apelido \"$alias\" já está em uso por outro link.";
            return '';
        }
        return $alias;
    }

    public static function sanitize_node_config(string $type, array $c, bool $can_script, array &$errors, string $name = ''): array
    {
        $url = function ($v) {
            return self::sanitize_url_with_placeholders((string) $v);
        };
        $label = $name !== '' ? "\"$name\"" : '';
        switch ($type) {
            case 'source':
                $platform = sanitize_key((string) ($c['platform'] ?? 'other'));
                $platforms = IWT_Sources::platforms();
                return [
                    'platform' => isset($platforms[$platform]) ? $platform : 'other',
                    'paid' => isset($c['paid']) ? (bool) $c['paid'] : (bool) ($platforms[$platform]['paid'] ?? false),
                    'cpc' => max(0, IWT_Helpers::parse_money($c['cpc'] ?? 0)),
                    'cost_param' => sanitize_key((string) ($c['cost_param'] ?? '')),
                    'bot_filter' => !empty($c['bot_filter']),
                ];
            case 'page':
            case 'thankyou':
                $u = $url($c['url'] ?? '');
                if ($u === '') {
                    $errors[] = "Informe a URL da etapa $label.";
                }
                return ['url' => $u, 'match' => in_array($c['match'] ?? 'path', ['path', 'prefix', 'exact'], true) ? ($c['match'] ?? 'path') : 'path'];
            case 'offer':
                $u = $url($c['url'] ?? '');
                if ($u === '') {
                    $errors[] = "Informe a URL do checkout $label.";
                }
                $platform = sanitize_key((string) ($c['platform'] ?? ''));
                return [
                    'url' => $u,
                    'platform' => isset(IWT_Platforms::all()[$platform]) ? $platform : '',
                    'product_id' => sanitize_text_field((string) ($c['product_id'] ?? '')),
                    'backup_url' => $url($c['backup_url'] ?? ''),
                ];
            case 'whatsapp':
                $phone = preg_replace('/\D/', '', (string) ($c['phone'] ?? ''));
                $custom = $url($c['url'] ?? '');
                if ($phone === '' && $custom === '') {
                    $errors[] = "Informe o número de WhatsApp $label.";
                }
                return [
                    'phone' => IWT_Helpers::normalize_phone($phone),
                    'message' => sanitize_textarea_field((string) ($c['message'] ?? '')),
                    'url' => $custom,
                    'append_code' => !empty($c['append_code']),
                ];
            case 'condition':
                $field = in_array($c['field'] ?? '', self::CONDITION_FIELDS, true) ? $c['field'] : 'param';
                $op = in_array($c['operator'] ?? '', self::CONDITION_OPERATORS, true) ? $c['operator'] : 'equals';
                return [
                    'field' => $field,
                    'param' => sanitize_key((string) ($c['param'] ?? '')),
                    'operator' => $op,
                    'value' => sanitize_text_field((string) ($c['value'] ?? '')),
                ];
            case 'rotator':
                return ['sticky' => !isset($c['sticky']) || (bool) $c['sticky']];
            case 'distribution':
                return ['mode' => ($c['mode'] ?? '') === 'balanced' ? 'balanced' : 'sequential'];
            case 'script':
                return [
                    // Sem unfiltered_html o código é descartado aqui e o salvo é mantido em save_graph().
                    'code' => $can_script ? (string) ($c['code'] ?? '') : '',
                    'delay' => max(0, min(10000, (int) ($c['delay'] ?? 800))),
                    'message' => sanitize_text_field((string) ($c['message'] ?? 'Carregando…')),
                ];
        }
        return [];
    }

    /** esc_url_raw() apaga "{" e "}": protege os placeholders {param} antes e restaura depois. */
    public static function sanitize_url_with_placeholders(string $v): string
    {
        $v = trim($v);
        if ($v === '') {
            return '';
        }
        $v = preg_match('#^https?://#i', $v) ? $v : 'https://' . ltrim($v, '/');
        $v = preg_replace('/\{([a-z0-9_\-]{1,40})\}/i', 'IWTPH0$1IWTPH1', $v);
        $v = esc_url_raw($v, ['http', 'https']);
        return preg_replace('/IWTPH0([a-z0-9_\-]{1,40})IWTPH1/i', '{$1}', $v);
    }

    public static function sanitize_link_config(array $c, string $from_type): array
    {
        $out = [
            'keep_params' => !isset($c['keep_params']) || (bool) $c['keep_params'],
            'extra_params' => sanitize_text_field((string) ($c['extra_params'] ?? '')),
            'label' => IWT_Helpers::clean_text($c['label'] ?? '', 60),
        ];
        if ($from_type === 'condition') {
            $out['branch'] = ($c['branch'] ?? 'yes') === 'no' ? 'no' : 'yes';
        }
        if ($from_type === 'rotator') {
            $out['weight'] = max(0, min(100, (int) ($c['weight'] ?? 50)));
        }
        if ($from_type === 'distribution') {
            $out['limit'] = max(0, (int) ($c['limit'] ?? 100));
            $out['is_default'] = !empty($c['is_default']);
        }
        return $out;
    }

    public static function set_status(int $id, string $status): void
    {
        global $wpdb;
        if (!in_array($status, ['active', 'paused', 'archived'], true)) {
            return;
        }
        $wpdb->update(IWT_DB::t('funnels'), ['status' => $status, 'updated_at' => IWT_Helpers::now()], ['id' => $id]);
        self::flush_cache();
    }

    /** Exclusão lógica: some das listas; links continuam redirecionando. */
    public static function delete(int $id): void
    {
        global $wpdb;
        $wpdb->update(IWT_DB::t('funnels'), ['deleted_at' => IWT_Helpers::now(), 'status' => 'archived'], ['id' => $id]);
        self::flush_cache();
    }

    public static function duplicate(int $id): int
    {
        $graph = self::graph($id);
        if (!$graph) {
            return 0;
        }
        $data = $graph['funnel'];
        $data['name'] = $data['name'] . ' (cópia)';
        $new_id = self::create($data);
        $payload = [
            'nodes' => array_map(function ($n) {
                $n['id'] = 'n' . $n['id'];
                return $n;
            }, $graph['nodes']),
            'links' => array_map(function ($l) {
                return ['id' => 'l' . $l['id'], 'from' => 'n' . $l['from'], 'to' => 'n' . $l['to'], 'alias' => '', 'config' => $l['config']];
            }, $graph['links']),
        ];
        self::save_graph($new_id, $payload, current_user_can('unfiltered_html'));
        return $new_id;
    }

    /* ------------------------------------------------- cache de páginas de obrigado */

    /**
     * Páginas de obrigado de funis ativos, para o coletor reconhecer a visita como conversão.
     * @return array<int,array{funnel_id:int,node_id:int,host:string,path:string,match:string}>
     */
    public static function thankyou_targets(): array
    {
        $cached = get_transient('iwt_thankyou_targets');
        if (is_array($cached)) {
            return $cached;
        }
        global $wpdb;
        $rows = $wpdb->get_results(
            'SELECT n.id, n.funnel_id, n.config FROM ' . IWT_DB::t('nodes') . ' n JOIN ' . IWT_DB::t('funnels') . " f ON f.id = n.funnel_id
             WHERE n.type = 'thankyou' AND n.deleted = 0 AND f.deleted_at IS NULL AND f.status = 'active' AND f.goal = 'thankyou'"
        );
        $out = [];
        foreach ($rows as $row) {
            $c = IWT_Helpers::json_decode_array($row->config);
            if (empty($c['url'])) {
                continue;
            }
            $out[] = [
                'funnel_id' => (int) $row->funnel_id,
                'node_id' => (int) $row->id,
                'host' => IWT_Helpers::host_of($c['url']),
                'path' => untrailingslashit((string) wp_parse_url($c['url'], PHP_URL_PATH)) ?: '/',
                'match' => $c['match'] ?? 'path',
                'url' => $c['url'],
            ];
        }
        set_transient('iwt_thankyou_targets', $out, HOUR_IN_SECONDS);
        return $out;
    }

    /**
     * Páginas (nó "page") de funis ativos: host + caminho → funil.
     * Usado pelo coletor para que uma visita que cai direto numa página do funil (sem passar
     * por link /go/) também conte como visita daquele funil.
     * @return array<string,int>
     */
    public static function page_targets(): array
    {
        $cached = get_transient('iwt_page_targets');
        if (is_array($cached)) {
            return $cached;
        }
        global $wpdb;
        $rows = $wpdb->get_results(
            'SELECT n.funnel_id, n.config FROM ' . IWT_DB::t('nodes') . ' n JOIN ' . IWT_DB::t('funnels') . " f ON f.id = n.funnel_id
             WHERE n.type = 'page' AND n.deleted = 0 AND f.deleted_at IS NULL AND f.status = 'active' ORDER BY f.updated_at DESC"
        );
        $out = [];
        foreach ($rows as $row) {
            $c = IWT_Helpers::json_decode_array($row->config);
            if (empty($c['url']) || strpos((string) $c['url'], '{') !== false) {
                continue;
            }
            $key = self::page_key((string) $c['url']);
            if ($key !== '' && !isset($out[$key])) {
                $out[$key] = (int) $row->funnel_id;
            }
        }
        set_transient('iwt_page_targets', $out, HOUR_IN_SECONDS);
        return $out;
    }

    public static function page_key(string $url): string
    {
        $host = IWT_Helpers::host_of($url);
        if ($host === '') {
            return '';
        }
        return $host . (untrailingslashit((string) wp_parse_url($url, PHP_URL_PATH)) ?: '/');
    }

    public static function flush_cache(): void
    {
        delete_transient('iwt_thankyou_targets');
        delete_transient('iwt_page_targets');
    }
}
