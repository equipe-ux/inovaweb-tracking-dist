<?php
/**
 * Atualizador: faz o WordPress mostrar "Atualização disponível" para este plugin em todos os sites.
 *
 * Fluxo: tag vX.Y.Z no repositório privado → GitHub Actions publica o zip + update.json no
 * repositório PÚBLICO equipe-ux/inovaweb-tracking-dist → cada site consulta o update.json
 * (a cada 12h, junto com as atualizações do WordPress) e oferece a atualização em Plugins.
 * Nenhum token fica guardado nos sites.
 *
 * Usa o mecanismo nativo do WordPress 5.8+: header "Update URI" + filtro update_plugins_{host}.
 * Para trocar a origem (ex.: servidor próprio da INOVAWEB), defina no wp-config.php:
 *   define('IWT_UPDATE_MANIFEST', 'https://…/update.json');
 * O host do manifesto precisa ser o mesmo do "Update URI" do header do plugin, ou o filtro não dispara.
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_Updater
{
    const DEFAULT_MANIFEST = 'https://raw.githubusercontent.com/equipe-ux/inovaweb-tracking-dist/main/update.json';
    const CACHE_KEY = 'iwt_update_manifest';

    public static function init(): void
    {
        $host = (string) wp_parse_url(self::manifest_url(), PHP_URL_HOST);
        add_filter('update_plugins_' . $host, [__CLASS__, 'check'], 10, 4);
        add_filter('plugins_api', [__CLASS__, 'details'], 20, 3);
        add_action('upgrader_process_complete', [__CLASS__, 'clear_cache'], 10, 0);
        add_filter('plugin_row_meta', [__CLASS__, 'row_meta'], 10, 2);
        add_action('admin_init', [__CLASS__, 'maybe_force_check']);
    }

    public static function manifest_url(): string
    {
        return defined('IWT_UPDATE_MANIFEST') && IWT_UPDATE_MANIFEST ? (string) IWT_UPDATE_MANIFEST : self::DEFAULT_MANIFEST;
    }

    /** Lê o update.json (cache de 6h; ?iwt_check_update=1 força). */
    public static function manifest(bool $force = false): ?array
    {
        if (!$force) {
            $cached = get_site_transient(self::CACHE_KEY);
            if (is_array($cached)) {
                return $cached ?: null;
            }
        }
        $response = wp_remote_get(self::manifest_url(), ['timeout' => 8, 'headers' => ['Accept' => 'application/json']]);
        $data = null;
        if (!is_wp_error($response) && (int) wp_remote_retrieve_response_code($response) === 200) {
            $json = json_decode((string) wp_remote_retrieve_body($response), true);
            if (is_array($json) && !empty($json['version']) && !empty($json['download_url'])) {
                $data = $json;
            }
        }
        // Falha também é cacheada (1h) para não atrasar o painel quando o GitHub estiver fora.
        set_site_transient(self::CACHE_KEY, $data ?: [], $data ? 6 * HOUR_IN_SECONDS : HOUR_IN_SECONDS);
        return $data;
    }

    /** Filtro update_plugins_{host}: devolve os dados da atualização para o WordPress. */
    public static function check($update, $plugin_data, $plugin_file, $locales)
    {
        if ($plugin_file !== plugin_basename(IWT_FILE)) {
            return $update;
        }
        $m = self::manifest();
        if (!$m || strpos((string) $m['download_url'], 'https://') !== 0) {
            return $update;
        }
        return [
            'id' => self::manifest_url(),
            'slug' => IWT_SLUG,
            'version' => (string) $m['version'],
            'url' => (string) ($m['homepage'] ?? 'https://github.com/equipe-ux/inovaweb-tracking-dist'),
            'package' => (string) $m['download_url'],
            'tested' => (string) ($m['tested'] ?? ''),
            'requires_php' => (string) ($m['requires_php'] ?? '7.4'),
            'requires' => (string) ($m['requires'] ?? '5.9'),
            'icons' => [],
        ];
    }

    /** Janela "Ver detalhes" da tela de Plugins. */
    public static function details($result, $action, $args)
    {
        if ($action !== 'plugin_information' || !isset($args->slug) || $args->slug !== IWT_SLUG) {
            return $result;
        }
        $m = self::manifest();
        if (!$m) {
            return $result;
        }
        return (object) [
            'name' => 'INOVAWEB Tracking',
            'slug' => IWT_SLUG,
            'version' => (string) $m['version'],
            'author' => '<a href="https://inovawebdesign.com.br">Inova Web Design</a>',
            'homepage' => (string) ($m['homepage'] ?? ''),
            'requires' => (string) ($m['requires'] ?? '5.9'),
            'requires_php' => (string) ($m['requires_php'] ?? '7.4'),
            'tested' => (string) ($m['tested'] ?? ''),
            'last_updated' => (string) ($m['last_updated'] ?? ''),
            'download_link' => (string) $m['download_url'],
            'sections' => [
                'description' => 'Rastreamento de visitas, fontes de tráfego, funis e conversões para os sites dos clientes INOVAWEB.',
                'changelog' => self::markdown_to_html((string) ($m['changelog'] ?? '')),
            ],
        ];
    }

    /** Markdown mínimo (títulos, listas, negrito, código) para a aba de changelog. */
    public static function markdown_to_html(string $md): string
    {
        $html = '';
        $in_list = false;
        foreach (preg_split('/\r?\n/', esc_html($md)) as $line) {
            $line = preg_replace('/\*\*(.+?)\*\*/', '<strong>$1</strong>', $line);
            $line = preg_replace('/`(.+?)`/', '<code>$1</code>', $line);
            if (preg_match('/^\s*[-*]\s+(.*)$/', $line, $m)) {
                if (!$in_list) {
                    $html .= '<ul>';
                    $in_list = true;
                }
                $html .= '<li>' . $m[1] . '</li>';
                continue;
            }
            if ($in_list) {
                $html .= '</ul>';
                $in_list = false;
            }
            if (preg_match('/^(#{1,4})\s+(.*)$/', $line, $m)) {
                $level = min(4, strlen($m[1]) + 1);
                $html .= "<h$level>{$m[2]}</h$level>";
            } elseif (trim($line) !== '' && trim($line) !== '---') {
                $html .= '<p>' . $line . '</p>';
            }
        }
        return $html . ($in_list ? '</ul>' : '');
    }

    public static function clear_cache(): void
    {
        delete_site_transient(self::CACHE_KEY);
    }

    public static function row_meta(array $links, string $file): array
    {
        if ($file === plugin_basename(IWT_FILE) && current_user_can('update_plugins')) {
            $links[] = '<a href="' . esc_url(wp_nonce_url(admin_url('plugins.php?iwt_check_update=1'), 'iwt_check_update')) . '">Verificar atualizações</a>';
        }
        return $links;
    }

    /** Link "Verificar atualizações": limpa os caches e força a consulta agora. */
    public static function maybe_force_check(): void
    {
        if (!isset($_GET['iwt_check_update']) || !current_user_can('update_plugins')) {
            return;
        }
        check_admin_referer('iwt_check_update');
        self::clear_cache();
        delete_site_transient('update_plugins');
        wp_update_plugins();
        wp_safe_redirect(admin_url('plugins.php'));
        exit;
    }
}
