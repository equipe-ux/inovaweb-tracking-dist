<?php
/**
 * Presets das plataformas de checkout.
 *
 * Cada preset diz:
 *  - params:  em quais parâmetros da URL do checkout o token de rastreio é colocado;
 *  - domains: domínios de checkout (o script das páginas marca esses links automaticamente);
 *  - caminhos no payload do webhook para token, transação, status, valor, comprador e produto.
 *
 * Caminhos usam a sintaxe de IWT_Helpers::get_path(): "a.b.c", "lista[0].x", "lista[campo=VALOR].x",
 * e "a+b" para concatenar (DDD + número). Se o token não estiver no caminho esperado, o webhook
 * ainda faz uma varredura no payload inteiro procurando "iwh…"/"iwv…".
 *
 * "beta" = preset adaptado do Smart Funnel e ainda não validado em produção por nós:
 * confira o log do primeiro webhook recebido.
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_Platforms
{
    /** Dicionário geral de status (minúsculo) → status normalizado. */
    const STATUS = [
        'approved' => ['approved', 'paid', 'complete', 'completed', 'completa', 'finalizada', 'aprovada', 'aprovado', 'paga', 'pago',
            'authorized', 'autorizada', 'purchase_approved', 'purchase_complete', 'order_approved', 'orderpaid', 'order_paid',
            'purchase_order_confirmed', 'order.success', 'pagamento_confirmado', 'succeeded', 'invoice_paid', 'myeduzz.invoice_paid',
            'sale_approved', 'venda_aprovada', 'approved_purchase', 'checkout.session.completed', 'waiting_refund'],
        'pending' => ['pending', 'waiting_payment', 'aguardando pagamento', 'aguardando_pagamento', 'billet_printed', 'printed_billet',
            'purchase_billet_printed', 'billet_created', 'pix_created', 'bank_slip_created', 'bank_slip_generated', 'pix_generated',
            'boleto_gerado', 'pix_gerado', 'waiting', 'generated', 'voucher_pending', 'purchase_request_confirmed', 'pending_payment',
            'open', 'aberta', 'in_analysis', 'em_analise', 'invoice_opened', 'invoice_waiting_payment', 'unpaid', 'recovering', 'scheduled',
            'under_analisys', 'under_analysis', 'started', 'delayed', 'overdue', 'purchase_delayed'],
        'refunded' => ['refunded', 'reembolsada', 'reembolsado', 'purchase_refunded', 'order_refunded', 'refund', 'estornada', 'estornado',
            'partially_refunded', 'invoice_refunded', 'myeduzz.invoice_refunded', 'returned', 'devolvida', 'devolvido', 'charge.refunded'],
        'chargeback' => ['chargeback', 'chargedback', 'charged_back', 'purchase_chargeback', 'dispute', 'disputa', 'purchase_protest', 'protested'],
        'canceled' => ['canceled', 'cancelled', 'cancelada', 'cancelado', 'purchase_canceled', 'refused', 'recusada', 'recusado',
            'rejected', 'order_rejected', 'expired', 'expirada', 'purchase_expired', 'failed', 'invoice_canceled', 'invoice_expired',
            'bloqueada', 'duplicada', 'no_funds', 'blocked'],
    ];

    public static function all(): array
    {
        return [
            'hotmart' => [
                'label' => 'Hotmart',
                'params' => ['sck', 'xcod'],
                'domains' => ['pay.hotmart.com', 'go.hotmart.com'],
                'token' => ['data.purchase.origin.sck', 'data.purchase.origin.xcod', 'data.purchase.origin.src', 'sck', 'xcod', 'src'],
                'txn' => ['data.purchase.transaction', 'transaction'],
                'status' => ['data.purchase.status', 'status', 'event'],
                'value' => ['data.purchase.price.value', 'data.purchase.full_price.value', 'price', 'full_price'],
                'net' => ['data.commissions[source=PRODUCER].value', 'cms_vendor'],
                'currency' => ['data.purchase.price.currency_value', 'currency_code_from', 'currency'],
                'email' => ['data.buyer.email', 'email'],
                'name' => ['data.buyer.name', 'name'],
                'phone' => ['data.buyer.checkout_phone', 'data.buyer.phone', 'phone_checkout_local_code+phone_checkout_number', 'phone_local_code+phone_number'],
                'product_id' => ['data.product.id', 'prod'],
                'product_name' => ['data.product.name', 'prod_name'],
                'payment' => ['data.purchase.payment.type', 'payment_type'],
                'cents' => false,
                'auth' => 'hotmart',
                'help' => 'Hotmart → Ferramentas → Webhook (API e notificações) → Cadastrar webhook, versão 2.0.0, com todos os eventos de compra. Copie o "Hottok de verificação" para as configurações do plugin.',
            ],
            'kiwify' => [
                'label' => 'Kiwify',
                'params' => ['sck', 'src'],
                'domains' => ['pay.kiwify.com.br', 'pay.kiwify.com'],
                'token' => ['TrackingParameters.sck', 'TrackingParameters.src', 'TrackingParameters.s1', 'TrackingParameters.utm_content'],
                'txn' => ['order_id', 'order_ref'],
                'status' => ['order_status', 'webhook_event_type'],
                'value' => ['Commissions.charge_amount', 'Commissions.product_base_price'],
                'net' => ['Commissions.my_commission'],
                'currency' => ['Commissions.currency', 'Commissions.product_base_price_currency'],
                'email' => ['Customer.email'],
                'name' => ['Customer.full_name', 'Customer.first_name'],
                'phone' => ['Customer.mobile'],
                'product_id' => ['Product.product_id'],
                'product_name' => ['Product.product_name'],
                'payment' => ['payment_method'],
                'cents' => true,
                'auth' => 'kiwify',
                'help' => 'Kiwify → Apps → Webhooks → Criar webhook, marque compra aprovada, recusada, reembolso, chargeback, boleto e pix gerados. Copie o token do webhook para as configurações do plugin.',
            ],
            'eduzz' => [
                'label' => 'Eduzz',
                'params' => ['trk3'],
                'domains' => ['sun.eduzz.com', 'chk.eduzz.com', 'eduzz.com'],
                'token' => ['trans_track_id', 'data.tracker.code3', 'data.tracker.code1', 'trk3', 'trk'],
                'txn' => ['trans_cod', 'data.id'],
                'status' => ['trans_status', 'trans_status_code', 'data.status', 'event'],
                'status_codes' => ['1' => 'pending', '3' => 'approved', '4' => 'canceled', '6' => 'approved', '7' => 'refunded', '9' => 'canceled', '10' => 'canceled', '11' => 'pending', '15' => 'pending'],
                'value' => ['trans_value', 'trans_paid', 'data.paid.value', 'data.price.value'],
                'net' => ['commission_value', 'data.producer.amount'],
                'currency' => ['trans_currency', 'data.price.currency'],
                'email' => ['cus_email', 'data.buyer.email'],
                'name' => ['cus_name', 'data.buyer.name'],
                'phone' => ['cus_cel', 'data.buyer.cellphone', 'data.buyer.phone'],
                'product_id' => ['product_cod', 'data.items[0].productId'],
                'product_name' => ['product_name', 'data.items[0].name'],
                'payment' => ['trans_paymentmethod', 'data.paymentMethod'],
                'cents' => false,
                'help' => 'Eduzz → Configurações → Webhook/Postback: cole a URL abaixo e marque os eventos de fatura.',
            ],
            'monetizze' => [
                'label' => 'Monetizze', 'beta' => true,
                'params' => ['src'],
                'domains' => ['app.monetizze.com.br', 'monetizze.com.br'],
                'token' => ['venda.src', 'src'],
                'txn' => ['venda.codigo', 'chave_unica'],
                'status' => ['venda.status', 'tipoPostback.descricao'],
                'value' => ['venda.valor', 'venda.valorRecebido'],
                'net' => ['venda.valorRecebido', 'comissoes[0].valor'],
                'currency' => [],
                'email' => ['comprador.email'],
                'name' => ['comprador.nome'],
                'phone' => ['comprador.telefone'],
                'product_id' => ['produto.codigo'],
                'product_name' => ['produto.nome'],
                'payment' => ['venda.formaPagamento'],
                'cents' => false,
            ],
            'braip' => [
                'label' => 'Braip', 'beta' => true,
                'params' => ['src', 'visitor'],
                'domains' => ['ev.braip.com', 'braip.com'],
                'token' => ['meta.src', 'meta.visitor', 'src'],
                'txn' => ['trans_key', 'trans_cod'],
                'status' => ['trans_status_code', 'trans_status'],
                'status_codes' => ['1' => 'pending', '2' => 'approved', '3' => 'canceled', '4' => 'chargeback', '5' => 'refunded', '6' => 'pending', '7' => 'approved', '8' => 'pending', '10' => 'pending', '11' => 'pending'],
                'value' => ['trans_total_value', 'trans_value'],
                'net' => ['trans_value'],
                'currency' => [],
                'email' => ['client_email'],
                'name' => ['client_name'],
                'phone' => ['client_cel'],
                'product_id' => ['product_key'],
                'product_name' => ['product_name'],
                'payment' => ['trans_payment'],
                'cents' => true,
            ],
            'perfectpay' => [
                'label' => 'Perfect Pay', 'beta' => true,
                'params' => ['src'],
                'domains' => ['go.perfectpay.com.br', 'checkout.perfectpay.com.br'],
                'token' => ['metadata.src', 'src'],
                'txn' => ['code'],
                'status' => ['sale_status_enum', 'sale_status_detail'],
                'status_codes' => ['1' => 'pending', '2' => 'approved', '3' => 'pending', '5' => 'canceled', '6' => 'canceled', '7' => 'refunded', '9' => 'chargeback', '10' => 'approved', '13' => 'canceled'],
                'value' => ['sale_amount'],
                'net' => ['commission_amount'],
                'currency' => ['currency_enum_key'],
                'email' => ['customer.email'],
                'name' => ['customer.full_name'],
                'phone' => ['customer.phone_area_code+customer.phone_number'],
                'product_id' => ['product.code'],
                'product_name' => ['product.name'],
                'payment' => ['payment_type_enum'],
                'cents' => false,
            ],
            'ticto' => [
                'label' => 'Ticto', 'beta' => true,
                'params' => ['utm_content'],
                'domains' => ['checkout.ticto.app', 'payment.ticto.app'],
                'token' => ['tracking.utm_content', 'utm_content', 'tracking.src', 'tracking.sck'],
                'txn' => ['order.hash', 'transaction.hash', 'order.id'],
                'status' => ['status'],
                'value' => ['order.paid_amount', 'item.amount', 'producer.amount'],
                'net' => ['producer.amount', 'cms_value'],
                'currency' => [],
                'email' => ['customer.email', 'email_customer'],
                'name' => ['customer.name', 'name_customer'],
                'phone' => ['customer.phone.ddd+customer.phone.number', 'phone_local_code_customer+phone_number_customer'],
                'product_id' => ['item.product_id'],
                'product_name' => ['item.product_name', 'name_prod'],
                'payment' => ['payment_method'],
                'cents' => false,
            ],
            'greenn' => [
                'label' => 'Greenn', 'beta' => true,
                'params' => ['iwt'],
                'domains' => ['payfast.greenn.com.br', 'greenn.com.br'],
                'token' => ['iwt', 'sale.iwt'],
                'txn' => ['sale.id'],
                'status' => ['currentStatus', 'sale.status'],
                'value' => ['sale.amount', 'sale.total'],
                'net' => ['sale.amount'],
                'currency' => [],
                'email' => ['client.email'],
                'name' => ['client.name'],
                'phone' => ['client.cellphone'],
                'product_id' => ['product.id'],
                'product_name' => ['product.name'],
                'payment' => ['sale.method'],
                'cents' => false,
            ],
            'guru' => [
                'label' => 'Digital Manager Guru', 'beta' => true,
                'params' => ['src'],
                'domains' => ['clkdmg.site', 'digitalmanager.guru'],
                'token' => ['source.source', 'source.src', 'src'],
                'txn' => ['id', 'transaction.id'],
                'status' => ['status'],
                'value' => ['payment.total', 'payment.gross'],
                'net' => ['payment.net'],
                'currency' => ['payment.currency'],
                'email' => ['contact.email'],
                'name' => ['contact.name'],
                'phone' => ['contact.phone_number'],
                'product_id' => ['product.id'],
                'product_name' => ['product.name'],
                'payment' => ['payment.method'],
                'cents' => false,
            ],
            'doppus' => [
                'label' => 'Doppus', 'beta' => true,
                'params' => ['src'],
                'domains' => ['doppus.app', 'doppus.com'],
                'token' => ['tracking.src', 'src'],
                'txn' => ['transaction.code', 'transaction.id'],
                'status' => ['status'],
                'value' => ['transaction.total_value'],
                'net' => ['transaction.total_value'],
                'currency' => [],
                'email' => ['customer.email'],
                'name' => ['customer.name'],
                'phone' => ['customer.phone'],
                'product_id' => ['items[0].code'],
                'product_name' => ['items[0].description'],
                'payment' => ['payment.payment_type'],
                'cents' => false,
            ],
            'lastlink' => [
                'label' => 'Lastlink', 'beta' => true,
                'params' => ['utm_term'],
                'domains' => ['lastlink.com'],
                'token' => ['Data.Utm.UtmTerm'],
                'txn' => ['Data.Purchase.PaymentId', 'Data.Purchase.Id', 'Id'],
                'status' => ['Event'],
                'value' => ['Data.Purchase.Price.Value'],
                'net' => [],
                'currency' => ['Data.Purchase.Price.Currency'],
                'email' => ['Data.Buyer.Email'],
                'name' => ['Data.Buyer.Name'],
                'phone' => ['Data.Buyer.PhoneNumber'],
                'product_id' => ['Data.Products[0].Id'],
                'product_name' => ['Data.Products[0].Name'],
                'payment' => ['Data.Purchase.Payment.PaymentMethod'],
                'cents' => false,
            ],
            'cartpanda' => [
                'label' => 'CartPanda', 'beta' => true,
                'params' => ['sck'],
                'domains' => ['mycartpanda.com', 'cartpanda.com'],
                'token' => ['order.tracking_parameters[parameter_name=sck].parameter_value'],
                'txn' => ['order.id', 'order.number'],
                'status' => ['order.payment_status', 'order.status'],
                'status_codes' => ['1' => 'pending', '3' => 'approved'],
                'value' => ['order.total_price'],
                'net' => [],
                'currency' => ['order.currency'],
                'email' => ['order.customer.email'],
                'name' => ['order.customer.full_name'],
                'phone' => ['order.customer.phone'],
                'product_id' => ['order.line_items[0].product_id'],
                'product_name' => ['order.line_items[0].name'],
                'payment' => ['order.payment.type'],
                'cents' => false,
            ],
            'yampi' => [
                'label' => 'Yampi', 'beta' => true,
                'params' => ['utm_content'],
                'domains' => [],
                'token' => ['resource.utm_content'],
                'txn' => ['resource.id', 'resource.number'],
                'status' => ['resource.status.data.alias'],
                'value' => ['resource.value_total'],
                'net' => [],
                'currency' => [],
                'email' => ['resource.customer.data.email'],
                'name' => ['resource.customer.data.generic_name', 'resource.customer.data.name'],
                'phone' => ['resource.customer.data.phone.formated_number'],
                'product_id' => ['resource.items.data[0].product_id'],
                'product_name' => ['resource.items.data[0].sku.data.title'],
                'payment' => [],
                'cents' => false,
            ],
            'stripe' => [
                'label' => 'Stripe (Payment Links / Checkout)', 'beta' => true,
                'params' => ['client_reference_id'],
                'domains' => ['buy.stripe.com', 'checkout.stripe.com'],
                'token' => ['data.object.client_reference_id'],
                'txn' => ['data.object.payment_intent', 'data.object.id'],
                'status' => ['type', 'data.object.payment_status'],
                'value' => ['data.object.amount_total', 'data.object.amount'],
                'net' => [],
                'currency' => ['data.object.currency'],
                'email' => ['data.object.customer_details.email', 'data.object.billing_details.email'],
                'name' => ['data.object.customer_details.name'],
                'phone' => ['data.object.customer_details.phone'],
                'product_id' => [],
                'product_name' => [],
                'payment' => [],
                'cents' => true,
            ],
            'woocommerce' => [
                'label' => 'WooCommerce (este site)',
                'params' => [],
                'domains' => [],
                'internal' => true,
                'help' => 'Não precisa de webhook: o plugin acompanha os pedidos do WooCommerce deste site automaticamente.',
            ],
            'generic' => [
                'label' => 'Outra plataforma (webhook genérico)',
                'params' => [],
                'domains' => [],
                'generic' => true,
                'help' => 'Para qualquer checkout ou ferramenta que envie webhook em JSON ou formulário: configure os caminhos dos campos em Integrações.',
            ],
        ];
    }

    public static function get(string $key): ?array
    {
        $all = self::all();
        if (!isset($all[$key])) {
            return null;
        }
        $p = $all[$key];
        if (!empty($p['generic'])) {
            $p = array_merge($p, self::generic_preset());
        }
        return $p;
    }

    /** Campos do mapeamento do webhook genérico (Integrações). */
    public static function generic_fields(): array
    {
        return [
            'url_param' => 'Parâmetro da URL do checkout que recebe o código (ex.: src)',
            'type' => 'Tipo de conversão: sale (venda) ou lead',
            'token' => 'Caminho do código de rastreio no webhook',
            'txn' => 'Caminho do ID da transação',
            'status' => 'Caminho do status',
            'approved' => 'Valores de status = aprovado (separados por vírgula)',
            'pending' => 'Valores de status = pendente (boleto/pix gerado)',
            'refunded' => 'Valores de status = reembolso/chargeback/cancelado',
            'value' => 'Caminho do valor',
            'cents' => 'Valor vem em centavos? (sim/não)',
            'currency' => 'Caminho da moeda',
            'email' => 'Caminho do e-mail',
            'name' => 'Caminho do nome',
            'phone' => 'Caminho do telefone',
            'product_id' => 'Caminho do ID do produto',
            'product_name' => 'Caminho do nome do produto',
        ];
    }

    private static function generic_preset(): array
    {
        $m = (array) IWT_Settings::get('generic_mapping');
        $paths = function ($key) use ($m) {
            $v = trim((string) ($m[$key] ?? ''));
            return $v === '' ? [] : array_map('trim', explode(',', $v));
        };
        $values = function ($key) use ($m) {
            $v = strtolower(trim((string) ($m[$key] ?? '')));
            return $v === '' ? [] : array_map('trim', explode(',', $v));
        };
        $codes = [];
        foreach ($values('approved') as $v) {
            $codes[$v] = 'approved';
        }
        foreach ($values('pending') as $v) {
            $codes[$v] = 'pending';
        }
        foreach ($values('refunded') as $v) {
            $codes[$v] = 'refunded';
        }
        return [
            'params' => $paths('url_param') ?: ['src'],
            'token' => $paths('token'),
            'txn' => $paths('txn'),
            'status' => $paths('status'),
            'status_codes' => $codes,
            'value' => $paths('value'),
            'net' => [],
            'currency' => $paths('currency'),
            'email' => $paths('email'),
            'name' => $paths('name'),
            'phone' => $paths('phone'),
            'product_id' => $paths('product_id'),
            'product_name' => $paths('product_name'),
            'payment' => [],
            'cents' => in_array(strtolower(trim((string) ($m['cents'] ?? ''))), ['1', 'sim', 'yes', 'true', 's'], true),
            'type' => strtolower(trim((string) ($m['type'] ?? ''))) === 'lead' ? 'lead' : 'sale',
        ];
    }

    /** Para o script das páginas: domínio de checkout → parâmetros do token. */
    public static function checkout_domain_map(): array
    {
        $map = [];
        foreach (self::all() as $key => $p) {
            foreach ($p['domains'] ?? [] as $domain) {
                $map[$domain] = $p['params'];
            }
        }
        $extra = preg_split('/[\s,]+/', (string) IWT_Settings::get('extra_checkout_domains'));
        foreach (array_filter(array_map('trim', $extra)) as $line) {
            // Formato: dominio.com ou dominio.com=param
            [$domain, $param] = array_pad(explode('=', $line, 2), 2, 'src');
            $domain = strtolower(preg_replace('#^https?://#', '', rtrim($domain, '/')));
            if ($domain !== '') {
                $map[$domain] = [sanitize_key($param) ?: 'src'];
            }
        }
        return $map;
    }

    /** Status normalizado a partir de um valor bruto. */
    public static function normalize_status($raw, array $preset): string
    {
        if (!is_scalar($raw)) {
            return '';
        }
        $v = strtolower(trim((string) $raw));
        if ($v === '') {
            return '';
        }
        if (isset($preset['status_codes'][$v])) {
            return $preset['status_codes'][$v];
        }
        foreach (self::STATUS as $status => $list) {
            if (in_array($v, $list, true)) {
                return $status;
            }
        }
        return '';
    }

    /**
     * Converte o payload bruto num formato único.
     * @return array|null null quando o status não é reconhecido (webhook ignorado).
     */
    public static function normalize(string $platform, array $payload): ?array
    {
        $p = self::get($platform);
        if (!$p || !empty($p['internal'])) {
            return null;
        }

        // Status: primeiro caminho que resulte num status conhecido.
        $status = '';
        $raw_status = '';
        foreach ((array) ($p['status'] ?? []) as $path) {
            $raw = IWT_Helpers::get_path($payload, $path);
            $s = self::normalize_status($raw, $p);
            if ($raw !== null && $raw_status === '') {
                $raw_status = is_scalar($raw) ? (string) $raw : '';
            }
            if ($s !== '') {
                $status = $s;
                $raw_status = (string) $raw;
                break;
            }
        }
        // Lead (webhook genérico) sem status configurado = aprovado.
        if ($status === '' && ($p['type'] ?? 'sale') === 'lead' && empty($p['status'])) {
            $status = 'approved';
        }

        $token = null;
        foreach ((array) ($p['token'] ?? []) as $path) {
            $token = IWT_Helpers::parse_token(IWT_Helpers::get_path($payload, $path));
            if ($token) {
                break;
            }
        }
        if (!$token) {
            $token = IWT_Helpers::deep_find_token($payload);
        }

        $value = IWT_Helpers::parse_money(IWT_Helpers::first_path($payload, (array) ($p['value'] ?? [])));
        $net = IWT_Helpers::parse_money(IWT_Helpers::first_path($payload, (array) ($p['net'] ?? [])));
        if (!empty($p['cents'])) {
            $value = $value / 100;
            $net = $net / 100;
        }
        $currency = strtoupper((string) IWT_Helpers::first_path($payload, (array) ($p['currency'] ?? [])));
        if (!preg_match('/^[A-Z]{3}$/', $currency)) {
            $currency = '';
        }
        $txn = IWT_Helpers::first_path($payload, (array) ($p['txn'] ?? []));

        return [
            'status' => $status,
            'raw_status' => IWT_Helpers::truncate($raw_status, 60),
            'type' => $p['type'] ?? 'sale',
            'transaction_id' => is_scalar($txn) ? IWT_Helpers::truncate((string) $txn, 100) : '',
            'token' => $token,
            'value' => round($value, 2),
            'net_value' => round($net, 2),
            'currency' => $currency,
            'email' => sanitize_email((string) IWT_Helpers::first_path($payload, (array) ($p['email'] ?? []))),
            'name' => IWT_Helpers::clean_text(IWT_Helpers::first_path($payload, (array) ($p['name'] ?? [])), 191),
            'phone' => IWT_Helpers::clean_text(IWT_Helpers::first_path($payload, (array) ($p['phone'] ?? [])), 32),
            'product_id' => IWT_Helpers::clean_text(IWT_Helpers::first_path($payload, (array) ($p['product_id'] ?? [])), 100),
            'product_name' => IWT_Helpers::clean_text(IWT_Helpers::first_path($payload, (array) ($p['product_name'] ?? [])), 191),
            'payment_method' => IWT_Helpers::clean_text(IWT_Helpers::first_path($payload, (array) ($p['payment'] ?? [])), 32),
        ];
    }

    /** Lista enxuta para o painel. */
    public static function for_admin(): array
    {
        $out = [];
        foreach (self::all() as $key => $p) {
            $out[] = [
                'key' => $key,
                'label' => $p['label'],
                'beta' => !empty($p['beta']),
                'internal' => !empty($p['internal']),
                'generic' => !empty($p['generic']),
                'params' => $p['params'] ?? [],
                'help' => $p['help'] ?? '',
            ];
        }
        return $out;
    }
}
