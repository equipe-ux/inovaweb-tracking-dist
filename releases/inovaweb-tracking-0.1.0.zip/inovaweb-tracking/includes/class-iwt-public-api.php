<?php
/**
 * API de leitura para ferramentas externas (painel central da agência, planilhas, agentes de IA).
 *
 *   GET /wp-json/inovaweb-tracking/v1/api/overview?from=2026-09-01&to=2026-09-30
 *   GET /wp-json/inovaweb-tracking/v1/api/breakdown?dimension=campaign&model=last
 *   GET /wp-json/inovaweb-tracking/v1/api/funnels
 *   GET /wp-json/inovaweb-tracking/v1/api/conversions?status=approved
 *   Cabeçalho: Authorization: Bearer iwt_…   (gerado em Configurações → Acesso pela API)
 *
 * Somente leitura. O token é guardado como hash SHA-256; dados pessoais de compradores não saem por aqui.
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_Public_API
{
    public static function register_routes(): void
    {
        foreach (['overview', 'timeseries', 'breakdown', 'funnels', 'conversions'] as $name) {
            register_rest_route(IWT_REST_NS, '/api/' . $name, [
                'methods' => 'GET',
                'callback' => [__CLASS__, $name],
                'permission_callback' => [__CLASS__, 'authorize'],
            ]);
        }
    }

    public static function authorize(WP_REST_Request $r): bool
    {
        $hash = (string) IWT_Settings::get('api_token_hash');
        if ($hash === '') {
            return false;
        }
        $header = (string) $r->get_header('authorization');
        $token = stripos($header, 'bearer ') === 0 ? trim(substr($header, 7)) : '';
        return $token !== '' && hash_equals($hash, hash('sha256', $token));
    }

    public static function overview(WP_REST_Request $r): WP_REST_Response
    {
        return new WP_REST_Response(IWT_Reports::overview(IWT_Reports::args($r->get_params())));
    }

    public static function timeseries(WP_REST_Request $r): WP_REST_Response
    {
        return new WP_REST_Response(['series' => IWT_Reports::timeseries(IWT_Reports::args($r->get_params()))]);
    }

    public static function breakdown(WP_REST_Request $r): WP_REST_Response
    {
        $dimension = sanitize_key((string) ($r->get_param('dimension') ?: 'channel'));
        return new WP_REST_Response(['dimension' => $dimension, 'rows' => IWT_Reports::breakdown($dimension, IWT_Reports::args($r->get_params()), (int) ($r->get_param('limit') ?: 100))]);
    }

    public static function funnels(WP_REST_Request $r): WP_REST_Response
    {
        return new WP_REST_Response(['funnels' => IWT_Reports::funnels_summary(IWT_Reports::args($r->get_params()))]);
    }

    public static function conversions(WP_REST_Request $r): WP_REST_Response
    {
        $list = IWT_Reports::conversions_list(IWT_Reports::args($r->get_params()), $r->get_params());
        foreach ($list['items'] as &$item) {
            unset($item['customer_name'], $item['customer_email'], $item['customer_phone']);
        }
        unset($item);
        return new WP_REST_Response($list);
    }
}
