<?php
/**
 * API REST do painel: /wp-json/inovaweb-tracking/v1/admin/...
 * Toda rota tem permission_callback (capability iwt_view ou iwt_manage) e o nonce wp_rest
 * é exigido pelo próprio WordPress para requisições autenticadas por cookie.
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_Admin_API
{
    public static function can_view(): bool
    {
        return current_user_can(IWT_Plugin::CAP_VIEW) || current_user_can('manage_options');
    }

    public static function can_manage(): bool
    {
        return current_user_can(IWT_Plugin::CAP_MANAGE) || current_user_can('manage_options');
    }

    public static function register_routes(): void
    {
        $ns = IWT_REST_NS;
        $view = [__CLASS__, 'can_view'];
        $manage = [__CLASS__, 'can_manage'];
        $id = '(?P<id>\d+)';

        $routes = [
            ['/admin/bootstrap', 'GET', 'bootstrap', $view],
            ['/admin/overview', 'GET', 'overview', $view],
            ['/admin/timeseries', 'GET', 'timeseries', $view],
            ['/admin/breakdown', 'GET', 'breakdown', $view],
            ['/admin/funnels', 'GET', 'funnels', $view],
            ['/admin/funnels', 'POST', 'funnel_create', $manage],
            ["/admin/funnels/$id", 'GET', 'funnel_get', $view],
            ["/admin/funnels/$id", 'POST', 'funnel_save', $manage],
            ["/admin/funnels/$id", 'DELETE', 'funnel_delete', $manage],
            ["/admin/funnels/$id/status", 'POST', 'funnel_status', $manage],
            ["/admin/funnels/$id/duplicate", 'POST', 'funnel_duplicate', $manage],
            ["/admin/funnels/$id/stats", 'GET', 'funnel_stats', $view],
            ['/admin/conversions', 'GET', 'conversions', $view],
            ["/admin/conversions/$id", 'GET', 'conversion_get', $view],
            ["/admin/conversions/$id", 'DELETE', 'conversion_delete', $manage],
            ['/admin/costs', 'GET', 'costs', $view],
            ['/admin/costs', 'POST', 'cost_create', $manage],
            ["/admin/costs/$id", 'DELETE', 'cost_delete', $manage],
            ['/admin/webhook-logs', 'GET', 'webhook_logs', $manage],
            ["/admin/webhook-logs/$id", 'GET', 'webhook_log_get', $manage],
            ['/admin/outbox', 'GET', 'outbox', $manage],
            ["/admin/outbox/$id/retry", 'POST', 'outbox_retry', $manage],
            ['/admin/settings', 'GET', 'settings_get', $manage],
            ['/admin/settings', 'POST', 'settings_save', $manage],
            ['/admin/settings/webhook-key', 'POST', 'regenerate_webhook_key', $manage],
            ['/admin/settings/api-token', 'POST', 'generate_api_token', $manage],
            ['/admin/meta/test', 'POST', 'meta_test', $manage],
            ['/admin/diagnostics', 'GET', 'diagnostics', $manage],
        ];
        foreach ($routes as [$path, $method, $cb, $perm]) {
            register_rest_route($ns, $path, [
                'methods' => $method,
                'callback' => [__CLASS__, $cb],
                'permission_callback' => $perm,
            ]);
        }
    }

    private static function ok($data, int $status = 200): WP_REST_Response
    {
        return new WP_REST_Response($data, $status);
    }

    private static function error(string $message, int $status = 400): WP_REST_Response
    {
        return new WP_REST_Response(['ok' => false, 'error' => $message], $status);
    }

    /* ------------------------------------------------------------ bootstrap */

    public static function bootstrap(WP_REST_Request $r): WP_REST_Response
    {
        $webhooks = [];
        foreach (IWT_Platforms::all() as $key => $p) {
            if (empty($p['internal'])) {
                $webhooks[$key] = IWT_Webhooks::url($key);
            }
        }
        $dims = [];
        foreach (IWT_Reports::dimensions() as $k => $d) {
            $dims[$k] = $d['label'];
        }
        $platform_sources = [];
        foreach (IWT_Sources::platforms() as $k => $p) {
            $platform_sources[] = ['key' => $k, 'label' => $p['label'], 'paid' => $p['paid'], 'channel' => $p['channel']];
        }
        return self::ok([
            'version' => IWT_VERSION,
            'can_manage' => self::can_manage(),
            'can_script' => current_user_can('unfiltered_html'),
            'currency' => IWT_Settings::get('currency'),
            'timezone' => wp_timezone_string(),
            'today' => wp_date('Y-m-d'),
            'goals' => IWT_Funnels::goals(),
            'node_types' => IWT_Funnels::node_types(),
            'condition_fields' => IWT_Funnels::CONDITION_FIELDS,
            'platforms' => IWT_Platforms::for_admin(),
            'traffic_platforms' => $platform_sources,
            'channels' => IWT_Sources::channels(),
            'dimensions' => $dims,
            'statuses' => IWT_Conversions::statuses(),
            'types' => IWT_Conversions::types(),
            'funnels' => array_map(function ($f) {
                return ['id' => (int) $f->id, 'name' => $f->name, 'goal' => $f->goal, 'status' => $f->status];
            }, IWT_Funnels::all(true)),
            'woocommerce' => IWT_WooCommerce::active(),
            'webhook_urls' => self::can_manage() ? $webhooks : [],
            'link_base' => get_option('permalink_structure') ? home_url('/' . IWT_Settings::route_prefix() . '/') : add_query_arg('iwt_go', '', home_url('/')),
            'capi_configured' => IWT_Meta_CAPI::configured(),
            'tracker_enabled' => (bool) IWT_Settings::get('tracker_enabled'),
            'snippet' => IWT_Collector::external_snippet(),
        ]);
    }

    /* ------------------------------------------------------------ relatórios */

    public static function overview(WP_REST_Request $r): WP_REST_Response
    {
        $a = IWT_Reports::args($r->get_params());
        return self::ok(IWT_Reports::overview($a));
    }

    public static function timeseries(WP_REST_Request $r): WP_REST_Response
    {
        $a = IWT_Reports::args($r->get_params());
        return self::ok(['series' => IWT_Reports::timeseries($a)]);
    }

    public static function breakdown(WP_REST_Request $r): WP_REST_Response
    {
        $a = IWT_Reports::args($r->get_params());
        $dimension = sanitize_key((string) $r->get_param('dimension'));
        $limit = (int) ($r->get_param('limit') ?: 100);
        return self::ok(['dimension' => $dimension, 'rows' => IWT_Reports::breakdown($dimension, $a, $limit)]);
    }

    /* ------------------------------------------------------------ funis */

    public static function funnels(WP_REST_Request $r): WP_REST_Response
    {
        $a = IWT_Reports::args($r->get_params());
        return self::ok(['funnels' => IWT_Reports::funnels_summary($a)]);
    }

    public static function funnel_create(WP_REST_Request $r): WP_REST_Response
    {
        $data = (array) $r->get_json_params();
        $data['with_template'] = !isset($data['with_template']) || $data['with_template'];
        $id = IWT_Funnels::create($data);
        return self::ok(['ok' => true, 'id' => $id, 'graph' => IWT_Funnels::graph($id)], 201);
    }

    public static function funnel_get(WP_REST_Request $r): WP_REST_Response
    {
        $graph = IWT_Funnels::graph((int) $r['id']);
        return $graph ? self::ok($graph) : self::error('Funil não encontrado.', 404);
    }

    public static function funnel_save(WP_REST_Request $r): WP_REST_Response
    {
        $id = (int) $r['id'];
        $result = IWT_Funnels::save_graph($id, (array) $r->get_json_params());
        if (!$result['ok']) {
            return self::error(implode(' ', $result['errors']), 404);
        }
        return self::ok(['ok' => true, 'warnings' => $result['errors'], 'map' => $result['map'], 'graph' => IWT_Funnels::graph($id)]);
    }

    public static function funnel_delete(WP_REST_Request $r): WP_REST_Response
    {
        IWT_Funnels::delete((int) $r['id']);
        return self::ok(['ok' => true]);
    }

    public static function funnel_status(WP_REST_Request $r): WP_REST_Response
    {
        IWT_Funnels::set_status((int) $r['id'], sanitize_key((string) $r->get_param('status')));
        return self::ok(['ok' => true]);
    }

    public static function funnel_duplicate(WP_REST_Request $r): WP_REST_Response
    {
        $new = IWT_Funnels::duplicate((int) $r['id']);
        return $new ? self::ok(['ok' => true, 'id' => $new]) : self::error('Funil não encontrado.', 404);
    }

    public static function funnel_stats(WP_REST_Request $r): WP_REST_Response
    {
        $a = IWT_Reports::args($r->get_params());
        return self::ok(IWT_Reports::funnel_stats((int) $r['id'], $a));
    }

    /* ------------------------------------------------------------ conversões */

    public static function conversions(WP_REST_Request $r): WP_REST_Response
    {
        $a = IWT_Reports::args($r->get_params());
        return self::ok(IWT_Reports::conversions_list($a, $r->get_params()));
    }

    public static function conversion_get(WP_REST_Request $r): WP_REST_Response
    {
        $c = IWT_Conversions::get((int) $r['id']);
        if (!$c) {
            return self::error('Conversão não encontrada.', 404);
        }
        $first = IWT_Visitors::get_session((int) $c->first_session_id);
        $last = IWT_Visitors::get_session((int) $c->last_session_id);
        $paid = IWT_Visitors::get_session((int) $c->paid_session_id);
        $touch = function ($s) {
            if (!$s) {
                return null;
            }
            $channels = IWT_Sources::channels();
            return [
                'started_at' => IWT_Helpers::to_local_iso($s->started_at),
                'channel' => $channels[$s->channel] ?? $s->channel,
                'source' => $s->source, 'medium' => $s->medium, 'campaign' => $s->campaign,
                'content' => $s->content, 'term' => $s->term, 'landing' => $s->landing,
                'referrer' => $s->referrer_host, 'click_id_type' => $s->click_id_type, 'device' => $s->device,
            ];
        };
        return self::ok([
            'id' => (int) $c->id,
            'attribution' => ['first' => $touch($first), 'last' => $touch($last), 'paid' => $touch($paid)],
            'journey' => IWT_Reports::journey((int) $c->visitor_id),
            'match_method' => $c->match_method,
        ]);
    }

    public static function conversion_delete(WP_REST_Request $r): WP_REST_Response
    {
        IWT_Conversions::delete((int) $r['id']);
        return self::ok(['ok' => true]);
    }

    /* ------------------------------------------------------------ custos */

    public static function costs(WP_REST_Request $r): WP_REST_Response
    {
        global $wpdb;
        $a = IWT_Reports::args($r->get_params());
        $rows = $wpdb->get_results($wpdb->prepare(
            'SELECT c.*, f.name AS funnel_name, n.name AS node_name FROM ' . IWT_DB::t('costs') . ' c
             LEFT JOIN ' . IWT_DB::t('funnels') . ' f ON f.id = c.funnel_id LEFT JOIN ' . IWT_DB::t('nodes') . ' n ON n.id = c.node_id
             WHERE c.date BETWEEN %s AND %s ORDER BY c.date DESC, c.id DESC LIMIT 500',
            $a['from'],
            $a['to']
        ));
        return self::ok(['items' => array_map(function ($c) {
            return [
                'id' => (int) $c->id, 'date' => $c->date, 'funnel_id' => (int) $c->funnel_id, 'funnel_name' => (string) $c->funnel_name,
                'node_id' => (int) $c->node_id, 'node_name' => (string) $c->node_name, 'channel' => $c->channel, 'source' => $c->source,
                'campaign' => $c->campaign, 'amount' => (float) $c->amount, 'note' => $c->note,
            ];
        }, $rows)]);
    }

    public static function cost_create(WP_REST_Request $r): WP_REST_Response
    {
        global $wpdb;
        $d = (array) $r->get_json_params();
        $date = isset($d['date']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) $d['date']) ? $d['date'] : wp_date('Y-m-d');
        $amount = IWT_Helpers::parse_money($d['amount'] ?? 0);
        if ($amount <= 0) {
            return self::error('Informe um valor maior que zero.');
        }
        // Lançamento por período: divide igualmente entre os dias (ex.: gasto da semana).
        $until = isset($d['until']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) $d['until']) && $d['until'] >= $date ? $d['until'] : $date;
        $days = (int) round((strtotime($until . ' UTC') - strtotime($date . ' UTC')) / DAY_IN_SECONDS) + 1;
        $days = max(1, min(366, $days));
        $per_day = round($amount / $days, 2);
        $channel = sanitize_key((string) ($d['channel'] ?? ''));
        for ($i = 0; $i < $days; $i++) {
            $wpdb->insert(IWT_DB::t('costs'), [
                'date' => gmdate('Y-m-d', strtotime($date . ' UTC') + $i * DAY_IN_SECONDS),
                'funnel_id' => (int) ($d['funnel_id'] ?? 0),
                'node_id' => (int) ($d['node_id'] ?? 0),
                'channel' => isset(IWT_Sources::channels()[$channel]) ? $channel : '',
                'source' => IWT_Helpers::clean_text($d['source'] ?? '', 100),
                'campaign' => IWT_Helpers::clean_text($d['campaign'] ?? '', 191),
                'amount' => $i === $days - 1 ? round($amount - $per_day * ($days - 1), 2) : $per_day,
                'note' => IWT_Helpers::clean_text($d['note'] ?? '', 191),
                'created_at' => IWT_Helpers::now(),
            ]);
        }
        return self::ok(['ok' => true, 'days' => $days], 201);
    }

    public static function cost_delete(WP_REST_Request $r): WP_REST_Response
    {
        global $wpdb;
        $wpdb->delete(IWT_DB::t('costs'), ['id' => (int) $r['id']]);
        return self::ok(['ok' => true]);
    }

    /* ------------------------------------------------------------ logs */

    public static function webhook_logs(WP_REST_Request $r): WP_REST_Response
    {
        global $wpdb;
        $rows = $wpdb->get_results('SELECT id, created_at, platform, status, message, conversion_id FROM ' . IWT_DB::t('webhook_logs') . ' ORDER BY id DESC LIMIT 200');
        return self::ok(['items' => array_map(function ($l) {
            return ['id' => (int) $l->id, 'created_at' => IWT_Helpers::to_local_iso($l->created_at), 'platform' => $l->platform,
                'status' => $l->status, 'message' => $l->message, 'conversion_id' => (int) $l->conversion_id];
        }, $rows)]);
    }

    public static function webhook_log_get(WP_REST_Request $r): WP_REST_Response
    {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . IWT_DB::t('webhook_logs') . ' WHERE id = %d', (int) $r['id']));
        if (!$row) {
            return self::error('Registro não encontrado.', 404);
        }
        $decoded = json_decode((string) $row->payload, true);
        return self::ok(['id' => (int) $row->id, 'payload' => $decoded !== null ? $decoded : (string) $row->payload]);
    }

    public static function outbox(WP_REST_Request $r): WP_REST_Response
    {
        global $wpdb;
        $rows = $wpdb->get_results('SELECT id, created_at, provider, event_name, event_id, conversion_id, status, attempts, response_code, last_error, sent_at FROM ' . IWT_DB::t('outbox') . ' ORDER BY id DESC LIMIT 200');
        return self::ok(['items' => array_map(function ($o) {
            return ['id' => (int) $o->id, 'created_at' => IWT_Helpers::to_local_iso($o->created_at), 'event_name' => $o->event_name,
                'event_id' => $o->event_id, 'conversion_id' => (int) $o->conversion_id, 'status' => $o->status, 'attempts' => (int) $o->attempts,
                'response_code' => (int) $o->response_code, 'last_error' => (string) $o->last_error, 'sent_at' => IWT_Helpers::to_local_iso($o->sent_at)];
        }, $rows)]);
    }

    public static function outbox_retry(WP_REST_Request $r): WP_REST_Response
    {
        global $wpdb;
        $wpdb->update(IWT_DB::t('outbox'), ['status' => 'retry', 'attempts' => 0], ['id' => (int) $r['id']]);
        $result = IWT_Meta_CAPI::send((int) $r['id']);
        return self::ok(['ok' => (bool) $result['ok'], 'error' => $result['error'] ?? '']);
    }

    /* ------------------------------------------------------------ configurações */

    public static function settings_get(WP_REST_Request $r): WP_REST_Response
    {
        $roles = [];
        foreach (wp_roles()->roles as $key => $role) {
            $roles[$key] = translate_user_role($role['name']);
        }
        return self::ok(['settings' => IWT_Settings::for_admin(), 'roles' => $roles, 'generic_fields' => IWT_Platforms::generic_fields()]);
    }

    public static function settings_save(WP_REST_Request $r): WP_REST_Response
    {
        $old_prefix = IWT_Settings::route_prefix();
        IWT_Settings::update_from_admin((array) $r->get_json_params());
        if ($old_prefix !== IWT_Settings::route_prefix()) {
            IWT_Funnels::flush_cache();
        }
        return self::ok(['ok' => true, 'settings' => IWT_Settings::for_admin()]);
    }

    public static function regenerate_webhook_key(WP_REST_Request $r): WP_REST_Response
    {
        IWT_Settings::set('webhook_key', IWT_Helpers::random_key(32));
        return self::ok(['ok' => true]);
    }

    /** O token aparece uma única vez; no banco fica só o hash. */
    public static function generate_api_token(WP_REST_Request $r): WP_REST_Response
    {
        $token = 'iwt_' . IWT_Helpers::random_key(40);
        $all = IWT_Settings::all();
        $all['api_token_hash'] = hash('sha256', $token);
        $all['api_token_hint'] = substr($token, 0, 8) . '…' . substr($token, -4);
        IWT_Settings::save_raw($all);
        return self::ok(['ok' => true, 'token' => $token]);
    }

    public static function meta_test(WP_REST_Request $r): WP_REST_Response
    {
        return self::ok(IWT_Meta_CAPI::send_test());
    }

    public static function diagnostics(WP_REST_Request $r): WP_REST_Response
    {
        global $wpdb;
        $missing = IWT_DB::missing_tables();
        $counts = [];
        foreach (['visitors', 'sessions', 'hits', 'conversions'] as $t) {
            $counts[$t] = (int) $wpdb->get_var('SELECT COUNT(*) FROM ' . IWT_DB::t($t)); // phpcs:ignore
        }
        if (!function_exists('is_plugin_active')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php'; // não carregado em requisições REST
        }
        $cache_plugins = [];
        foreach (['wp-rocket/wp-rocket.php' => 'WP Rocket', 'litespeed-cache/litespeed-cache.php' => 'LiteSpeed Cache', 'w3-total-cache/w3-total-cache.php' => 'W3 Total Cache',
            'wp-super-cache/wp-cache.php' => 'WP Super Cache', 'wp-fastest-cache/wpFastestCache.php' => 'WP Fastest Cache', 'sg-cachepress/sg-cachepress.php' => 'SiteGround Optimizer'] as $file => $name) {
            if (is_plugin_active($file)) {
                $cache_plugins[] = $name;
            }
        }
        $last_hit = $wpdb->get_var('SELECT MAX(created_at) FROM ' . IWT_DB::t('hits'));
        $last_pageview = $wpdb->get_var('SELECT MAX(created_at) FROM ' . IWT_DB::t('hits') . " WHERE type = 'pageview'");
        $last_webhook = $wpdb->get_var('SELECT MAX(created_at) FROM ' . IWT_DB::t('webhook_logs'));
        return self::ok([
            'version' => IWT_VERSION,
            'db_version' => get_option(IWT_DB::OPTION_VERSION),
            'php' => PHP_VERSION,
            'wp' => get_bloginfo('version'),
            'missing_tables' => $missing,
            'counts' => $counts,
            'permalinks' => (bool) get_option('permalink_structure'),
            'link_example' => IWT_Funnels::link_url((object) ['id' => 123, 'alias' => '']),
            'cron_next' => wp_next_scheduled('iwt_cron_hourly') ? IWT_Helpers::to_local_iso(gmdate('Y-m-d H:i:s', (int) wp_next_scheduled('iwt_cron_hourly'))) : '',
            'cron_disabled' => defined('DISABLE_WP_CRON') && DISABLE_WP_CRON,
            'cache_plugins' => $cache_plugins,
            'last_hit' => IWT_Helpers::to_local_iso($last_hit),
            'last_pageview' => IWT_Helpers::to_local_iso($last_pageview),
            'last_webhook' => IWT_Helpers::to_local_iso($last_webhook),
            'https' => is_ssl(),
            'woocommerce' => IWT_WooCommerce::active(),
            'capi' => IWT_Meta_CAPI::configured(),
            'tz' => wp_timezone_string(),
            'update_manifest' => IWT_Updater::manifest_url(),
        ]);
    }
}
