<?php
/**
 * Esquema do banco. Toda alteração de tabela entra em install() e exige subir IWT_VERSION
 * (é a mudança de versão que dispara o dbDelta em maybe_upgrade()).
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_DB
{
    const OPTION_VERSION = 'iwt_db_version';

    /** Nome completo da tabela. Nunca escreva o nome à mão nas queries. */
    public static function t(string $name): string
    {
        global $wpdb;
        return $wpdb->prefix . 'iwt_' . $name;
    }

    public static function tables(): array
    {
        return ['visitors', 'sessions', 'hits', 'funnels', 'nodes', 'links', 'conversions', 'webhook_logs', 'outbox', 'costs'];
    }

    /** @return bool true quando a versão mudou (instalação nova ou atualização por zip). */
    public static function maybe_upgrade(): bool
    {
        if (get_option(self::OPTION_VERSION) !== IWT_VERSION) {
            self::install();
            return true;
        }
        return false;
    }

    public static function install(): void
    {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $c = $wpdb->get_charset_collate();
        $sql = [];

        // Visitante = navegador identificado pelo cookie _iwt_vid (uid). Guarda os ponteiros de atribuição.
        $sql[] = 'CREATE TABLE ' . self::t('visitors') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  uid char(20) NOT NULL,
  created_at datetime NOT NULL,
  last_seen_at datetime NOT NULL,
  current_session_id bigint(20) unsigned NOT NULL DEFAULT 0,
  first_session_id bigint(20) unsigned NOT NULL DEFAULT 0,
  last_touch_session_id bigint(20) unsigned NOT NULL DEFAULT 0,
  paid_session_id bigint(20) unsigned NOT NULL DEFAULT 0,
  sessions int(10) unsigned NOT NULL DEFAULT 0,
  fbc varchar(255) NOT NULL DEFAULT '',
  fbp varchar(64) NOT NULL DEFAULT '',
  email_hash char(64) NOT NULL DEFAULT '',
  phone_hash char(64) NOT NULL DEFAULT '',
  ip varchar(45) NOT NULL DEFAULT '',
  user_agent varchar(255) NOT NULL DEFAULT '',
  country char(2) NOT NULL DEFAULT '',
  is_bot tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY  (id),
  UNIQUE KEY uid (uid),
  KEY email_hash (email_hash),
  KEY last_seen_at (last_seen_at)
) $c;";

        // Sessão = visita. Uma linha por visita, com a origem (canal/fonte/UTM) já classificada.
        $sql[] = 'CREATE TABLE ' . self::t('sessions') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  visitor_id bigint(20) unsigned NOT NULL,
  started_at datetime NOT NULL,
  last_activity_at datetime NOT NULL,
  channel varchar(24) NOT NULL DEFAULT 'direct',
  source varchar(100) NOT NULL DEFAULT '',
  medium varchar(100) NOT NULL DEFAULT '',
  campaign varchar(191) NOT NULL DEFAULT '',
  content varchar(191) NOT NULL DEFAULT '',
  term varchar(191) NOT NULL DEFAULT '',
  referrer_host varchar(191) NOT NULL DEFAULT '',
  landing varchar(255) NOT NULL DEFAULT '',
  click_id_type varchar(16) NOT NULL DEFAULT '',
  click_id varchar(255) NOT NULL DEFAULT '',
  funnel_id int(10) unsigned NOT NULL DEFAULT 0,
  link_id int(10) unsigned NOT NULL DEFAULT 0,
  source_node_id int(10) unsigned NOT NULL DEFAULT 0,
  is_paid tinyint(1) NOT NULL DEFAULT 0,
  is_bot tinyint(1) NOT NULL DEFAULT 0,
  device varchar(16) NOT NULL DEFAULT '',
  os varchar(32) NOT NULL DEFAULT '',
  browser varchar(32) NOT NULL DEFAULT '',
  country char(2) NOT NULL DEFAULT '',
  language varchar(16) NOT NULL DEFAULT '',
  pageviews int(10) unsigned NOT NULL DEFAULT 0,
  clicks int(10) unsigned NOT NULL DEFAULT 0,
  events int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY  (id),
  KEY visitor_id (visitor_id),
  KEY started_at (started_at),
  KEY channel_started (channel,started_at),
  KEY funnel_started (funnel_id,started_at)
) $c;";

        // Hit = cada acontecimento: clique em link do funil (click), página vista (pageview) ou evento (event).
        $sql[] = 'CREATE TABLE ' . self::t('hits') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  created_at datetime NOT NULL,
  visitor_id bigint(20) unsigned NOT NULL DEFAULT 0,
  session_id bigint(20) unsigned NOT NULL DEFAULT 0,
  type varchar(16) NOT NULL DEFAULT 'click',
  event varchar(32) NOT NULL DEFAULT '',
  funnel_id int(10) unsigned NOT NULL DEFAULT 0,
  link_id int(10) unsigned NOT NULL DEFAULT 0,
  from_node_id int(10) unsigned NOT NULL DEFAULT 0,
  to_node_id int(10) unsigned NOT NULL DEFAULT 0,
  url varchar(255) NOT NULL DEFAULT '',
  cost decimal(12,4) NOT NULL DEFAULT 0,
  is_bot tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY  (id),
  KEY created_at (created_at),
  KEY session_id (session_id),
  KEY visitor_id (visitor_id),
  KEY funnel_created (funnel_id,created_at),
  KEY link_created (link_id,created_at),
  KEY type_created (type,created_at)
) $c;";

        $sql[] = 'CREATE TABLE ' . self::t('funnels') . " (
  id int(10) unsigned NOT NULL AUTO_INCREMENT,
  name varchar(191) NOT NULL DEFAULT '',
  status varchar(16) NOT NULL DEFAULT 'active',
  goal varchar(16) NOT NULL DEFAULT 'checkout',
  platform varchar(32) NOT NULL DEFAULT '',
  currency char(3) NOT NULL DEFAULT 'BRL',
  settings longtext NULL,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  deleted_at datetime NULL DEFAULT NULL,
  PRIMARY KEY  (id),
  KEY status (status)
) $c;";

        // Nó do funil: source | page | offer | thankyou | whatsapp | condition | rotator | distribution | script
        $sql[] = 'CREATE TABLE ' . self::t('nodes') . " (
  id int(10) unsigned NOT NULL AUTO_INCREMENT,
  funnel_id int(10) unsigned NOT NULL,
  type varchar(16) NOT NULL,
  name varchar(191) NOT NULL DEFAULT '',
  config longtext NULL,
  pos_x int(11) NOT NULL DEFAULT 0,
  pos_y int(11) NOT NULL DEFAULT 0,
  deleted tinyint(1) NOT NULL DEFAULT 0,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY funnel_id (funnel_id)
) $c;";

        // Link = conexão entre dois nós. Cada link é uma URL rastreável /{prefixo}/{id ou alias}.
        $sql[] = 'CREATE TABLE ' . self::t('links') . " (
  id int(10) unsigned NOT NULL AUTO_INCREMENT,
  funnel_id int(10) unsigned NOT NULL,
  from_node_id int(10) unsigned NOT NULL,
  to_node_id int(10) unsigned NOT NULL,
  alias varchar(100) NOT NULL DEFAULT '',
  config longtext NULL,
  deleted tinyint(1) NOT NULL DEFAULT 0,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY funnel_id (funnel_id),
  KEY from_node_id (from_node_id),
  KEY alias (alias)
) $c;";

        // Conversão: venda (checkout), página de obrigado ou WhatsApp. dedupe_key garante idempotência.
        $sql[] = 'CREATE TABLE ' . self::t('conversions') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  converted_at datetime NOT NULL,
  type varchar(16) NOT NULL DEFAULT 'sale',
  status varchar(16) NOT NULL DEFAULT 'approved',
  platform varchar(32) NOT NULL DEFAULT '',
  transaction_id varchar(100) NOT NULL DEFAULT '',
  dedupe_key varchar(191) NOT NULL,
  funnel_id int(10) unsigned NOT NULL DEFAULT 0,
  link_id int(10) unsigned NOT NULL DEFAULT 0,
  node_id int(10) unsigned NOT NULL DEFAULT 0,
  hit_id bigint(20) unsigned NOT NULL DEFAULT 0,
  visitor_id bigint(20) unsigned NOT NULL DEFAULT 0,
  first_session_id bigint(20) unsigned NOT NULL DEFAULT 0,
  last_session_id bigint(20) unsigned NOT NULL DEFAULT 0,
  paid_session_id bigint(20) unsigned NOT NULL DEFAULT 0,
  match_method varchar(16) NOT NULL DEFAULT 'none',
  value decimal(14,2) NOT NULL DEFAULT 0,
  net_value decimal(14,2) NOT NULL DEFAULT 0,
  currency char(3) NOT NULL DEFAULT 'BRL',
  product_id varchar(100) NOT NULL DEFAULT '',
  product_name varchar(191) NOT NULL DEFAULT '',
  payment_method varchar(32) NOT NULL DEFAULT '',
  customer_name varchar(191) NOT NULL DEFAULT '',
  customer_email varchar(191) NOT NULL DEFAULT '',
  customer_phone varchar(32) NOT NULL DEFAULT '',
  email_hash char(64) NOT NULL DEFAULT '',
  phone_hash char(64) NOT NULL DEFAULT '',
  meta longtext NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY dedupe_key (dedupe_key),
  KEY converted_at (converted_at),
  KEY funnel_converted (funnel_id,converted_at),
  KEY visitor_id (visitor_id),
  KEY status (status)
) $c;";

        $sql[] = 'CREATE TABLE ' . self::t('webhook_logs') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  created_at datetime NOT NULL,
  platform varchar(32) NOT NULL DEFAULT '',
  status varchar(16) NOT NULL DEFAULT '',
  message varchar(255) NOT NULL DEFAULT '',
  conversion_id bigint(20) unsigned NOT NULL DEFAULT 0,
  payload mediumtext NULL,
  PRIMARY KEY  (id),
  KEY created_at (created_at)
) $c;";

        // Fila de envio para plataformas externas (Meta CAPI). Reprocessada pelo cron com até 5 tentativas.
        $sql[] = 'CREATE TABLE ' . self::t('outbox') . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  created_at datetime NOT NULL,
  provider varchar(16) NOT NULL DEFAULT 'meta',
  event_name varchar(40) NOT NULL DEFAULT '',
  event_id varchar(64) NOT NULL DEFAULT '',
  conversion_id bigint(20) unsigned NOT NULL DEFAULT 0,
  funnel_id int(10) unsigned NOT NULL DEFAULT 0,
  status varchar(16) NOT NULL DEFAULT 'pending',
  attempts tinyint(3) unsigned NOT NULL DEFAULT 0,
  response_code smallint(5) unsigned NOT NULL DEFAULT 0,
  last_error text NULL,
  sent_at datetime NULL DEFAULT NULL,
  payload longtext NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY event_id (provider,event_id),
  KEY status (status)
) $c;";

        // Custos manuais por dia (complementam o CPC configurado nas fontes de tráfego).
        $sql[] = 'CREATE TABLE ' . self::t('costs') . " (
  id int(10) unsigned NOT NULL AUTO_INCREMENT,
  date date NOT NULL,
  funnel_id int(10) unsigned NOT NULL DEFAULT 0,
  node_id int(10) unsigned NOT NULL DEFAULT 0,
  channel varchar(24) NOT NULL DEFAULT '',
  source varchar(100) NOT NULL DEFAULT '',
  campaign varchar(191) NOT NULL DEFAULT '',
  amount decimal(14,2) NOT NULL DEFAULT 0,
  note varchar(191) NOT NULL DEFAULT '',
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY date (date)
) $c;";

        foreach ($sql as $statement) {
            dbDelta($statement);
        }

        update_option(self::OPTION_VERSION, IWT_VERSION, false);
    }

    /** Usado pelo uninstall.php quando "Apagar dados ao desinstalar" está marcado. */
    public static function drop_all(): void
    {
        global $wpdb;
        foreach (self::tables() as $name) {
            $wpdb->query('DROP TABLE IF EXISTS ' . self::t($name)); // phpcs:ignore WordPress.DB.PreparedSQL
        }
        delete_option(self::OPTION_VERSION);
    }

    public static function missing_tables(): array
    {
        global $wpdb;
        $missing = [];
        foreach (self::tables() as $name) {
            $table = self::t($name);
            if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) !== $table) {
                $missing[] = $table;
            }
        }
        return $missing;
    }
}
