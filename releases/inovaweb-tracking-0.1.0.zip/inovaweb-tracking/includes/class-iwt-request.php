<?php
/**
 * Propriedades da requisição atual: dispositivo, sistema, navegador, robô, país, idioma.
 * Parser de user-agent próprio e enxuto (sem bibliotecas externas).
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_Request
{
    private static $props = null;

    /** Robôs, crawlers de pré-visualização de link e ferramentas automatizadas. */
    // "[a-z0-9]bot[/-;)]" pega Googlebot/, bingbot/, Slackbot-… sem confundir com celulares "CUBOT X30".
    const BOT_PATTERN = '/[a-z0-9]bot[\/\-;)]|\bbot\b|crawl|spider|slurp|facebookexternalhit|facebookcatalog|meta-externalagent|whatsapp\/|telegrambot|twitterbot|linkedinbot|slackbot|discordbot|skypeuripreview|pinterestbot|bingpreview|google-inspectiontool|googleother|adsbot|mediapartners-google|apis-google|feedfetcher|lighthouse|pagespeed|gtmetrix|pingdom|uptimerobot|statuscake|headlesschrome|phantomjs|puppeteer|playwright|selenium|python-requests|python-urllib|aiohttp|curl\/|wget\/|go-http-client|java\/|okhttp|axios\/|node-fetch|libwww|httpclient|scrapy|semrush|ahrefs|mj12|dotbot|petalbot|yandex|baiduspider|bytespider|gptbot|chatgpt-user|oai-searchbot|claudebot|claude-web|anthropic-ai|perplexitybot|ccbot|amazonbot|applebot|duckduckbot|qwantify|seznambot|ia_archiver|archive\.org_bot|preview/i';

    public static function props(): array
    {
        if (self::$props !== null) {
            return self::$props;
        }
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? (string) wp_unslash($_SERVER['HTTP_USER_AGENT']) : '';
        self::$props = self::from_user_agent($ua) + [
            'ip'       => IWT_Helpers::client_ip(),
            'country'  => self::country(),
            'language' => self::language(),
            'referrer' => isset($_SERVER['HTTP_REFERER']) ? esc_url_raw((string) wp_unslash($_SERVER['HTTP_REFERER'])) : '',
        ];
        if (self::is_prefetch()) {
            self::$props['is_bot'] = 1;
        }
        return self::$props;
    }

    /** Usado também pelo coletor (o user-agent vem do próprio request do navegador). */
    public static function from_user_agent(string $ua): array
    {
        $ua_l = strtolower($ua);
        $is_bot = ($ua === '' || preg_match(self::BOT_PATTERN, $ua)) ? 1 : 0;

        // Sistema operacional
        $os = 'Outro';
        if (strpos($ua_l, 'windows') !== false) {
            $os = 'Windows';
        } elseif (preg_match('/iphone|ipad|ipod/', $ua_l)) {
            $os = 'iOS';
        } elseif (strpos($ua_l, 'android') !== false) {
            $os = 'Android';
        } elseif (strpos($ua_l, 'cros') !== false) {
            $os = 'ChromeOS';
        } elseif (strpos($ua_l, 'mac os') !== false || strpos($ua_l, 'macintosh') !== false) {
            $os = 'macOS';
        } elseif (strpos($ua_l, 'linux') !== false) {
            $os = 'Linux';
        }

        // Dispositivo
        $device = 'desktop';
        if (preg_match('/ipad|tablet|kindle|silk|playbook/', $ua_l) || ($os === 'Android' && strpos($ua_l, 'mobile') === false)) {
            $device = 'tablet';
        } elseif (preg_match('/mobile|iphone|ipod|android|blackberry|opera mini|iemobile|windows phone/', $ua_l)) {
            $device = 'mobile';
        }
        // Client hint (Chrome) tem prioridade quando presente.
        if (isset($_SERVER['HTTP_SEC_CH_UA_MOBILE']) && $_SERVER['HTTP_SEC_CH_UA_MOBILE'] === '?1' && $device === 'desktop') {
            $device = 'mobile';
        }

        // Navegador — apps com navegador embutido primeiro (Instagram, Facebook, TikTok…).
        $browser = 'Outro';
        $map = [
            'instagram'        => 'Instagram',
            'fban|fbav|fb_iab' => 'Facebook',
            'musical_ly|bytedancewebview|tiktok' => 'TikTok',
            'kwai'             => 'Kwai',
            'linkedinapp'      => 'LinkedIn',
            'gsa\/'            => 'Google App',
            'samsungbrowser'   => 'Samsung Internet',
            'edg\/|edga\/|edgios' => 'Edge',
            'opr\/|opera'      => 'Opera',
            'firefox|fxios'    => 'Firefox',
            'crios|chrome'     => 'Chrome',
            'safari'           => 'Safari',
        ];
        foreach ($map as $pattern => $name) {
            if (preg_match('/' . $pattern . '/', $ua_l)) {
                $browser = $name;
                break;
            }
        }

        return [
            'user_agent' => IWT_Helpers::truncate($ua, 255),
            'is_bot'     => $is_bot,
            'device'     => $is_bot ? 'bot' : $device,
            'os'         => $os,
            'browser'    => $browser,
            'in_app'     => in_array($browser, ['Instagram', 'Facebook', 'TikTok', 'Kwai', 'LinkedIn'], true) ? $browser : '',
        ];
    }

    /** País sem GeoIP: usa cabeçalhos de CDN/servidor; senão, a região do idioma do navegador. */
    public static function country(): string
    {
        foreach (['HTTP_CF_IPCOUNTRY', 'HTTP_X_COUNTRY_CODE', 'HTTP_CLOUDFRONT_VIEWER_COUNTRY', 'GEOIP_COUNTRY_CODE', 'HTTP_X_GEO_COUNTRY'] as $key) {
            if (!empty($_SERVER[$key])) {
                $cc = strtoupper(substr(preg_replace('/[^A-Za-z]/', '', (string) $_SERVER[$key]), 0, 2));
                if (strlen($cc) === 2 && $cc !== 'XX' && $cc !== 'T1') {
                    return $cc;
                }
            }
        }
        $lang = isset($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? (string) $_SERVER['HTTP_ACCEPT_LANGUAGE'] : '';
        if (preg_match('/^[a-z]{2}[-_]([A-Za-z]{2})\b/', $lang, $m)) {
            return strtoupper($m[1]);
        }
        return '';
    }

    public static function language(): string
    {
        $lang = isset($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? (string) $_SERVER['HTTP_ACCEPT_LANGUAGE'] : '';
        if (preg_match('/^([a-zA-Z]{2,3}(?:[-_][a-zA-Z]{2})?)/', $lang, $m)) {
            return strtolower(str_replace('_', '-', $m[1]));
        }
        return '';
    }

    /** Pré-carregamento do navegador (Chrome prefetch/prerender) não é visita real. */
    public static function is_prefetch(): bool
    {
        $purpose = strtolower((string) ($_SERVER['HTTP_SEC_PURPOSE'] ?? $_SERVER['HTTP_PURPOSE'] ?? $_SERVER['HTTP_X_MOZ'] ?? ''));
        return $purpose !== '' && (strpos($purpose, 'prefetch') !== false || strpos($purpose, 'prerender') !== false);
    }

    public static function is_excluded_ip(string $ip): bool
    {
        if ($ip === '') {
            return false;
        }
        foreach (IWT_Settings::excluded_ips() as $rule) {
            if ($rule === $ip) {
                return true;
            }
            // Prefixo simples: "189.10." ou "2804:14c:"
            if (substr($rule, -1) === '.' || substr($rule, -1) === ':' || substr($rule, -1) === '*') {
                if (strpos($ip, rtrim($rule, '*')) === 0) {
                    return true;
                }
            }
        }
        return false;
    }

    /** Valor de uma propriedade usada nas condições do funil. */
    public static function property(string $name)
    {
        $p = self::props();
        $local = time() + IWT_Helpers::tz_offset();
        switch ($name) {
            case 'device':
            case 'os':
            case 'browser':
            case 'country':
            case 'language':
                return (string) $p[$name];
            case 'referrer':
                return IWT_Helpers::host_of($p['referrer']);
            case 'hour':
                return (int) gmdate('G', $local);
            case 'weekday':
                return (int) gmdate('N', $local); // 1 = segunda … 7 = domingo
            case 'in_app':
                return (string) $p['in_app'];
        }
        return '';
    }
}
