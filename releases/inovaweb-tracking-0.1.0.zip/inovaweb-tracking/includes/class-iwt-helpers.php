<?php
/**
 * Funções utilitárias sem estado: datas, tokens, hashing, URLs e leitura de payloads.
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_Helpers
{
    /** Datas são gravadas SEMPRE em UTC. Conversão para o fuso do site só na leitura/relatório. */
    public static function now(): string
    {
        return gmdate('Y-m-d H:i:s');
    }

    /** Diferença em segundos entre o fuso do site e UTC (ex.: -10800 para America/Sao_Paulo). */
    public static function tz_offset(): int
    {
        return (int) round((float) get_option('gmt_offset', 0) * HOUR_IN_SECONDS);
    }

    /** Converte uma data local (Y-m-d) do site em limite UTC. $end=true devolve o último segundo do dia. */
    public static function local_date_to_utc(string $date, bool $end = false): string
    {
        $date = preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) ? $date : wp_date('Y-m-d');
        $ts = strtotime($date . ($end ? ' 23:59:59' : ' 00:00:00') . ' UTC');
        return gmdate('Y-m-d H:i:s', $ts - self::tz_offset());
    }

    /** UTC (Y-m-d H:i:s) → ISO 8601 com offset do site, para o JS formatar. */
    public static function to_local_iso(?string $utc): string
    {
        if (!$utc || $utc === '0000-00-00 00:00:00') {
            return '';
        }
        $ts = strtotime($utc . ' UTC');
        return wp_date('c', $ts);
    }

    /** ID público de visitante: 20 caracteres [a-z0-9]. */
    public static function new_uid(): string
    {
        $alphabet = 'abcdefghijklmnopqrstuvwxyz0123456789';
        $out = '';
        $bytes = random_bytes(20);
        for ($i = 0; $i < 20; $i++) {
            $out .= $alphabet[ord($bytes[$i]) % 36];
        }
        return $out;
    }

    public static function is_uid($value): bool
    {
        return is_string($value) && (bool) preg_match('/^[a-z0-9]{20}$/', $value);
    }

    public static function random_key(int $length = 32): string
    {
        return substr(bin2hex(random_bytes((int) ceil($length / 2))), 0, $length);
    }

    /**
     * Token que vai para o checkout e volta no webhook.
     * iwh{base36(hit_id)} → clique exato no link da oferta; iwv{uid} → visitante (link decorado pelo script).
     * O prefixo "iw" é o que permite achar o token em qualquer campo do payload (varredura profunda).
     */
    public static function hit_token(int $hit_id): string
    {
        return 'iwh' . base_convert((string) $hit_id, 10, 36);
    }

    public static function visitor_token(string $uid): string
    {
        return 'iwv' . $uid;
    }

    /** @return array{type:string,value:string}|null */
    public static function parse_token($value): ?array
    {
        if (!is_scalar($value)) {
            return null;
        }
        if (!preg_match('/(?:^|[^a-z0-9])(iw[hv][a-z0-9]{1,24})(?:$|[^a-z0-9])/i', ' ' . (string) $value . ' ', $m)) {
            return null;
        }
        $token = strtolower($m[1]);
        if ($token[2] === 'h') {
            $id = base_convert(substr($token, 3), 36, 10);
            return ctype_digit((string) $id) && (int) $id > 0 ? ['type' => 'hit', 'value' => (string) $id] : null;
        }
        $uid = substr($token, 3);
        return self::is_uid($uid) ? ['type' => 'visitor', 'value' => $uid] : null;
    }

    /** SHA-256 normalizado (padrão do Meta): e-mail minúsculo/trim; telefone só dígitos com DDI. */
    public static function hash_email(?string $email): string
    {
        $email = strtolower(trim((string) $email));
        return ($email !== '' && strpos($email, '@') !== false) ? hash('sha256', $email) : '';
    }

    public static function normalize_phone(?string $phone, string $default_ddi = '55'): string
    {
        $digits = preg_replace('/\D+/', '', (string) $phone);
        if ($digits === '' || strlen($digits) < 8) {
            return '';
        }
        $digits = ltrim($digits, '0');
        // Número brasileiro sem DDI (10 ou 11 dígitos) ganha o 55.
        if ($default_ddi !== '' && (strlen($digits) === 10 || strlen($digits) === 11)) {
            $digits = $default_ddi . $digits;
        }
        return $digits;
    }

    public static function hash_phone(?string $phone): string
    {
        $digits = self::normalize_phone($phone);
        return $digits !== '' ? hash('sha256', $digits) : '';
    }

    public static function hash_value(?string $value): string
    {
        $value = strtolower(trim((string) $value));
        return $value !== '' ? hash('sha256', $value) : '';
    }

    /** "1.234,56" | "1234.56" | 1234.56 | "R$ 97" → float. */
    public static function parse_money($value): float
    {
        if (is_int($value) || is_float($value)) {
            return (float) $value;
        }
        $s = preg_replace('/[^\d,.\-]/', '', (string) $value);
        if ($s === '' || $s === '-') {
            return 0.0;
        }
        $last_comma = strrpos($s, ',');
        $last_dot = strrpos($s, '.');
        if ($last_comma !== false && ($last_dot === false || $last_comma > $last_dot)) {
            // Vírgula é o separador decimal (padrão BR).
            $s = str_replace('.', '', $s);
            $s = str_replace(',', '.', $s);
        } else {
            $s = str_replace(',', '', $s);
        }
        return (float) $s;
    }

    public static function truncate(?string $value, int $max): string
    {
        $value = (string) $value;
        if (function_exists('mb_substr')) {
            return mb_strlen($value) > $max ? mb_substr($value, 0, $max) : $value;
        }
        return strlen($value) > $max ? substr($value, 0, $max) : $value;
    }

    public static function clean_text($value, int $max = 191): string
    {
        if (!is_scalar($value)) {
            return '';
        }
        return self::truncate(trim(wp_strip_all_tags((string) $value)), $max);
    }

    public static function site_host(): string
    {
        return strtolower((string) wp_parse_url(home_url('/'), PHP_URL_HOST));
    }

    public static function host_of(?string $url): string
    {
        $host = strtolower((string) wp_parse_url((string) $url, PHP_URL_HOST));
        return preg_replace('/^www\./', '', $host);
    }

    /** Mesmo domínio-base (ignora www e subdomínio de idioma simples). */
    public static function is_same_site(?string $host): bool
    {
        $host = preg_replace('/^www\./', '', strtolower((string) $host));
        $site = preg_replace('/^www\./', '', self::site_host());
        return $host !== '' && ($host === $site || substr($host, -strlen('.' . $site)) === '.' . $site);
    }

    /** Path + query, limitado a 255, para gravar URLs de página. */
    public static function url_path(?string $url): string
    {
        $parts = wp_parse_url((string) $url);
        if (!$parts) {
            return '';
        }
        $path = $parts['path'] ?? '/';
        return self::truncate($path, 255);
    }

    /** Acrescenta parâmetros sem sobrescrever os que já existem na URL. */
    public static function add_params(string $url, array $params, bool $overwrite = false): string
    {
        if (!$params) {
            return $url;
        }
        $fragment = '';
        if (($hash = strpos($url, '#')) !== false) {
            $fragment = substr($url, $hash);
            $url = substr($url, 0, $hash);
        }
        $existing = [];
        $query = (string) wp_parse_url($url, PHP_URL_QUERY);
        if ($query !== '') {
            wp_parse_str($query, $existing);
        }
        $add = [];
        foreach ($params as $key => $value) {
            if ($key === '' || $value === null || is_array($value)) {
                continue;
            }
            if (!$overwrite && array_key_exists($key, $existing)) {
                continue;
            }
            $add[$key] = (string) $value;
        }
        if ($overwrite) {
            $url = remove_query_arg(array_keys($add), $url);
        }
        if (!$add) {
            return $url . $fragment;
        }
        $sep = strpos($url, '?') === false ? '?' : (substr($url, -1) === '?' || substr($url, -1) === '&' ? '' : '&');
        return $url . $sep . http_build_query($add, '', '&', PHP_QUERY_RFC3986) . $fragment;
    }

    /**
     * Lê um valor de payload por caminho.
     * Sintaxe: "data.purchase.origin.sck", "items[0].name", "commissions[source=PRODUCER].value".
     * Aceita também o formato do Smart Funnel "a->b->c".
     */
    public static function get_path($data, string $path)
    {
        $path = trim(str_replace('->', '.', $path));
        if ($path === '') {
            return null;
        }
        // Quebra em segmentos respeitando colchetes.
        preg_match_all('/([^.\[\]]+)|\[([^\]]*)\]/', $path, $m, PREG_SET_ORDER);
        $current = $data;
        foreach ($m as $seg) {
            if (isset($seg[2]) && $seg[2] !== '' && ($seg[1] ?? '') === '') {
                $inner = $seg[2];
                if (!is_array($current)) {
                    return null;
                }
                if (ctype_digit($inner)) {
                    $current = $current[(int) $inner] ?? null;
                } elseif (strpos($inner, '=') !== false) {
                    [$k, $v] = array_map('trim', explode('=', $inner, 2));
                    $v = trim($v, "'\"");
                    $found = null;
                    foreach ($current as $item) {
                        if (is_array($item) && isset($item[$k]) && strcasecmp((string) $item[$k], $v) === 0) {
                            $found = $item;
                            break;
                        }
                    }
                    $current = $found;
                } else {
                    $current = $current[$inner] ?? null;
                }
            } else {
                $key = $seg[1];
                if (is_array($current) && array_key_exists($key, $current)) {
                    $current = $current[$key];
                } elseif (is_array($current) && isset($current[0]) && is_array($current[0]) && array_key_exists($key, $current[0])) {
                    // Lista sem índice explícito: usa o primeiro item (ex.: items.name).
                    $current = $current[0][$key];
                } else {
                    return null;
                }
            }
            if ($current === null) {
                return null;
            }
        }
        return $current;
    }

    /** Primeiro caminho com valor não vazio. Caminho com "+" concatena (ex.: "ddd+phone"). */
    public static function first_path($data, array $paths)
    {
        foreach ($paths as $path) {
            if (strpos($path, '+') !== false) {
                $parts = [];
                foreach (explode('+', $path) as $p) {
                    $v = self::get_path($data, $p);
                    if (is_scalar($v) && (string) $v !== '') {
                        $parts[] = (string) $v;
                    }
                }
                if ($parts) {
                    return implode('', $parts);
                }
                continue;
            }
            $v = self::get_path($data, $path);
            if ($v !== null && $v !== '' && !is_array($v)) {
                return $v;
            }
        }
        return null;
    }

    /** Varre recursivamente o payload atrás de um token "iwh…"/"iwv…". */
    public static function deep_find_token($data, int $depth = 0): ?array
    {
        if ($depth > 8) {
            return null;
        }
        if (is_scalar($data)) {
            $s = (string) $data;
            if (stripos($s, 'iw') === false) {
                return null;
            }
            // URL com query (ex.: link.url = "...?sck=iwh2k") também vale.
            return self::parse_token(rawurldecode($s));
        }
        if (is_array($data)) {
            foreach ($data as $value) {
                $found = self::deep_find_token($value, $depth + 1);
                if ($found) {
                    return $found;
                }
            }
        }
        return null;
    }

    public static function json_decode_array(?string $json): array
    {
        if (!$json) {
            return [];
        }
        $data = json_decode($json, true);
        return is_array($data) ? $data : [];
    }

    public static function client_ip(): string
    {
        $candidates = [];
        // Cabeçalhos de proxy só são confiáveis atrás de CDN/proxy; Cloudflare primeiro.
        foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $key) {
            if (!empty($_SERVER[$key])) {
                $candidates[] = trim(explode(',', (string) wp_unslash($_SERVER[$key]))[0]);
            }
        }
        foreach ($candidates as $ip) {
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
        return '';
    }

    public static function is_https_request(): bool
    {
        return is_ssl() || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string) $_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https');
    }
}
