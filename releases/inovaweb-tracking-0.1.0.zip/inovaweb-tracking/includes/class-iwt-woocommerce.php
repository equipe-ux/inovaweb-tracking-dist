<?php
/**
 * WooCommerce do próprio site: guarda o visitante no pedido e transforma mudanças de status em conversões.
 * Compatível com HPOS (tabelas de pedidos próprias) e com o checkout em blocos.
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_WooCommerce
{
    const META = '_iwt_vid';

    const STATUS_MAP = [
        'processing' => 'approved',
        'completed' => 'approved',
        'on-hold' => 'pending',
        'pending' => 'pending',
        'refunded' => 'refunded',
        'cancelled' => 'canceled',
        'failed' => 'canceled',
    ];

    public static function init(): void
    {
        add_action('before_woocommerce_init', function () {
            if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
                \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', IWT_FILE, true);
            }
        });
        if (!IWT_Settings::get('woocommerce_enabled')) {
            return;
        }
        add_action('woocommerce_checkout_order_created', [__CLASS__, 'capture'], 10, 1);
        add_action('woocommerce_store_api_checkout_order_processed', [__CLASS__, 'capture'], 10, 1);
        add_action('woocommerce_order_status_changed', [__CLASS__, 'status_changed'], 10, 4);
    }

    public static function active(): bool
    {
        return class_exists('WooCommerce');
    }

    /** No momento do checkout o cookie do visitante está disponível: grava no pedido. */
    public static function capture($order): void
    {
        if (!is_object($order) || !method_exists($order, 'get_meta') || $order->get_meta(self::META)) {
            return;
        }
        $uid = IWT_Visitors::cookie_uid();
        if ($uid === '') {
            return;
        }
        $order->update_meta_data(self::META, $uid);
        $order->save_meta_data();
    }

    public static function status_changed($order_id, $from, $to, $order = null): void
    {
        if (!isset(self::STATUS_MAP[$to])) {
            return;
        }
        if (!is_object($order) && function_exists('wc_get_order')) {
            $order = wc_get_order($order_id);
        }
        if (!is_object($order)) {
            return;
        }
        $uid = (string) $order->get_meta(self::META);
        $token = IWT_Helpers::is_uid($uid) ? ['type' => 'visitor', 'value' => $uid] : null;

        $items = $order->get_items();
        $first = $items ? reset($items) : null;
        $product_name = $first ? $first->get_name() : '';
        if (count($items) > 1) {
            $product_name .= ' + ' . (count($items) - 1) . ' item(ns)';
        }
        $n = [
            'status' => self::STATUS_MAP[$to],
            'raw_status' => (string) $to,
            'type' => 'sale',
            'transaction_id' => (string) $order->get_id(),
            'token' => $token,
            'value' => (float) $order->get_total(),
            'net_value' => (float) $order->get_total() - (float) $order->get_total_tax() - (float) $order->get_shipping_total(),
            'currency' => (string) $order->get_currency(),
            'email' => (string) $order->get_billing_email(),
            'name' => trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()),
            'phone' => (string) $order->get_billing_phone(),
            'product_id' => $first ? (string) $first->get_product_id() : '',
            'product_name' => IWT_Helpers::truncate($product_name, 191),
            'payment_method' => IWT_Helpers::truncate((string) $order->get_payment_method_title(), 32),
        ];
        $match = IWT_Conversions::match($token, IWT_Helpers::hash_email($n['email']), $n['product_id']);
        IWT_Conversions::upsert_sale('woocommerce', $n, $match);
    }
}
