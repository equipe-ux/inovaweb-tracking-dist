<?php
/**
 * Meta Conversions API (CAPI).
 *
 * - Conversão aprovada → evento (Purchase / Lead / Contact, ou o escolhido no funil).
 * - Clique no checkout → InitiateCheckout (opcional).
 * - Fila na tabela outbox: o envio acontece depois da resposta ao visitante (shutdown) e o cron
 *   reprocessa falhas (até 5 tentativas). Nada trava redirecionamento nem webhook.
 * - event_id determinístico (iwt-c{id} / iwt-ic{hit}) permite deduplicar com o pixel do navegador.
 * - Dados pessoais vão com SHA-256 (padrão do Meta); IP e user-agent vão como o Meta exige.
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_Meta_CAPI
{
    const MAX_ATTEMPTS = 5;

    /** IDs da fila criados nesta requisição, enviados no shutdown. */
    private static $pending_now = [];
    private static $shutdown_registered = false;

    public static function init(): void
    {
        add_action('iwt_conversion_approved', [__CLASS__, 'on_conversion_approved'], 10, 1);
    }

    public static function configured(): bool
    {
        return (bool) IWT_Settings::get('meta_enabled') && IWT_Settings::get('meta_pixel_id') !== '' && IWT_Settings::get('meta_token') !== '';
    }

    /** Funil sem configuração explícita envia (padrão ligado); funil com capi_enabled=false não envia. */
    public static function enabled_for(?object $funnel): bool
    {
        if (!self::configured()) {
            return false;
        }
        if (!$funnel) {
            return true;
        }
        $s = is_array($funnel->settings) ? $funnel->settings : IWT_Helpers::json_decode_array($funnel->settings);
        return !array_key_exists('capi_enabled', $s) || (bool) $s['capi_enabled'];
    }

    public static function pixel_for(?object $funnel): string
    {
        if ($funnel) {
            $s = is_array($funnel->settings) ? $funnel->settings : IWT_Helpers::json_decode_array($funnel->settings);
            if (!empty($s['capi_pixel_id'])) {
                return (string) $s['capi_pixel_id'];
            }
        }
        return (string) IWT_Settings::get('meta_pixel_id');
    }

    public static function default_event(string $type): string
    {
        $map = ['sale' => 'Purchase', 'lead' => 'Lead', 'thankyou' => 'Lead', 'whatsapp' => 'Contact'];
        return $map[$type] ?? 'Lead';
    }

    public static function on_conversion_approved(int $conversion_id): void
    {
        $c = IWT_Conversions::get($conversion_id);
        if (!$c) {
            return;
        }
        $funnel = $c->funnel_id ? IWT_Funnels::get((int) $c->funnel_id) : null;
        if (!self::enabled_for($funnel)) {
            return;
        }
        $s = $funnel ? $funnel->settings : [];
        $event_name = !empty($s['capi_event']) ? (string) $s['capi_event'] : self::default_event((string) $c->type);
        $visitor = $c->visitor_id ? IWT_Visitors::find((int) $c->visitor_id) : null;
        $meta = IWT_Helpers::json_decode_array($c->meta);

        $custom = [
            'currency' => $c->currency ?: 'BRL',
            'value' => (float) $c->value,
        ];
        if ($c->product_name !== '') {
            $custom['content_name'] = $c->product_name;
        }
        if ($c->product_id !== '') {
            $custom['content_ids'] = [(string) $c->product_id];
            $custom['content_type'] = 'product';
        }
        if ($c->transaction_id !== '') {
            $custom['order_id'] = $c->transaction_id;
        }
        $user = self::user_data($visitor, [
            'email_hash' => (string) $c->email_hash,
            'phone_hash' => (string) $c->phone_hash,
            'first_name' => (string) ($meta['first_name'] ?? ''),
        ]);
        $event = [
            'event_name' => $event_name,
            'event_time' => strtotime($c->converted_at . ' UTC'),
            'event_id' => 'iwt-c' . $c->id,
            'action_source' => 'website',
            'event_source_url' => self::source_url($c),
            'user_data' => $user,
            'custom_data' => $custom,
        ];
        self::enqueue($event, (int) $c->id, (int) $c->funnel_id, self::pixel_for($funnel));
    }

    public static function maybe_queue_initiate_checkout(object $funnel, object $visitor, int $hit_id, string $checkout_url): void
    {
        if (!IWT_Settings::get('meta_send_initiate_checkout') || !self::enabled_for($funnel)) {
            return;
        }
        $event = [
            'event_name' => 'InitiateCheckout',
            'event_time' => time(),
            'event_id' => 'iwt-ic' . $hit_id,
            'action_source' => 'website',
            'event_source_url' => esc_url_raw(strtok($checkout_url, '?')),
            'user_data' => self::user_data($visitor, []),
            'custom_data' => ['currency' => $funnel->currency ?: 'BRL'],
        ];
        self::enqueue($event, 0, (int) $funnel->id, self::pixel_for($funnel));
    }

    public static function user_data(?object $visitor, array $extra): array
    {
        $u = [];
        $email_hash = $extra['email_hash'] ?? '';
        $phone_hash = $extra['phone_hash'] ?? '';
        if ($visitor) {
            $email_hash = $email_hash ?: (string) $visitor->email_hash;
            $phone_hash = $phone_hash ?: (string) $visitor->phone_hash;
            $u['external_id'] = [hash('sha256', $visitor->uid)];
            if ($visitor->ip !== '') {
                $u['client_ip_address'] = $visitor->ip;
            }
            if ($visitor->user_agent !== '') {
                $u['client_user_agent'] = $visitor->user_agent;
            }
            if ($visitor->fbc !== '') {
                $u['fbc'] = $visitor->fbc;
            }
            if ($visitor->fbp !== '') {
                $u['fbp'] = $visitor->fbp;
            }
            if ($visitor->country !== '') {
                $u['country'] = [hash('sha256', strtolower($visitor->country))];
            }
        }
        if ($email_hash !== '') {
            $u['em'] = [$email_hash];
        }
        if ($phone_hash !== '') {
            $u['ph'] = [$phone_hash];
        }
        if (!empty($extra['first_name'])) {
            $u['fn'] = [IWT_Helpers::hash_value(remove_accents($extra['first_name']))];
        }
        return $u;
    }

    private static function source_url(object $c): string
    {
        if ($c->node_id) {
            $node = IWT_Funnels::get_node((int) $c->node_id);
            if ($node && !empty($node->config['url'])) {
                return esc_url_raw(strtok((string) $node->config['url'], '?'));
            }
        }
        return home_url('/');
    }

    public static function enqueue(array $event, int $conversion_id, int $funnel_id, string $pixel_id): void
    {
        global $wpdb;
        $table = IWT_DB::t('outbox');
        $wpdb->query($wpdb->prepare(
            "INSERT IGNORE INTO $table (created_at, provider, event_name, event_id, conversion_id, funnel_id, status, attempts, payload) VALUES (%s, 'meta', %s, %s, %d, %d, 'pending', 0, %s)",
            IWT_Helpers::now(),
            $event['event_name'],
            $event['event_id'],
            $conversion_id,
            $funnel_id,
            wp_json_encode(['pixel_id' => $pixel_id, 'event' => $event])
        ));
        if ($wpdb->insert_id) {
            self::$pending_now[] = (int) $wpdb->insert_id;
            if (!self::$shutdown_registered) {
                self::$shutdown_registered = true;
                register_shutdown_function([__CLASS__, 'flush_after_response']);
            }
        }
    }

    /** Envia o que foi enfileirado nesta requisição depois de liberar a resposta ao navegador. */
    public static function flush_after_response(): void
    {
        if (!self::$pending_now) {
            return;
        }
        if (function_exists('fastcgi_finish_request')) {
            fastcgi_finish_request();
        } elseif (function_exists('litespeed_finish_request')) {
            litespeed_finish_request();
        }
        foreach (self::$pending_now as $id) {
            self::send((int) $id);
        }
        self::$pending_now = [];
    }

    /** Cron: reprocessa pendentes/falhas. */
    public static function process_queue(int $limit = 25): int
    {
        global $wpdb;
        $ids = $wpdb->get_col($wpdb->prepare(
            'SELECT id FROM ' . IWT_DB::t('outbox') . " WHERE provider = 'meta' AND status IN ('pending','retry') AND attempts < %d ORDER BY id ASC LIMIT %d",
            self::MAX_ATTEMPTS,
            $limit
        ));
        foreach ($ids as $id) {
            self::send((int) $id);
        }
        return count($ids);
    }

    public static function send(int $outbox_id): array
    {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . IWT_DB::t('outbox') . ' WHERE id = %d', $outbox_id));
        if (!$row || $row->status === 'sent') {
            return ['ok' => false, 'error' => 'not_found'];
        }
        $payload = IWT_Helpers::json_decode_array($row->payload);
        $pixel = (string) ($payload['pixel_id'] ?? '');
        $event = $payload['event'] ?? null;
        $token = (string) IWT_Settings::get('meta_token');
        if ($pixel === '' || !$event || $token === '') {
            $wpdb->update(IWT_DB::t('outbox'), ['status' => 'failed', 'last_error' => 'Pixel ou token do Meta não configurado.'], ['id' => $outbox_id]);
            return ['ok' => false, 'error' => 'not_configured'];
        }
        $result = self::post($pixel, [$event], $token);
        $attempts = (int) $row->attempts + 1;
        $update = ['attempts' => $attempts, 'response_code' => $result['code']];
        if ($result['ok']) {
            $update['status'] = 'sent';
            $update['sent_at'] = IWT_Helpers::now();
            $update['last_error'] = null;
        } else {
            $update['status'] = $attempts >= self::MAX_ATTEMPTS ? 'failed' : 'retry';
            $update['last_error'] = IWT_Helpers::truncate($result['error'], 1000);
        }
        $wpdb->update(IWT_DB::t('outbox'), $update, ['id' => $outbox_id]);
        return $result;
    }

    /** @return array{ok:bool,code:int,error:string,body:array} */
    public static function post(string $pixel_id, array $events, string $token): array
    {
        $version = (string) IWT_Settings::get('meta_api_version') ?: 'v23.0';
        $body = ['data' => $events, 'access_token' => $token];
        $test = (string) IWT_Settings::get('meta_test_code');
        if ($test !== '') {
            $body['test_event_code'] = $test;
        }
        // Token vai no corpo, não na URL (o Smart Funnel mandava na query string).
        $response = wp_remote_post('https://graph.facebook.com/' . rawurlencode($version) . '/' . rawurlencode($pixel_id) . '/events', [
            'timeout' => 10,
            'headers' => ['Content-Type' => 'application/json'],
            'body' => wp_json_encode($body),
        ]);
        if (is_wp_error($response)) {
            return ['ok' => false, 'code' => 0, 'error' => $response->get_error_message(), 'body' => []];
        }
        $code = (int) wp_remote_retrieve_response_code($response);
        $data = json_decode((string) wp_remote_retrieve_body($response), true);
        $data = is_array($data) ? $data : [];
        if ($code === 200 && isset($data['events_received'])) {
            return ['ok' => true, 'code' => $code, 'error' => '', 'body' => $data];
        }
        $error = $data['error']['error_user_msg'] ?? $data['error']['message'] ?? ('HTTP ' . $code);
        return ['ok' => false, 'code' => $code, 'error' => (string) $error, 'body' => $data];
    }

    /** Botão "Enviar evento de teste" das Integrações. */
    public static function send_test(): array
    {
        $pixel = (string) IWT_Settings::get('meta_pixel_id');
        $token = (string) IWT_Settings::get('meta_token');
        if ($pixel === '' || $token === '') {
            return ['ok' => false, 'local' => true, 'error' => 'Preencha o ID do pixel e o token de acesso e salve antes de testar.'];
        }
        $event = [
            'event_name' => 'PageView',
            'event_time' => time(),
            'event_id' => 'iwt-test-' . time(),
            'action_source' => 'website',
            'event_source_url' => home_url('/'),
            'user_data' => [
                'client_ip_address' => IWT_Helpers::client_ip() ?: '127.0.0.1',
                'client_user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? (string) wp_unslash($_SERVER['HTTP_USER_AGENT']) : 'INOVAWEB Tracking',
                'external_id' => [hash('sha256', 'iwt-test')],
            ],
        ];
        $result = self::post($pixel, [$event], $token);
        return [
            'ok' => $result['ok'],
            'error' => $result['error'],
            'test_code_used' => (string) IWT_Settings::get('meta_test_code') !== '',
            'response' => $result['body'],
        ];
    }
}
