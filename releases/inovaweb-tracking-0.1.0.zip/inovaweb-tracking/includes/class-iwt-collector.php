<?php
/**
 * Coletor do script de rastreamento (assets/front/tracker.js).
 *
 * Recebe páginas vistas e eventos (cliques em WhatsApp, telefone, e-mail, checkout) de qualquer página
 * do site — e de páginas externas que incluam o script. É o que alimenta "Visitas" e "Fontes de tráfego"
 * mesmo para quem nunca passou por um link de funil.
 *
 * Endpoints (mesmo handler):
 *  - POST /wp-json/inovaweb-tracking/v1/collect   (padrão)
 *  - POST /?iwt_collect=1                          (reserva, para sites que bloqueiam a REST API)
 * O corpo é JSON enviado como text/plain (sendBeacon), o que evita preflight de CORS.
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_Collector
{
    const EVENTS = ['whatsapp_click', 'phone_click', 'email_click', 'checkout_click', 'form_submit', 'custom'];

    public static function init(): void
    {
        add_action('init', [__CLASS__, 'maybe_fallback'], 1);
    }

    public static function register_routes(): void
    {
        register_rest_route(IWT_REST_NS, '/collect', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'rest'],
            'permission_callback' => '__return_true', // endpoint público de analytics (sem dados sensíveis)
        ]);
    }

    public static function rest(WP_REST_Request $request)
    {
        $data = json_decode((string) $request->get_body(), true);
        if (!is_array($data)) {
            $data = (array) $request->get_json_params();
        }
        return new WP_REST_Response(self::handle($data), 200);
    }

    public static function maybe_fallback(): void
    {
        if (!isset($_GET['iwt_collect']) || ($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            return;
        }
        $data = json_decode((string) file_get_contents('php://input'), true);
        nocache_headers();
        wp_send_json(self::handle(is_array($data) ? $data : []));
    }

    public static function handle(array $data): array
    {
        $type = (string) ($data['t'] ?? 'pageview');
        $url = isset($data['u']) && is_string($data['u']) ? esc_url_raw(IWT_Helpers::truncate($data['u'], 2000)) : '';
        if (!in_array($type, ['pageview', 'event'], true) || $url === '' || !preg_match('#^https?://#i', $url)) {
            return ['ok' => false, 'error' => 'invalid'];
        }
        $props = IWT_Request::props();
        if ($props['is_bot'] || IWT_Request::is_excluded_ip($props['ip'])) {
            return ['ok' => true, 'skipped' => true];
        }

        $visitor = IWT_Visitors::identify(sanitize_key((string) ($data['vid'] ?? '')), true);
        if (!$visitor) {
            return ['ok' => false, 'error' => 'visitor'];
        }
        self::store_browser_ids($visitor, $data);

        $params = [];
        $query = (string) wp_parse_url($url, PHP_URL_QUERY);
        if ($query !== '') {
            wp_parse_str($query, $params);
        }
        $page = IWT_Helpers::truncate(IWT_Helpers::host_of($url) . ((string) wp_parse_url($url, PHP_URL_PATH) ?: '/'), 255);

        if ($type === 'pageview') {
            $referrer = isset($data['r']) && is_string($data['r']) ? esc_url_raw(IWT_Helpers::truncate($data['r'], 2000)) : '';
            // Página externa com o script: o referenciador do próprio domínio dela também é navegação interna.
            if ($referrer !== '' && IWT_Helpers::host_of($referrer) === IWT_Helpers::host_of($url)) {
                $referrer = '';
            }
            $attr = IWT_Sources::classify(['params' => $params, 'referrer' => $referrer, 'in_app' => $props['in_app']]);
            $session = IWT_Visitors::touch($visitor, $attr, ['landing' => $page]);
            self::assign_funnel($session, $url);
            $hit_id = IWT_Visitors::log_hit([
                'visitor_id' => (int) $visitor->id,
                'session_id' => (int) $session->id,
                'type' => 'pageview',
                'url' => $page,
            ]);
            self::check_thankyou($url, $visitor, $session, $hit_id);
            return ['ok' => true, 'vid' => $visitor->uid];
        }

        // Evento: continua a visita atual (ou abre uma direta, se expirou).
        $event = sanitize_key((string) ($data['e'] ?? ''));
        if (!in_array($event, self::EVENTS, true)) {
            return ['ok' => false, 'error' => 'event'];
        }
        $attr = IWT_Sources::classify(['params' => [], 'referrer' => '', 'in_app' => '']);
        $session = IWT_Visitors::touch($visitor, $attr, ['landing' => $page, 'continue_if_active' => true]);
        $target = isset($data['h']) && is_string($data['h']) ? IWT_Helpers::truncate(preg_replace('#^(https?://|tel:|mailto:)#i', '', $data['h']), 200) : $page;
        IWT_Visitors::log_hit([
            'visitor_id' => (int) $visitor->id,
            'session_id' => (int) $session->id,
            'type' => 'event',
            'event' => $event,
            'url' => sanitize_text_field($target),
        ]);
        return ['ok' => true, 'vid' => $visitor->uid];
    }

    /** Visita sem funil que abre uma página cadastrada num funil passa a contar para ele. */
    private static function assign_funnel(object $session, string $url): void
    {
        global $wpdb;
        if ((int) $session->funnel_id > 0) {
            return;
        }
        $targets = IWT_Funnels::page_targets();
        $key = IWT_Funnels::page_key($url);
        if ($key === '' || !isset($targets[$key])) {
            return;
        }
        $wpdb->query($wpdb->prepare(
            'UPDATE ' . IWT_DB::t('sessions') . ' SET funnel_id = %d WHERE id = %d AND funnel_id = 0',
            $targets[$key],
            (int) $session->id
        ));
        $session->funnel_id = $targets[$key];
    }

    /** _fbp e _fbc do pixel do Meta melhoram o casamento no CAPI. */
    private static function store_browser_ids(object $visitor, array $data): void
    {
        global $wpdb;
        $update = [];
        $fbp = (string) ($data['fbp'] ?? '');
        if ($fbp !== '' && preg_match('/^fb\.\d\.\d{10,16}\.\d{3,25}$/', $fbp) && $fbp !== $visitor->fbp) {
            $update['fbp'] = $fbp;
        }
        $fbc = (string) ($data['fbc'] ?? '');
        if ($fbc !== '' && preg_match('/^fb\.\d\.\d{10,16}\.[\w\-]{10,240}$/', $fbc) && $fbc !== $visitor->fbc) {
            $update['fbc'] = $fbc;
        }
        if ($update) {
            $wpdb->update(IWT_DB::t('visitors'), $update, ['id' => (int) $visitor->id]);
            foreach ($update as $k => $v) {
                $visitor->$k = $v;
            }
        }
    }

    /** Página vista que é a "página de obrigado" de um funil ativo → conversão. */
    private static function check_thankyou(string $url, object $visitor, object $session, int $hit_id): void
    {
        $targets = IWT_Funnels::thankyou_targets();
        if (!$targets) {
            return;
        }
        $host = IWT_Helpers::host_of($url);
        $path = untrailingslashit((string) wp_parse_url($url, PHP_URL_PATH)) ?: '/';
        foreach ($targets as $t) {
            if ($t['host'] !== '' && $t['host'] !== $host) {
                continue;
            }
            $hit = false;
            if ($t['match'] === 'prefix') {
                $hit = strpos($path, $t['path']) === 0;
            } elseif ($t['match'] === 'exact') {
                $hit = untrailingslashit(strtok($url, '#')) === untrailingslashit(strtok($t['url'], '#'));
            } else {
                $hit = $path === $t['path'];
            }
            if (!$hit) {
                continue;
            }
            $funnel = IWT_Funnels::get((int) $t['funnel_id']);
            $node = IWT_Funnels::get_node((int) $t['node_id']);
            if ($funnel) {
                IWT_Conversions::record_funnel_event('thankyou', $funnel, $node, null, $hit_id, $visitor, $session);
            }
        }
    }

    /** Configuração entregue ao tracker.js (também usada no snippet para páginas externas). */
    public static function tracker_config(): array
    {
        $s = IWT_Settings::all();
        return [
            'endpoint' => rest_url(IWT_REST_NS . '/collect'),
            'fallback' => add_query_arg('iwt_collect', '1', home_url('/')),
            'prefix' => '/' . IWT_Settings::route_prefix() . '/',
            'home' => home_url('/'),
            'cookieDays' => (int) $s['cookie_days'],
            'consent' => $s['consent_mode'] === 'required',
            'whatsapp' => (bool) $s['track_whatsapp'],
            'phoneEmail' => (bool) $s['track_phone_email'],
            'decorate' => (bool) $s['decorate_checkouts'],
            'checkouts' => IWT_Platforms::checkout_domain_map(),
        ];
    }

    /** Enfileira o script nas páginas públicas do próprio site. */
    public static function enqueue(): void
    {
        if (!IWT_Settings::get('tracker_enabled') || is_admin()) {
            return;
        }
        if (is_user_logged_in() && current_user_can('edit_posts') && !IWT_Settings::get('track_logged_admins')) {
            return;
        }
        if (is_preview() || is_customize_preview() || (function_exists('wp_is_json_request') && wp_is_json_request())) {
            return;
        }
        wp_enqueue_script('iwt-tracker', IWT_URL . 'assets/front/tracker.js', [], IWT_VERSION, ['in_footer' => true, 'strategy' => 'defer']);
        wp_add_inline_script('iwt-tracker', 'window.IWT_CONFIG=' . wp_json_encode(self::tracker_config()) . ';', 'before');
    }

    /** Snippet para colar em páginas fora do WordPress (landing pages em outro domínio). */
    public static function external_snippet(): string
    {
        $config = self::tracker_config();
        return '<script>window.IWT_CONFIG=' . wp_json_encode($config, JSON_UNESCAPED_SLASHES) . ";</script>\n"
            . '<script src="' . esc_url(IWT_URL . 'assets/front/tracker.js?ver=' . IWT_VERSION) . '" defer></script>';
    }
}
