# INOVAWEB Tracking — guia rápido

Plugin de rastreamento da **INOVAWEB**: visitas, fontes de tráfego, funis por link rastreável e conversões
(vendas, páginas de obrigado e WhatsApp), dentro do próprio WordPress do cliente.

> **Manual completo, com imagens:** [Manual-INOVAWEB-Tracking.pdf](https://raw.githubusercontent.com/equipe-ux/inovaweb-tracking-dist/main/Manual-INOVAWEB-Tracking.pdf)
> (também em *Tracking → Ajuda e diagnóstico* no painel).

## Instalar e atualizar

1. *Plugins → Adicionar novo → Enviar plugin* → escolha `inovaweb-tracking.zip` → *Ativar*.
2. Pronto: o script de rastreamento já está ativo em todas as páginas (visitas de administradores logados não contam).
3. **Atualizações chegam sozinhas**: quando sair uma versão nova, aparece "Atualização disponível" em *Plugins*.
   Dá para ligar *Ativar atualizações automáticas* na linha do plugin. O link *Verificar atualizações* força a consulta.

Requisitos: WordPress 5.9+ e PHP 7.4+. Links permanentes ligados deixam os links mais bonitos (`/go/123`); desligados, funciona com `?iwt_go=123`.

## Em 5 minutos

1. **Tracking → Funis → Novo funil.** Dê um nome e escolha o que conta como conversão:
   - **Venda no checkout** (Hotmart, Kiwify, Eduzz, WooCommerce, outra plataforma);
   - **Página de obrigado** (lead de formulário, inscrição);
   - **Contato no WhatsApp**.
2. No editor, ajuste as etapas: **Fonte de tráfego** (onde o link será divulgado) → **Página** → **Checkout / Obrigado / WhatsApp**.
   Arraste da bolinha à direita de uma etapa até a próxima para conectar. Clique numa etapa para configurar (URL, plataforma…).
3. **Salve.** Cada conexão vira um link rastreável:
   - o link que sai da **Fonte de tráfego** vai no **anúncio** (ou bio, e-mail, QR Code);
   - o link que sai de uma **Página** vai no **botão** daquela página.
4. Funil de venda: em **Integrações**, copie a URL do webhook da plataforma e cadastre no painel dela.
5. Acompanhe em **Visão geral**, **Funis**, **Conversões** e **Relatórios**.

## O que cada tela faz

| Tela | Para quê |
|---|---|
| **Visão geral** | Visitas, visitantes, conversões, receita, investimento, ROAS e CPA, com comparação ao período anterior; canais, **temperatura do tráfego** (frio, morno, quente, orgânico), campanhas, fontes, páginas de entrada, dispositivos, **estágio do visitante** e últimas conversões. Clique num item para filtrar. |
| **Funis** | Lista com visitas, quem chegou ao checkout, conversões, receita e ROAS. Abre o **editor visual** com os números de cada etapa e de cada link. Cada **teste A/B** ganha um cartão abaixo do desenho com a divisão do tráfego (em %) e os resultados de cada versão, com recomendação. |
| **Conversões** | Cada venda/lead/contato com status, valor, cliente e origem. "Detalhes" mostra primeiro contato, último clique, última mídia paga e a jornada do visitante. Exporta CSV. |
| **Relatórios** | Qualquer dimensão (canal, temperatura, estágio do visitante, fonte, campanha, anúncio, página, dispositivo, país, dia, hora…) com visitas, conversões, receita, investimento, ROAS e CPA. Exporta CSV. |
| **Custos** | Lançamento do investimento em mídia (por dia ou período, por funil/fonte/canal/temperatura/campanha) para calcular ROAS e CPA. |
| **Integrações** | URLs de webhook das plataformas, WooCommerce, Meta (API de Conversões), fila de envio ao Meta e log de webhooks. |
| **Configurações** | Script, LGPD/consentimento, prefixo dos links, palavras de temperatura, retenção de dados, quem vê os relatórios, token da API e aparência (modo noturno). |
| **Ajuda e diagnóstico** | Checagem automática do site, explicação das variáveis e o código para páginas fora do WordPress. |

## Dicas importantes

- **Testar sem sujar os números:** acrescente `?iwt_test=1` ao link do funil.
- **Temperatura:** escreva frio, morno ou quente no nome da campanha ou do conjunto (ou fixe a temperatura na fonte do funil) para separar prospecção de remarketing.
- **Teste A/B:** comece dividindo igualmente; espere o cartão do teste dizer "venceu" (e pelo menos 7 dias) antes de mandar 100% para uma versão.
- **Modo noturno:** botão da lua no topo de cada tela.
- **UTMs:** no anúncio, use o link do funil com UTMs (a etapa Fonte de tráfego tem um botão "Copiar com UTMs sugeridas").
- **Variáveis nas URLs:** `{utm_source}`, `{utm_campaign}` e qualquer parâmetro recebido; `{iwt_vid}` (visitante); `{iwt_token}` (código de rastreio).
- **Landing page fora do WordPress:** cole o código de *Ajuda e diagnóstico* na página para registrar visitas e marcar os links de checkout.
- **Sem webhook** o funil já mede tudo até o checkout; o webhook acrescenta as **vendas confirmadas**.
- **Link removido continua funcionando** (para não quebrar anúncio antigo). Funil pausado redireciona, mas não conta.
- **Cache:** os links `/go/` já pedem para não ser guardados em cache. Se algum redirecionar errado, exclua `/go/*` no plugin de cache.

Suporte: INOVAWEB — equipe@inovawebdesign.com.br
