<?php
/**
 * Classificação de origem do tráfego: transforma UTMs, click IDs, referenciador e a fonte
 * configurada no funil em canal + fonte + campanha. Regra única usada pelo roteador (/go/)
 * e pelo coletor (script das páginas), para os números baterem entre si.
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_Sources
{
    /** Canais (chave → rótulo pt-BR). A ordem é a ordem de exibição nos relatórios. */
    public static function channels(): array
    {
        return [
            'paid_social'    => 'Social pago',
            'paid_search'    => 'Busca paga',
            'display'        => 'Display / nativo',
            'organic_search' => 'Busca orgânica',
            'organic_social' => 'Social orgânico',
            'ai'             => 'Assistentes de IA',
            'email'          => 'E-mail',
            'messaging'      => 'WhatsApp / mensageiros',
            'affiliate'      => 'Afiliados',
            'referral'       => 'Sites de referência',
            'direct'         => 'Direto',
            'other'          => 'Outros',
        ];
    }

    public static function paid_channels(): array
    {
        return ['paid_social', 'paid_search', 'display'];
    }

    /** Plataformas que podem ser escolhidas no nó "Fonte de tráfego" do funil. */
    public static function platforms(): array
    {
        return [
            'meta_ads'      => ['label' => 'Meta Ads (Facebook/Instagram)', 'channel' => 'paid_social', 'source' => 'facebook', 'paid' => true],
            'google_ads'    => ['label' => 'Google Ads', 'channel' => 'paid_search', 'source' => 'google', 'paid' => true],
            'youtube_ads'   => ['label' => 'YouTube Ads', 'channel' => 'paid_social', 'source' => 'youtube', 'paid' => true],
            'tiktok_ads'    => ['label' => 'TikTok Ads', 'channel' => 'paid_social', 'source' => 'tiktok', 'paid' => true],
            'kwai_ads'      => ['label' => 'Kwai Ads', 'channel' => 'paid_social', 'source' => 'kwai', 'paid' => true],
            'bing_ads'      => ['label' => 'Microsoft Ads (Bing)', 'channel' => 'paid_search', 'source' => 'bing', 'paid' => true],
            'pinterest_ads' => ['label' => 'Pinterest Ads', 'channel' => 'paid_social', 'source' => 'pinterest', 'paid' => true],
            'linkedin_ads'  => ['label' => 'LinkedIn Ads', 'channel' => 'paid_social', 'source' => 'linkedin', 'paid' => true],
            'taboola'       => ['label' => 'Taboola', 'channel' => 'display', 'source' => 'taboola', 'paid' => true],
            'outbrain'      => ['label' => 'Outbrain', 'channel' => 'display', 'source' => 'outbrain', 'paid' => true],
            'other_paid'    => ['label' => 'Outra mídia paga', 'channel' => 'display', 'source' => 'paid', 'paid' => true],
            'instagram'     => ['label' => 'Instagram orgânico (bio, stories, direct)', 'channel' => 'organic_social', 'source' => 'instagram', 'paid' => false],
            'facebook'      => ['label' => 'Facebook orgânico', 'channel' => 'organic_social', 'source' => 'facebook', 'paid' => false],
            'youtube'       => ['label' => 'YouTube orgânico', 'channel' => 'organic_social', 'source' => 'youtube', 'paid' => false],
            'tiktok'        => ['label' => 'TikTok orgânico', 'channel' => 'organic_social', 'source' => 'tiktok', 'paid' => false],
            'email'         => ['label' => 'E-mail marketing', 'channel' => 'email', 'source' => 'email', 'paid' => false],
            'whatsapp'      => ['label' => 'WhatsApp (grupos, listas, conversa)', 'channel' => 'messaging', 'source' => 'whatsapp', 'paid' => false],
            'telegram'      => ['label' => 'Telegram', 'channel' => 'messaging', 'source' => 'telegram', 'paid' => false],
            'sms'           => ['label' => 'SMS', 'channel' => 'messaging', 'source' => 'sms', 'paid' => false],
            'seo'           => ['label' => 'Google orgânico / SEO', 'channel' => 'organic_search', 'source' => 'google', 'paid' => false],
            'affiliate'     => ['label' => 'Afiliados / parceiros', 'channel' => 'affiliate', 'source' => 'affiliate', 'paid' => false],
            'qrcode'        => ['label' => 'QR Code / offline', 'channel' => 'other', 'source' => 'qrcode', 'paid' => false],
            'other'         => ['label' => 'Outra fonte', 'channel' => 'other', 'source' => 'other', 'paid' => false],
        ];
    }

    /** Click IDs reconhecidos → [tipo, fonte, canal]. */
    const CLICK_IDS = [
        'gclid'     => ['google', 'paid_search'],
        'gbraid'    => ['google', 'paid_search'],
        'wbraid'    => ['google', 'paid_search'],
        'dclid'     => ['google', 'display'],
        'msclkid'   => ['bing', 'paid_search'],
        'ttclid'    => ['tiktok', 'paid_social'],
        'twclid'    => ['x', 'paid_social'],
        'li_fat_id' => ['linkedin', 'paid_social'],
        'epik'      => ['pinterest', 'paid_social'],
        'sccid'     => ['snapchat', 'paid_social'],
        'kwai_click_id' => ['kwai', 'paid_social'],
        'fbclid'    => ['facebook', 'organic_social'], // fbclid sozinho também aparece em links orgânicos
    ];

    const UTM_KEYS = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term'];

    const SEARCH_ENGINES = ['google.' => 'google', 'bing.com' => 'bing', 'yahoo.' => 'yahoo', 'duckduckgo.com' => 'duckduckgo',
        'ecosia.org' => 'ecosia', 'yandex.' => 'yandex', 'baidu.com' => 'baidu', 'search.brave.com' => 'brave', 'qwant.com' => 'qwant'];

    const AI_ASSISTANTS = ['chatgpt.com' => 'chatgpt', 'chat.openai.com' => 'chatgpt', 'perplexity.ai' => 'perplexity',
        'gemini.google.com' => 'gemini', 'copilot.microsoft.com' => 'copilot', 'claude.ai' => 'claude', 'meta.ai' => 'meta_ai', 'deepseek.com' => 'deepseek'];

    const SOCIAL = ['facebook.com' => 'facebook', 'fb.com' => 'facebook', 'fb.me' => 'facebook', 'instagram.com' => 'instagram',
        't.co' => 'x', 'twitter.com' => 'x', 'x.com' => 'x', 'linkedin.com' => 'linkedin', 'lnkd.in' => 'linkedin',
        'youtube.com' => 'youtube', 'youtu.be' => 'youtube', 'tiktok.com' => 'tiktok', 'pinterest.' => 'pinterest',
        'reddit.com' => 'reddit', 'threads.net' => 'threads', 'threads.com' => 'threads', 'kwai.com' => 'kwai', 'linktr.ee' => 'linktree', 'bsky.app' => 'bluesky'];

    const MESSAGING = ['whatsapp.com' => 'whatsapp', 'wa.me' => 'whatsapp', 't.me' => 'telegram', 'telegram.org' => 'telegram', 'web.telegram.org' => 'telegram'];

    const WEBMAIL = ['mail.google.com' => 'gmail', 'outlook.live.com' => 'outlook', 'outlook.office.com' => 'outlook', 'mail.yahoo.com' => 'yahoo_mail'];

    const SOCIAL_SOURCES = ['facebook', 'fb', 'instagram', 'ig', 'meta', 'tiktok', 'kwai', 'pinterest', 'linkedin', 'twitter', 'x', 'youtube', 'snapchat', 'threads', 'reddit'];

    /* ------------------------------------------------------------------ temperatura */

    /** Temperatura do público que a campanha mira (chave → rótulo). */
    public static function temperatures(): array
    {
        return [
            'cold' => 'Frio',
            'warm' => 'Morno',
            'hot' => 'Quente',
            'organic' => 'Orgânico',
            'unknown' => 'Pago sem temperatura',
        ];
    }

    /** Estágio real do visitante no momento da visita (pelo histórico dele no site). */
    public static function visitor_stages(): array
    {
        return [
            'new' => 'Primeira visita',
            'returning' => 'Já visitou antes',
            'lead' => 'Já é lead',
            'customer' => 'Já comprou',
        ];
    }

    /** Palavras padrão (editáveis em Configurações). Comparadas com campanha e público da UTM. */
    public static function default_temperature_words(): array
    {
        return [
            'cold' => 'frio, cold, prospeccao, prospect, lookalike, lal, semelhante, interesse, interesses, aberto, broad, tof, topo',
            'warm' => 'morno, warm, engajamento, engajados, envolvimento, visitantes, seguidores, videoview, vv',
            'hot' => 'quente, hot, remarketing, rmkt, retargeting, rtg, carrinho, abandono, compradores, clientes',
        ];
    }

    /**
     * Temperatura de uma visita.
     * Ordem: temperatura fixa da fonte do funil → palavras na campanha/público (utm_campaign, utm_term)
     * → "Orgânico" se não é pago → "Pago sem temperatura".
     * O nome do anúncio (utm_content) fica de fora: criativo "video-depoimento" não diz nada sobre o público.
     */
    public static function temperature(array $attr, string $fixed = 'auto'): string
    {
        if (isset(self::temperatures()[$fixed]) && $fixed !== 'unknown') {
            return $fixed;
        }
        $text = remove_accents(strtolower($attr['campaign'] . ' ' . $attr['term']));
        $tokens = array_filter(preg_split('/[^a-z0-9]+/', $text));
        if ($tokens) {
            // 1º: a temperatura escrita por extenso vence ("lookalike-compradores-QUENTE").
            $explicit = ['frio' => 'cold', 'cold' => 'cold', 'morno' => 'warm', 'warm' => 'warm', 'quente' => 'hot', 'hot' => 'hot'];
            foreach ($tokens as $t) {
                if (isset($explicit[$t])) {
                    return $explicit[$t];
                }
            }
            // 2º: tipo de público. Frio antes de quente: "lookalike-compradores" é público frio.
            foreach (['cold', 'hot', 'warm'] as $temp) {
                $words = array_filter(array_map('trim', explode(',', remove_accents(strtolower((string) IWT_Settings::get('temp_' . $temp . '_words'))))));
                foreach ($tokens as $t) {
                    if (in_array($t, $words, true)) {
                        return $temp;
                    }
                }
            }
        }
        return $attr['is_paid'] ? 'unknown' : 'organic';
    }

    /**
     * Origem + temperatura.
     * @param array $in [
     *   'params'   => query params da URL de entrada,
     *   'referrer' => URL de referência,
     *   'in_app'   => navegador embutido (Instagram/Facebook/TikTok…),
     *   'platform' => plataforma do nó "Fonte" do funil (opcional),
     *   'paid'     => força pago/orgânico vindo da configuração da fonte (opcional),
     *   'temperature' => temperatura fixa da fonte do funil (opcional; "auto" = detectar)
     * ]
     * @return array{channel:string,source:string,medium:string,campaign:string,content:string,term:string,referrer_host:string,click_id_type:string,click_id:string,is_paid:int,is_direct:bool,temperature:string}
     */
    public static function classify(array $in): array
    {
        $out = self::classify_origin($in);
        $out['temperature'] = self::temperature($out, (string) ($in['temperature'] ?? 'auto'));
        return $out;
    }

    private static function classify_origin(array $in): array
    {
        $params = array_change_key_case((array) ($in['params'] ?? []), CASE_LOWER);
        $get = function (string $k) use ($params): string {
            $v = $params[$k] ?? '';
            return is_scalar($v) ? IWT_Helpers::clean_text((string) $v, 191) : '';
        };

        $out = [
            'channel' => 'direct', 'source' => '', 'medium' => '', 'campaign' => $get('utm_campaign'),
            'content' => $get('utm_content'), 'term' => $get('utm_term'), 'referrer_host' => '',
            'click_id_type' => '', 'click_id' => '', 'is_paid' => 0, 'is_direct' => false,
        ];
        $utm_source = strtolower($get('utm_source'));
        $utm_medium = strtolower($get('utm_medium'));
        $out['source'] = IWT_Helpers::truncate($utm_source, 100);
        $out['medium'] = IWT_Helpers::truncate($utm_medium, 100);

        $ref_host = IWT_Helpers::host_of($in['referrer'] ?? '');
        if ($ref_host !== '' && IWT_Helpers::is_same_site($ref_host)) {
            $ref_host = ''; // navegação interna não é origem
        }
        $out['referrer_host'] = IWT_Helpers::truncate($ref_host, 191);

        foreach (self::CLICK_IDS as $key => [$src, $channel]) {
            $value = $get($key);
            if ($value !== '') {
                $out['click_id_type'] = $key;
                $out['click_id'] = IWT_Helpers::truncate((string) ($params[$key] ?? ''), 255);
                break;
            }
        }

        // 1) Nó "Fonte de tráfego" do funil manda no canal; UTMs refinam fonte/campanha.
        $platforms = self::platforms();
        if (!empty($in['platform']) && isset($platforms[$in['platform']])) {
            $p = $platforms[$in['platform']];
            $out['channel'] = $p['channel'];
            $out['source'] = $out['source'] !== '' ? $out['source'] : $p['source'];
            $out['medium'] = $out['medium'] !== '' ? $out['medium'] : ($p['paid'] ? 'paid' : 'link');
            $out['is_paid'] = isset($in['paid']) ? (int) (bool) $in['paid'] : (int) $p['paid'];
            if ($out['is_paid'] && !in_array($out['channel'], self::paid_channels(), true)) {
                $out['channel'] = 'display';
            }
            return $out;
        }

        // 2) Click ID de mídia paga.
        if ($out['click_id_type'] !== '') {
            [$src, $channel] = self::CLICK_IDS[$out['click_id_type']];
            if ($out['click_id_type'] === 'fbclid') {
                $paid_medium = self::is_paid_medium($utm_medium);
                $channel = $paid_medium ? 'paid_social' : 'organic_social';
                $src = $utm_source !== '' ? $utm_source : (strpos($ref_host, 'instagram') !== false || ($in['in_app'] ?? '') === 'Instagram' ? 'instagram' : 'facebook');
            } else {
                $src = $utm_source !== '' ? $utm_source : $src;
            }
            $out['channel'] = $channel;
            $out['source'] = IWT_Helpers::truncate($src, 100);
            $out['medium'] = $out['medium'] !== '' ? $out['medium'] : (in_array($channel, self::paid_channels(), true) ? 'cpc' : 'social');
            $out['is_paid'] = in_array($channel, self::paid_channels(), true) ? 1 : 0;
            return $out;
        }

        // 3) UTMs.
        if ($utm_source !== '' || $utm_medium !== '') {
            $out['channel'] = self::channel_from_utm($utm_source, $utm_medium);
            $out['is_paid'] = in_array($out['channel'], self::paid_channels(), true) ? 1 : 0;
            if ($out['source'] === '') {
                $out['source'] = $ref_host !== '' ? self::source_from_host($ref_host) : '(sem fonte)';
            }
            return $out;
        }

        // 4) Referenciador.
        if ($ref_host !== '') {
            [$channel, $src] = self::classify_host($ref_host);
            $out['channel'] = $channel;
            $out['source'] = $src;
            $out['medium'] = $channel === 'organic_search' ? 'organic' : ($channel === 'referral' ? 'referral' : 'social');
            return $out;
        }

        // 5) Sem referenciador: navegador embutido de app denuncia a origem social.
        $in_app = (string) ($in['in_app'] ?? '');
        if ($in_app !== '') {
            $out['channel'] = 'organic_social';
            $out['source'] = strtolower($in_app);
            $out['medium'] = 'social';
            return $out;
        }

        $out['channel'] = 'direct';
        $out['source'] = '(direto)';
        $out['medium'] = '(nenhum)';
        $out['is_direct'] = true;
        return $out;
    }

    public static function is_paid_medium(string $medium): bool
    {
        return (bool) preg_match('/^(cpc|ppc|cpm|cpv|cpa|paid|paid[_\-\s]?(social|search|media|ads?)|ads?|social[_\-\s]?paid|sponsored|patrocinado|pago|trafego[_\-\s]?pago|display|banner|remarketing|retargeting)$/', $medium);
    }

    public static function channel_from_utm(string $source, string $medium): string
    {
        $is_social_source = false;
        foreach (self::SOCIAL_SOURCES as $s) {
            if ($source === $s || strpos($source, $s) === 0) {
                $is_social_source = true;
                break;
            }
        }
        if (preg_match('/^(display|banner|cpm|native|nativo|programmatic)$/', $medium) || in_array($source, ['taboola', 'outbrain', 'mgid', 'criteo'], true)) {
            return 'display';
        }
        if (self::is_paid_medium($medium)) {
            return $is_social_source ? 'paid_social' : 'paid_search';
        }
        if (preg_match('/e-?mail|newsletter|mailing|^mail$/', $medium) || preg_match('/e-?mail|newsletter|mailchimp|activecampaign|rdstation|klaviyo|brevo/', $source)) {
            return 'email';
        }
        if (preg_match('/whatsapp|telegram|sms|^wa$|^zap$/', $medium . ' ' . $source)) {
            return 'messaging';
        }
        if (preg_match('/affiliate|afiliad|parceir|partner/', $medium)) {
            return 'affiliate';
        }
        if (preg_match('/^(social|social[_\-\s]?media|social[_\-\s]?network|sm|organic[_\-\s]?social|bio|stories|post|reels|story)$/', $medium) || ($is_social_source && $medium === '')) {
            return 'organic_social';
        }
        if ($medium === 'organic' || $medium === 'seo') {
            return 'organic_search';
        }
        if ($medium === 'referral') {
            return 'referral';
        }
        return $is_social_source ? 'organic_social' : 'other';
    }

    /** @return array{0:string,1:string} [canal, fonte] */
    public static function classify_host(string $host): array
    {
        // Referenciador de app Android (android-app://com.google.android.gm = Gmail).
        if (strpos($host, 'com.google.android.gm') === 0) {
            return ['email', 'gmail'];
        }
        foreach (self::AI_ASSISTANTS as $needle => $name) {
            if (self::host_matches($host, $needle)) {
                return ['ai', $name];
            }
        }
        // Webmail antes de busca: mail.google.com não é Google orgânico.
        foreach (self::WEBMAIL as $needle => $name) {
            if (self::host_matches($host, $needle)) {
                return ['email', $name];
            }
        }
        foreach (self::SEARCH_ENGINES as $needle => $name) {
            if (self::host_matches($host, $needle)) {
                return ['organic_search', $name];
            }
        }
        foreach (self::SOCIAL as $needle => $name) {
            if (self::host_matches($host, $needle)) {
                return ['organic_social', $name];
            }
        }
        foreach (self::MESSAGING as $needle => $name) {
            if (self::host_matches($host, $needle)) {
                return ['messaging', $name];
            }
        }
        return ['referral', IWT_Helpers::truncate($host, 100)];
    }

    public static function source_from_host(string $host): string
    {
        return self::classify_host($host)[1];
    }

    /** "google." casa com google.com.br; "t.co" casa só com t.co e subdomínios. */
    private static function host_matches(string $host, string $needle): bool
    {
        if (substr($needle, -1) === '.') {
            return (bool) preg_match('/(^|\.)' . preg_quote($needle, '/') . '[a-z.]+$/', $host);
        }
        return $host === $needle || substr($host, -strlen('.' . $needle)) === '.' . $needle;
    }

    /** Assinatura usada para decidir se a origem mudou (nova visita) dentro da janela da sessão. */
    public static function signature(array $c): string
    {
        // Sem utm_medium: o mesmo anúncio às vezes chega com mídia preenchida por padrão ("paid") e às vezes vazia.
        return $c['channel'] . '|' . $c['source'] . '|' . $c['campaign'] . '|' . $c['content'] . '|' . $c['click_id'];
    }
}
