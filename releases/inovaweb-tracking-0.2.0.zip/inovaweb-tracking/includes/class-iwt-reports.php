<?php
/**
 * Relatórios. Regras:
 *  - Dimensões e filtros vêm de listas fechadas (DIMENSIONS); nada do request entra cru no SQL.
 *  - Visitas/visitantes vêm de sessions (started_at); conversões de conversions (converted_at = data da aprovação).
 *  - Visitantes únicos são COUNT(DISTINCT) no período inteiro — nunca soma de únicos diários.
 *  - Datas no banco em UTC; agrupamento por dia/hora usa o fuso do site (offset em segundos).
 *  - Modelo de atribuição das conversões: last (último clique não-direto, padrão), first ou paid.
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_Reports
{
    /** Dimensão → expressão SQL sobre a tabela de sessões (alias s). */
    public static function dimensions(): array
    {
        return [
            'channel' => ['label' => 'Canal', 'expr' => 's.channel'],
            'temperature' => ['label' => 'Temperatura', 'expr' => 's.temperature'],
            'visitor_stage' => ['label' => 'Estágio do visitante', 'expr' => 's.visitor_stage'],
            'source' => ['label' => 'Fonte (utm_source)', 'expr' => 's.source'],
            'medium' => ['label' => 'Mídia (utm_medium)', 'expr' => 's.medium'],
            'source_medium' => ['label' => 'Fonte / mídia', 'expr' => "CONCAT(s.source, ' / ', s.medium)"],
            'campaign' => ['label' => 'Campanha (utm_campaign)', 'expr' => 's.campaign'],
            'content' => ['label' => 'Conteúdo / anúncio (utm_content)', 'expr' => 's.content'],
            'term' => ['label' => 'Termo / público (utm_term)', 'expr' => 's.term'],
            'referrer' => ['label' => 'Site de origem', 'expr' => 's.referrer_host'],
            'landing' => ['label' => 'Página de entrada', 'expr' => 's.landing'],
            'funnel' => ['label' => 'Funil', 'expr' => 's.funnel_id'],
            'source_node' => ['label' => 'Fonte do funil', 'expr' => 's.source_node_id'],
            'device' => ['label' => 'Dispositivo', 'expr' => 's.device'],
            'os' => ['label' => 'Sistema', 'expr' => 's.os'],
            'browser' => ['label' => 'Navegador', 'expr' => 's.browser'],
            'country' => ['label' => 'País', 'expr' => 's.country'],
            'language' => ['label' => 'Idioma', 'expr' => 's.language'],
            'day' => ['label' => 'Dia', 'expr' => 'DATE({local:s.started_at})'],
            'hour' => ['label' => 'Hora do dia', 'expr' => 'HOUR({local:s.started_at})'],
            'weekday' => ['label' => 'Dia da semana', 'expr' => 'DAYOFWEEK({local:s.started_at})'],
        ];
    }

    const FILTERS = ['funnel', 'channel', 'temperature', 'visitor_stage', 'source', 'medium', 'campaign', 'content', 'device', 'country', 'source_node'];

    /** Filtros que os custos manuais não têm: com eles ativos, só entra o CPC registrado nos cliques. */
    const NO_MANUAL_COST = ['medium', 'content', 'device', 'country', 'visitor_stage'];
    const MODELS = ['last' => 'last_session_id', 'first' => 'first_session_id', 'paid' => 'paid_session_id'];

    /* ------------------------------------------------------------------ argumentos */

    /** Normaliza período, filtros e modelo vindos do request. */
    public static function args(array $in): array
    {
        $today = wp_date('Y-m-d');
        $to = isset($in['to']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) $in['to']) ? (string) $in['to'] : $today;
        $from = isset($in['from']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) $in['from']) ? (string) $in['from'] : wp_date('Y-m-d', strtotime('-29 days'));
        if ($from > $to) {
            [$from, $to] = [$to, $from];
        }
        $days = (int) round((strtotime($to) - strtotime($from)) / DAY_IN_SECONDS) + 1;
        $filters = [];
        foreach (self::FILTERS as $f) {
            if (isset($in[$f]) && $in[$f] !== '' && is_scalar($in[$f])) {
                $filters[$f] = sanitize_text_field((string) $in[$f]);
            }
        }
        $model = isset($in['model'], self::MODELS[$in['model']]) ? (string) $in['model'] : 'last';
        return [
            'from' => $from,
            'to' => $to,
            'days' => $days,
            'from_utc' => IWT_Helpers::local_date_to_utc($from),
            'to_utc' => IWT_Helpers::local_date_to_utc($to, true),
            'filters' => $filters,
            'model' => $model,
        ];
    }

    public static function previous(array $a): array
    {
        // Período anterior de mesmo tamanho. Aritmética em UTC sobre datas puras (sem deslocamento de fuso).
        $to = gmdate('Y-m-d', strtotime($a['from'] . ' UTC') - DAY_IN_SECONDS);
        $from = gmdate('Y-m-d', strtotime($a['from'] . ' UTC') - $a['days'] * DAY_IN_SECONDS);
        return self::args(['from' => $from, 'to' => $to, 'model' => $a['model']] + $a['filters']);
    }

    /**
     * Coluna UTC → horário do site. DATE_SUB com valor positivo em vez de DATE_ADD negativo:
     * funciona igual no MySQL e também no SQLite do WordPress Playground (ambiente de teste).
     */
    public static function local(string $col): string
    {
        $offset = IWT_Helpers::tz_offset();
        if ($offset === 0) {
            return $col;
        }
        return $offset > 0 ? "DATE_ADD($col, INTERVAL $offset SECOND)" : "DATE_SUB($col, INTERVAL " . abs($offset) . ' SECOND)';
    }

    private static function tz_expr(string $expr): string
    {
        return preg_replace_callback('/{local:([a-z_.]+)}/', function ($m) {
            return self::local($m[1]);
        }, $expr);
    }

    /** WHERE de filtros sobre a sessão (alias s). @return array{0:string,1:array} */
    private static function session_filters(array $filters, string $alias = 's'): array
    {
        $sql = '';
        $params = [];
        $map = ['channel' => 'channel', 'temperature' => 'temperature', 'visitor_stage' => 'visitor_stage', 'source' => 'source', 'medium' => 'medium', 'campaign' => 'campaign', 'content' => 'content', 'device' => 'device', 'country' => 'country'];
        foreach ($map as $key => $col) {
            if (isset($filters[$key])) {
                $sql .= " AND $alias.$col = %s";
                $params[] = $filters[$key];
            }
        }
        if (isset($filters['source_node'])) {
            $sql .= " AND $alias.source_node_id = %d";
            $params[] = (int) $filters['source_node'];
        }
        return [$sql, $params];
    }

    private static function has_session_filters(array $filters): bool
    {
        return (bool) array_diff(array_keys($filters), ['funnel']);
    }

    /* ------------------------------------------------------------------ visão geral */

    public static function overview(array $a): array
    {
        $current = self::totals($a);
        $prev = self::totals(self::previous($a));
        return ['current' => $current, 'previous' => $prev, 'range' => ['from' => $a['from'], 'to' => $a['to'], 'days' => $a['days']]];
    }

    public static function totals(array $a): array
    {
        global $wpdb;
        $S = IWT_DB::t('sessions');
        $H = IWT_DB::t('hits');
        $C = IWT_DB::t('conversions');
        $f = $a['filters'];
        [$sf, $sp] = self::session_filters($f);

        // Visitas
        $where = 's.started_at BETWEEN %s AND %s AND s.is_bot = 0' . $sf;
        $params = array_merge([$a['from_utc'], $a['to_utc']], $sp);
        if (isset($f['funnel'])) {
            $where .= ' AND s.funnel_id = %d';
            $params[] = (int) $f['funnel'];
        }
        $v = $wpdb->get_row($wpdb->prepare(
            "SELECT COUNT(*) AS visits, COUNT(DISTINCT s.visitor_id) AS visitors, COALESCE(SUM(s.pageviews),0) AS pageviews FROM $S s WHERE $where",
            $params
        ));

        // Cliques em links de funil, eventos e custo (via hits)
        $hw = 'h.created_at BETWEEN %s AND %s AND h.is_bot = 0';
        $hp = [$a['from_utc'], $a['to_utc']];
        if (isset($f['funnel'])) {
            $hw .= ' AND h.funnel_id = %d';
            $hp[] = (int) $f['funnel'];
        }
        $join = '';
        if (self::has_session_filters($f)) {
            $join = "JOIN $S s ON s.id = h.session_id";
            $hw .= $sf;
            $hp = array_merge($hp, $sp);
        }
        // "Chegou ao checkout" vale com ou sem webhook: clique num link de funil que leva a um nó Checkout
        // ou clique (registrado pelo script) num link de checkout do site.
        $N = IWT_DB::t('nodes');
        $is_checkout = "((h.type = 'click' AND n.type = 'offer') OR (h.type = 'event' AND h.event = 'checkout_click'))";
        $h = $wpdb->get_row($wpdb->prepare(
            "SELECT
                SUM(CASE WHEN h.type = 'click' AND h.event = '' THEN 1 ELSE 0 END) AS clicks,
                SUM(CASE WHEN h.type = 'event' AND h.event = 'whatsapp_click' THEN 1 ELSE 0 END) AS whatsapp_clicks,
                SUM(CASE WHEN h.type = 'event' AND h.event = 'phone_click' THEN 1 ELSE 0 END) AS phone_clicks,
                SUM(CASE WHEN h.type = 'event' AND h.event = 'email_click' THEN 1 ELSE 0 END) AS email_clicks,
                SUM(CASE WHEN $is_checkout THEN 1 ELSE 0 END) AS checkout_clicks,
                COUNT(DISTINCT CASE WHEN $is_checkout THEN h.visitor_id END) AS checkout_visitors,
                COALESCE(SUM(h.cost), 0) AS cost
             FROM $H h LEFT JOIN $N n ON n.id = h.to_node_id $join WHERE $hw",
            $hp
        ));

        // Conversões (por data de aprovação)
        [$cw, $cp, $cjoin] = self::conversion_where($a);
        $c = $wpdb->get_row($wpdb->prepare(
            "SELECT
                SUM(CASE WHEN c.status = 'approved' THEN 1 ELSE 0 END) AS conversions,
                SUM(CASE WHEN c.status = 'approved' AND c.type = 'sale' THEN 1 ELSE 0 END) AS sales,
                SUM(CASE WHEN c.status = 'approved' AND c.type <> 'sale' THEN 1 ELSE 0 END) AS leads,
                COALESCE(SUM(CASE WHEN c.status = 'approved' THEN c.value ELSE 0 END), 0) AS revenue,
                COALESCE(SUM(CASE WHEN c.status = 'approved' THEN c.net_value ELSE 0 END), 0) AS net_revenue,
                SUM(CASE WHEN c.status = 'pending' THEN 1 ELSE 0 END) AS pending,
                COALESCE(SUM(CASE WHEN c.status = 'pending' THEN c.value ELSE 0 END), 0) AS pending_value,
                SUM(CASE WHEN c.status IN ('refunded','chargeback') THEN 1 ELSE 0 END) AS refunds,
                COALESCE(SUM(CASE WHEN c.status IN ('refunded','chargeback') THEN c.value ELSE 0 END), 0) AS refunds_value
             FROM " . IWT_DB::t('conversions') . " c $cjoin WHERE $cw",
            $cp
        ));

        $cost = (float) $h->cost + self::manual_cost($a);
        $visitors = (int) $v->visitors;
        $conversions = (int) $c->conversions;
        $revenue = (float) $c->revenue;
        return [
            'visits' => (int) $v->visits,
            'visitors' => $visitors,
            'pageviews' => (int) $v->pageviews,
            'clicks' => (int) $h->clicks,
            'whatsapp_clicks' => (int) $h->whatsapp_clicks,
            'phone_clicks' => (int) $h->phone_clicks,
            'email_clicks' => (int) $h->email_clicks,
            'checkout_clicks' => (int) $h->checkout_clicks,
            'checkout_visitors' => (int) $h->checkout_visitors,
            'checkout_rate' => $visitors ? round((int) $h->checkout_visitors / $visitors * 100, 2) : null,
            'conversions' => $conversions,
            'sales' => (int) $c->sales,
            'leads' => (int) $c->leads,
            'revenue' => round($revenue, 2),
            'net_revenue' => round((float) $c->net_revenue, 2),
            'pending' => (int) $c->pending,
            'pending_value' => round((float) $c->pending_value, 2),
            'refunds' => (int) $c->refunds,
            'refunds_value' => round((float) $c->refunds_value, 2),
            'cost' => round($cost, 2),
            'conv_rate' => $visitors ? round($conversions / $visitors * 100, 2) : 0,
            'roas' => $cost > 0 ? round($revenue / $cost, 2) : null,
            'roi' => $cost > 0 ? round(($revenue - $cost) / $cost * 100, 1) : null,
            'cpa' => $conversions ? round($cost / $conversions, 2) : null,
            'ticket' => (int) $c->sales ? round($revenue / (int) $c->sales, 2) : null,
            'profit' => round($revenue - $cost, 2),
        ];
    }

    /** WHERE das conversões por período + filtros (filtros de sessão usam a sessão do modelo de atribuição). */
    private static function conversion_where(array $a, string $alias = 'c'): array
    {
        $f = $a['filters'];
        $w = "$alias.converted_at BETWEEN %s AND %s";
        $p = [$a['from_utc'], $a['to_utc']];
        if (isset($f['funnel'])) {
            $w .= " AND $alias.funnel_id = %d";
            $p[] = (int) $f['funnel'];
        }
        $join = '';
        if (self::has_session_filters($f)) {
            $col = self::MODELS[$a['model']];
            $join = 'JOIN ' . IWT_DB::t('sessions') . " s ON s.id = $alias.$col";
            [$sf, $sp] = self::session_filters($f);
            $w .= $sf;
            $p = array_merge($p, $sp);
        }
        return [$w, $p, $join];
    }

    /** Custos manuais do período. Com filtro de sessão só entram linhas que batem com o filtro. */
    private static function manual_cost(array $a, string $group_col = ''): float
    {
        global $wpdb;
        $f = $a['filters'];
        $w = 'date BETWEEN %s AND %s';
        $p = [$a['from'], $a['to']];
        if (isset($f['funnel'])) {
            $w .= ' AND funnel_id = %d';
            $p[] = (int) $f['funnel'];
        }
        foreach (['channel', 'temperature', 'source', 'campaign'] as $k) {
            if (isset($f[$k])) {
                $w .= " AND $k = %s";
                $p[] = $f[$k];
            }
        }
        if (isset($f['source_node'])) {
            $w .= ' AND node_id = %d';
            $p[] = (int) $f['source_node'];
        }
        foreach (self::NO_MANUAL_COST as $k) {
            if (isset($f[$k])) {
                return 0.0; // custo manual não tem essa granularidade
            }
        }
        return (float) $wpdb->get_var($wpdb->prepare('SELECT COALESCE(SUM(amount),0) FROM ' . IWT_DB::t('costs') . " WHERE $w", $p));
    }

    /* ------------------------------------------------------------------ série diária */

    public static function timeseries(array $a): array
    {
        global $wpdb;
        $f = $a['filters'];
        [$sf, $sp] = self::session_filters($f);

        $w = 's.started_at BETWEEN %s AND %s AND s.is_bot = 0' . $sf;
        $p = array_merge([$a['from_utc'], $a['to_utc']], $sp);
        if (isset($f['funnel'])) {
            $w .= ' AND s.funnel_id = %d';
            $p[] = (int) $f['funnel'];
        }
        $visits = $wpdb->get_results($wpdb->prepare(
            "SELECT DATE(" . self::local('s.started_at') . ") AS d, COUNT(*) AS visits, COUNT(DISTINCT s.visitor_id) AS visitors
             FROM " . IWT_DB::t('sessions') . " s WHERE $w GROUP BY d",
            $p
        ), OBJECT_K);

        [$cw, $cp, $cjoin] = self::conversion_where($a);
        $conv = $wpdb->get_results($wpdb->prepare(
            "SELECT DATE(" . self::local('c.converted_at') . ") AS d,
                SUM(CASE WHEN c.status = 'approved' THEN 1 ELSE 0 END) AS conversions,
                COALESCE(SUM(CASE WHEN c.status = 'approved' THEN c.value ELSE 0 END),0) AS revenue
             FROM " . IWT_DB::t('conversions') . " c $cjoin WHERE $cw GROUP BY d",
            $cp
        ), OBJECT_K);

        $hw = 'h.created_at BETWEEN %s AND %s AND h.is_bot = 0';
        $hp = [$a['from_utc'], $a['to_utc']];
        if (isset($f['funnel'])) {
            $hw .= ' AND h.funnel_id = %d';
            $hp[] = (int) $f['funnel'];
        }
        $hjoin = '';
        if (self::has_session_filters($f)) {
            $hjoin = 'JOIN ' . IWT_DB::t('sessions') . ' s ON s.id = h.session_id';
            $hw .= $sf;
            $hp = array_merge($hp, $sp);
        }
        $costs = $wpdb->get_results($wpdb->prepare(
            "SELECT DATE(" . self::local('h.created_at') . ") AS d, COALESCE(SUM(h.cost),0) AS cost
             FROM " . IWT_DB::t('hits') . " h $hjoin WHERE $hw GROUP BY d",
            $hp
        ), OBJECT_K);
        $manual = [];
        if (!array_intersect(array_keys($f), self::NO_MANUAL_COST)) {
            $mw = 'date BETWEEN %s AND %s';
            $mp = [$a['from'], $a['to']];
            if (isset($f['funnel'])) {
                $mw .= ' AND funnel_id = %d';
                $mp[] = (int) $f['funnel'];
            }
            foreach (['channel', 'temperature', 'source', 'campaign'] as $k) {
                if (isset($f[$k])) {
                    $mw .= " AND $k = %s";
                    $mp[] = $f[$k];
                }
            }
            $manual = $wpdb->get_results($wpdb->prepare(
                'SELECT date AS d, SUM(amount) AS cost FROM ' . IWT_DB::t('costs') . " WHERE $mw GROUP BY date",
                $mp
            ), OBJECT_K);
        }

        $out = [];
        $ts = strtotime($a['from'] . ' UTC');
        $end = strtotime($a['to'] . ' UTC');
        while ($ts <= $end) {
            $d = gmdate('Y-m-d', $ts);
            $out[] = [
                'date' => $d,
                'visits' => isset($visits[$d]) ? (int) $visits[$d]->visits : 0,
                'visitors' => isset($visits[$d]) ? (int) $visits[$d]->visitors : 0,
                'conversions' => isset($conv[$d]) ? (int) $conv[$d]->conversions : 0,
                'revenue' => isset($conv[$d]) ? round((float) $conv[$d]->revenue, 2) : 0,
                'cost' => round((isset($costs[$d]) ? (float) $costs[$d]->cost : 0) + (isset($manual[$d]) ? (float) $manual[$d]->cost : 0), 2),
            ];
            $ts += DAY_IN_SECONDS;
        }
        return $out;
    }

    /* ------------------------------------------------------------------ quebra por dimensão */

    public static function breakdown(string $dimension, array $a, int $limit = 100): array
    {
        global $wpdb;
        $dims = self::dimensions();
        if (!isset($dims[$dimension])) {
            $dimension = 'channel';
        }
        $expr = self::tz_expr($dims[$dimension]['expr']);
        $f = $a['filters'];
        [$sf, $sp] = self::session_filters($f);
        $limit = max(1, min(500, $limit));

        // Visitas
        $w = 's.started_at BETWEEN %s AND %s AND s.is_bot = 0' . $sf;
        $p = array_merge([$a['from_utc'], $a['to_utc']], $sp);
        if (isset($f['funnel'])) {
            $w .= ' AND s.funnel_id = %d';
            $p[] = (int) $f['funnel'];
        }
        $visits = $wpdb->get_results($wpdb->prepare(
            "SELECT $expr AS k, COUNT(*) AS visits, COUNT(DISTINCT s.visitor_id) AS visitors, COALESCE(SUM(s.pageviews),0) AS pageviews
             FROM " . IWT_DB::t('sessions') . " s WHERE $w GROUP BY k ORDER BY visits DESC LIMIT $limit",
            $p
        ));

        // Conversões pelo modelo de atribuição (LEFT JOIN: sem sessão = não atribuída)
        $col = self::MODELS[$a['model']];
        $cw = 'c.converted_at BETWEEN %s AND %s';
        $cp = [$a['from_utc'], $a['to_utc']];
        if (isset($f['funnel'])) {
            $cw .= ' AND c.funnel_id = %d';
            $cp[] = (int) $f['funnel'];
        }
        $cw .= $sf;
        $cp = array_merge($cp, $sp);
        $cexpr = $dimension === 'funnel' ? 'c.funnel_id' : $expr;
        $conv = $wpdb->get_results($wpdb->prepare(
            "SELECT $cexpr AS k,
                SUM(CASE WHEN c.status = 'approved' THEN 1 ELSE 0 END) AS conversions,
                SUM(CASE WHEN c.status = 'approved' AND c.type = 'sale' THEN 1 ELSE 0 END) AS sales,
                COALESCE(SUM(CASE WHEN c.status = 'approved' THEN c.value ELSE 0 END),0) AS revenue,
                SUM(CASE WHEN c.status = 'pending' THEN 1 ELSE 0 END) AS pending
             FROM " . IWT_DB::t('conversions') . ' c LEFT JOIN ' . IWT_DB::t('sessions') . " s ON s.id = c.$col
             WHERE $cw GROUP BY k",
            $cp
        ));

        // Custo (CPC/parametro registrado nos hits, pela sessão do hit)
        $hw = 'h.created_at BETWEEN %s AND %s AND h.is_bot = 0 AND h.cost > 0' . $sf;
        $hp = array_merge([$a['from_utc'], $a['to_utc']], $sp);
        if (isset($f['funnel'])) {
            $hw .= ' AND h.funnel_id = %d';
            $hp[] = (int) $f['funnel'];
        }
        $costs = $wpdb->get_results($wpdb->prepare(
            "SELECT $expr AS k, SUM(h.cost) AS cost FROM " . IWT_DB::t('hits') . ' h JOIN ' . IWT_DB::t('sessions') . " s ON s.id = h.session_id WHERE $hw GROUP BY k",
            $hp
        ));

        $rows = [];
        $key = function ($k) {
            return $k === null ? '__none__' : (string) $k;
        };
        foreach ($visits as $r) {
            $rows[$key($r->k)] = ['key' => $r->k, 'visits' => (int) $r->visits, 'visitors' => (int) $r->visitors, 'pageviews' => (int) $r->pageviews,
                'conversions' => 0, 'sales' => 0, 'revenue' => 0.0, 'pending' => 0, 'cost' => 0.0];
        }
        foreach ($conv as $r) {
            $k = $key($r->k);
            if (!isset($rows[$k])) {
                $rows[$k] = ['key' => $r->k, 'visits' => 0, 'visitors' => 0, 'pageviews' => 0, 'conversions' => 0, 'sales' => 0, 'revenue' => 0.0, 'pending' => 0, 'cost' => 0.0];
            }
            $rows[$k]['conversions'] = (int) $r->conversions;
            $rows[$k]['sales'] = (int) $r->sales;
            $rows[$k]['revenue'] = round((float) $r->revenue, 2);
            $rows[$k]['pending'] = (int) $r->pending;
        }
        foreach ($costs as $r) {
            $k = $key($r->k);
            if (isset($rows[$k])) {
                $rows[$k]['cost'] = (float) $r->cost;
            }
        }
        // Custos manuais nas dimensões que eles conhecem.
        $manual_col = ['funnel' => 'funnel_id', 'source_node' => 'node_id', 'channel' => 'channel', 'temperature' => 'temperature', 'source' => 'source', 'campaign' => 'campaign', 'day' => 'date'];
        if (isset($manual_col[$dimension]) && !array_intersect(array_keys($f), self::NO_MANUAL_COST)) {
            $mc = $manual_col[$dimension];
            $mw = 'date BETWEEN %s AND %s';
            $mp = [$a['from'], $a['to']];
            if (isset($f['funnel'])) {
                $mw .= ' AND funnel_id = %d';
                $mp[] = (int) $f['funnel'];
            }
            $manual = $wpdb->get_results($wpdb->prepare('SELECT ' . $mc . ' AS k, SUM(amount) AS cost FROM ' . IWT_DB::t('costs') . " WHERE $mw GROUP BY k", $mp));
            foreach ($manual as $r) {
                $k = $key($r->k);
                if (isset($rows[$k])) {
                    $rows[$k]['cost'] += (float) $r->cost;
                }
            }
        }

        $labels = self::labels($dimension, array_column($rows, 'key'));
        foreach ($rows as &$r) {
            $r['label'] = $labels[$key($r['key'])] ?? self::fallback_label($dimension, $r['key']);
            $r['cost'] = round($r['cost'], 2);
            $r['conv_rate'] = $r['visitors'] ? round($r['conversions'] / $r['visitors'] * 100, 2) : null;
            $r['roas'] = $r['cost'] > 0 ? round($r['revenue'] / $r['cost'], 2) : null;
            $r['cpa'] = $r['conversions'] && $r['cost'] > 0 ? round($r['cost'] / $r['conversions'], 2) : null;
        }
        unset($r);
        $rows = array_values($rows);
        if (in_array($dimension, ['day', 'hour', 'weekday'], true)) {
            usort($rows, function ($x, $y) {
                return strcmp((string) $x['key'], (string) $y['key']);
            });
            if ($dimension === 'hour') {
                usort($rows, function ($x, $y) {
                    return (int) $x['key'] <=> (int) $y['key'];
                });
            }
        } else {
            usort($rows, function ($x, $y) {
                return [$y['visits'], $y['conversions']] <=> [$x['visits'], $x['conversions']];
            });
        }
        return array_slice($rows, 0, $limit);
    }

    /** Rótulos legíveis para chaves de dimensão. */
    public static function labels(string $dimension, array $keys): array
    {
        global $wpdb;
        $out = [];
        if ($dimension === 'channel') {
            foreach (IWT_Sources::channels() as $k => $label) {
                $out[$k] = $label;
            }
        } elseif ($dimension === 'funnel') {
            $ids = array_filter(array_map('intval', $keys));
            if ($ids) {
                $rows = $wpdb->get_results('SELECT id, name FROM ' . IWT_DB::t('funnels') . ' WHERE id IN (' . implode(',', $ids) . ')');
                foreach ($rows as $r) {
                    $out[(string) $r->id] = $r->name;
                }
            }
        } elseif ($dimension === 'source_node') {
            $ids = array_filter(array_map('intval', $keys));
            if ($ids) {
                $rows = $wpdb->get_results('SELECT n.id, n.name, f.name AS funnel FROM ' . IWT_DB::t('nodes') . ' n LEFT JOIN ' . IWT_DB::t('funnels') . ' f ON f.id = n.funnel_id WHERE n.id IN (' . implode(',', $ids) . ')');
                foreach ($rows as $r) {
                    $out[(string) $r->id] = $r->name . ($r->funnel ? ' — ' . $r->funnel : '');
                }
            }
        } elseif ($dimension === 'temperature') {
            $out = IWT_Sources::temperatures();
        } elseif ($dimension === 'visitor_stage') {
            $out = IWT_Sources::visitor_stages();
        } elseif ($dimension === 'device') {
            $out = ['desktop' => 'Computador', 'mobile' => 'Celular', 'tablet' => 'Tablet', 'bot' => 'Robô'];
        } elseif ($dimension === 'weekday') {
            $out = ['1' => 'Domingo', '2' => 'Segunda', '3' => 'Terça', '4' => 'Quarta', '5' => 'Quinta', '6' => 'Sexta', '7' => 'Sábado'];
        } elseif ($dimension === 'hour') {
            for ($h = 0; $h < 24; $h++) {
                $out[(string) $h] = sprintf('%02dh', $h);
            }
        }
        return $out;
    }

    private static function fallback_label(string $dimension, $key): string
    {
        if ($key === null) {
            return '(não atribuído)';
        }
        $key = (string) $key;
        if ($key === '' || $key === '0') {
            $empty = ['temperature' => '(visita anterior à v0.2.0)', 'visitor_stage' => '(visita anterior à v0.2.0)', 'funnel' => '(fora de funil)', 'source_node' => '(sem fonte de funil)', 'campaign' => '(sem campanha)', 'content' => '(sem conteúdo)',
                'term' => '(sem termo)', 'referrer' => '(sem site de origem)', 'country' => '(desconhecido)', 'language' => '(desconhecido)', 'medium' => '(nenhum)', 'source' => '(nenhuma)'];
            return $empty[$dimension] ?? '(vazio)';
        }
        if ($dimension === 'day') {
            return wp_date('d/m/Y', strtotime($key . ' 12:00:00'));
        }
        return $key;
    }

    /* ------------------------------------------------------------------ funil */

    public static function funnel_stats(int $funnel_id, array $a): array
    {
        global $wpdb;
        $H = IWT_DB::t('hits');
        $C = IWT_DB::t('conversions');
        $S = IWT_DB::t('sessions');
        $range = [$a['from_utc'], $a['to_utc']];

        $links = $wpdb->get_results($wpdb->prepare(
            "SELECT link_id, SUM(CASE WHEN is_bot = 0 THEN 1 ELSE 0 END) AS clicks, COUNT(DISTINCT CASE WHEN is_bot = 0 THEN visitor_id END) AS visitors,
                    SUM(is_bot) AS bots, COALESCE(SUM(cost),0) AS cost
             FROM $H WHERE funnel_id = %d AND created_at BETWEEN %s AND %s AND type = 'click' GROUP BY link_id",
            array_merge([$funnel_id], $range)
        ));
        $nodes = $wpdb->get_results($wpdb->prepare(
            "SELECT to_node_id AS node_id, COUNT(*) AS arrivals, COUNT(DISTINCT visitor_id) AS visitors
             FROM $H WHERE funnel_id = %d AND created_at BETWEEN %s AND %s AND type = 'click' AND is_bot = 0 GROUP BY to_node_id",
            array_merge([$funnel_id], $range)
        ));
        $conv_nodes = $wpdb->get_results($wpdb->prepare(
            "SELECT node_id, status, COUNT(*) AS n, COALESCE(SUM(value),0) AS value FROM $C
             WHERE funnel_id = %d AND converted_at BETWEEN %s AND %s GROUP BY node_id, status",
            array_merge([$funnel_id], $range)
        ));
        $col = self::MODELS[$a['model']];
        $by_source = $wpdb->get_results($wpdb->prepare(
            "SELECT s.source_node_id AS node_id, COUNT(*) AS visits, COUNT(DISTINCT s.visitor_id) AS visitors
             FROM $S s WHERE s.funnel_id = %d AND s.started_at BETWEEN %s AND %s AND s.is_bot = 0 AND s.source_node_id > 0 GROUP BY s.source_node_id",
            array_merge([$funnel_id], $range)
        ), OBJECT_K);
        $conv_source = $wpdb->get_results($wpdb->prepare(
            "SELECT s.source_node_id AS node_id, SUM(CASE WHEN c.status = 'approved' THEN 1 ELSE 0 END) AS conversions,
                    COALESCE(SUM(CASE WHEN c.status = 'approved' THEN c.value ELSE 0 END),0) AS revenue
             FROM $C c LEFT JOIN $S s ON s.id = c.$col
             WHERE c.funnel_id = %d AND c.converted_at BETWEEN %s AND %s GROUP BY s.source_node_id",
            array_merge([$funnel_id], $range)
        ), OBJECT_K);
        $cost_source = $wpdb->get_results($wpdb->prepare(
            "SELECT from_node_id AS node_id, COALESCE(SUM(cost),0) AS cost FROM $H
             WHERE funnel_id = %d AND created_at BETWEEN %s AND %s AND is_bot = 0 AND cost > 0 GROUP BY from_node_id",
            array_merge([$funnel_id], $range)
        ), OBJECT_K);
        $manual_source = $wpdb->get_results($wpdb->prepare(
            'SELECT node_id, SUM(amount) AS cost FROM ' . IWT_DB::t('costs') . ' WHERE funnel_id = %d AND date BETWEEN %s AND %s GROUP BY node_id',
            $funnel_id, $a['from'], $a['to']
        ), OBJECT_K);

        $sources = [];
        $source_ids = array_unique(array_merge(array_keys($by_source), array_keys($conv_source), array_keys($cost_source), array_keys($manual_source)));
        foreach ($source_ids as $sid) {
            $cost = (float) ($cost_source[$sid]->cost ?? 0) + (float) ($manual_source[$sid]->cost ?? 0);
            $conversions = (int) ($conv_source[$sid]->conversions ?? 0);
            $revenue = (float) ($conv_source[$sid]->revenue ?? 0);
            $sources[] = [
                'node_id' => $sid === '' ? null : (int) $sid,
                'visits' => (int) ($by_source[$sid]->visits ?? 0),
                'visitors' => (int) ($by_source[$sid]->visitors ?? 0),
                'conversions' => $conversions,
                'revenue' => round($revenue, 2),
                'cost' => round($cost, 2),
                'roas' => $cost > 0 ? round($revenue / $cost, 2) : null,
                'cpa' => $conversions && $cost > 0 ? round($cost / $conversions, 2) : null,
            ];
        }

        $totals = self::totals(array_merge($a, ['filters' => ['funnel' => (string) $funnel_id]]));
        return [
            'totals' => $totals,
            'links' => array_map(function ($r) {
                return ['link_id' => (int) $r->link_id, 'clicks' => (int) $r->clicks, 'visitors' => (int) $r->visitors, 'bots' => (int) $r->bots, 'cost' => round((float) $r->cost, 2)];
            }, $links),
            'nodes' => array_map(function ($r) {
                return ['node_id' => (int) $r->node_id, 'arrivals' => (int) $r->arrivals, 'visitors' => (int) $r->visitors];
            }, $nodes),
            'conversions' => array_map(function ($r) {
                return ['node_id' => (int) $r->node_id, 'status' => $r->status, 'count' => (int) $r->n, 'value' => round((float) $r->value, 2)];
            }, $conv_nodes),
            'sources' => $sources,
            'series' => self::timeseries(array_merge($a, ['filters' => ['funnel' => (string) $funnel_id]])),
            'experiments' => self::experiments($funnel_id, $a),
        ];
    }

    /**
     * Resultados dos testes A/B do funil: para cada nó "Teste A/B", por saída (versão):
     * visitantes, quantos chegaram ao checkout, conversões aprovadas e receita.
     * O visitante é contado na versão por onde passou (com "variação fixa" ele fica sempre na mesma);
     * a conversão conta para a versão se o comprador passou por ela no período.
     * @return array<int,array{node_id:int,variants:array}>
     */
    public static function experiments(int $funnel_id, array $a): array
    {
        global $wpdb;
        $H = IWT_DB::t('hits');
        $N = IWT_DB::t('nodes');
        $C = IWT_DB::t('conversions');
        $range = [$a['from_utc'], $a['to_utc']];
        $rotators = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM $N WHERE funnel_id = %d AND type = 'rotator' AND deleted = 0",
            $funnel_id
        ));
        $out = [];
        foreach ($rotators as $rid) {
            $rid = (int) $rid;
            $visitors = $wpdb->get_results($wpdb->prepare(
                "SELECT link_id, to_node_id, COUNT(DISTINCT visitor_id) AS visitors FROM $H
                 WHERE from_node_id = %d AND type = 'click' AND is_bot = 0 AND created_at BETWEEN %s AND %s GROUP BY link_id, to_node_id",
                array_merge([$rid], $range)
            ));
            if (!$visitors) {
                $out[] = ['node_id' => $rid, 'variants' => []];
                continue;
            }
            $checkout = $wpdb->get_results($wpdb->prepare(
                "SELECT h.link_id, COUNT(DISTINCT h2.visitor_id) AS n FROM $H h
                 JOIN $H h2 ON h2.visitor_id = h.visitor_id AND h2.type = 'click' AND h2.created_at >= h.created_at
                 JOIN $N n ON n.id = h2.to_node_id AND n.type = 'offer'
                 WHERE h.from_node_id = %d AND h.type = 'click' AND h.is_bot = 0 AND h.created_at BETWEEN %s AND %s GROUP BY h.link_id",
                array_merge([$rid], $range)
            ), OBJECT_K);
            $conv = $wpdb->get_results($wpdb->prepare(
                "SELECT h.link_id, COUNT(DISTINCT c.id) AS conversions
                 FROM $C c JOIN $H h ON h.visitor_id = c.visitor_id AND h.from_node_id = %d AND h.type = 'click' AND h.is_bot = 0 AND h.created_at <= c.converted_at
                 WHERE c.funnel_id = %d AND c.status = 'approved' AND c.converted_at BETWEEN %s AND %s GROUP BY h.link_id",
                array_merge([$rid, $funnel_id], $range)
            ), OBJECT_K);
            // Receita sem duplicar a venda de quem passou mais de uma vez pela mesma versão.
            $rev = $wpdb->get_results($wpdb->prepare(
                "SELECT v.link_id, COALESCE(SUM(c.value), 0) AS revenue FROM $C c
                 JOIN (SELECT DISTINCT link_id, visitor_id FROM $H WHERE from_node_id = %d AND type = 'click' AND is_bot = 0 AND created_at <= %s) v ON v.visitor_id = c.visitor_id
                 WHERE c.funnel_id = %d AND c.status = 'approved' AND c.converted_at BETWEEN %s AND %s GROUP BY v.link_id",
                [$rid, $a['to_utc'], $funnel_id, $a['from_utc'], $a['to_utc']]
            ), OBJECT_K);
            $variants = [];
            foreach ($visitors as $v) {
                $lid = (int) $v->link_id;
                $variants[] = [
                    'link_id' => $lid,
                    'node_id' => (int) $v->to_node_id,
                    'visitors' => (int) $v->visitors,
                    'checkout' => (int) ($checkout[$lid]->n ?? 0),
                    'conversions' => (int) ($conv[$lid]->conversions ?? 0),
                    'revenue' => round((float) ($rev[$lid]->revenue ?? 0), 2),
                ];
            }
            $out[] = ['node_id' => $rid, 'variants' => $variants];
        }
        return $out;
    }

    /** Resumo dos funis para a listagem (últimos N dias). */
    public static function funnels_summary(array $a): array
    {
        global $wpdb;
        $range = [$a['from_utc'], $a['to_utc']];
        $visits = $wpdb->get_results($wpdb->prepare(
            'SELECT funnel_id, COUNT(*) AS visits, COUNT(DISTINCT visitor_id) AS visitors FROM ' . IWT_DB::t('sessions') . '
             WHERE started_at BETWEEN %s AND %s AND is_bot = 0 AND funnel_id > 0 GROUP BY funnel_id',
            $range
        ), OBJECT_K);
        $conv = $wpdb->get_results($wpdb->prepare(
            "SELECT funnel_id, SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS conversions,
                    COALESCE(SUM(CASE WHEN status = 'approved' THEN value ELSE 0 END),0) AS revenue
             FROM " . IWT_DB::t('conversions') . ' WHERE converted_at BETWEEN %s AND %s AND funnel_id > 0 GROUP BY funnel_id',
            $range
        ), OBJECT_K);
        $cost = $wpdb->get_results($wpdb->prepare(
            'SELECT funnel_id, COALESCE(SUM(cost),0) AS cost FROM ' . IWT_DB::t('hits') . '
             WHERE created_at BETWEEN %s AND %s AND is_bot = 0 AND cost > 0 GROUP BY funnel_id',
            $range
        ), OBJECT_K);
        $manual = $wpdb->get_results($wpdb->prepare(
            'SELECT funnel_id, SUM(amount) AS cost FROM ' . IWT_DB::t('costs') . ' WHERE date BETWEEN %s AND %s GROUP BY funnel_id',
            $a['from'], $a['to']
        ), OBJECT_K);
        $checkout = $wpdb->get_results($wpdb->prepare(
            'SELECT h.funnel_id, COUNT(DISTINCT h.visitor_id) AS visitors FROM ' . IWT_DB::t('hits') . ' h JOIN ' . IWT_DB::t('nodes') . " n ON n.id = h.to_node_id
             WHERE h.created_at BETWEEN %s AND %s AND h.type = 'click' AND h.is_bot = 0 AND n.type = 'offer' GROUP BY h.funnel_id",
            $range
        ), OBJECT_K);
        $out = [];
        foreach (IWT_Funnels::all(true) as $f) {
            $id = $f->id;
            $c = (float) ($cost[$id]->cost ?? 0) + (float) ($manual[$id]->cost ?? 0);
            $revenue = (float) ($conv[$id]->revenue ?? 0);
            $visitors = (int) ($visits[$id]->visitors ?? 0);
            $conversions = (int) ($conv[$id]->conversions ?? 0);
            $out[] = IWT_Funnels::export_funnel($f) + [
                'visits' => (int) ($visits[$id]->visits ?? 0),
                'visitors' => $visitors,
                'checkout_visitors' => (int) ($checkout[$id]->visitors ?? 0),
                'conversions' => $conversions,
                'revenue' => round($revenue, 2),
                'cost' => round($c, 2),
                'conv_rate' => $visitors ? round($conversions / $visitors * 100, 2) : null,
                'roas' => $c > 0 ? round($revenue / $c, 2) : null,
            ];
        }
        return $out;
    }

    /* ------------------------------------------------------------------ conversões */

    public static function conversions_list(array $a, array $q): array
    {
        global $wpdb;
        $C = IWT_DB::t('conversions');
        $S = IWT_DB::t('sessions');
        $col = self::MODELS[$a['model']];
        $w = 'c.converted_at BETWEEN %s AND %s';
        $p = [$a['from_utc'], $a['to_utc']];
        if (isset($a['filters']['funnel'])) {
            $w .= ' AND c.funnel_id = %d';
            $p[] = (int) $a['filters']['funnel'];
        }
        if (!empty($q['status']) && isset(IWT_Conversions::statuses()[$q['status']])) {
            $w .= ' AND c.status = %s';
            $p[] = $q['status'];
        }
        if (!empty($q['type']) && isset(IWT_Conversions::types()[$q['type']])) {
            $w .= ' AND c.type = %s';
            $p[] = $q['type'];
        }
        if (!empty($q['platform'])) {
            $w .= ' AND c.platform = %s';
            $p[] = sanitize_key((string) $q['platform']);
        }
        if (!empty($q['search'])) {
            $like = '%' . $wpdb->esc_like(sanitize_text_field((string) $q['search'])) . '%';
            $w .= ' AND (c.customer_email LIKE %s OR c.customer_name LIKE %s OR c.transaction_id LIKE %s OR c.product_name LIKE %s)';
            array_push($p, $like, $like, $like, $like);
        }
        [$sf, $sp] = self::session_filters($a['filters']);
        $join = "LEFT JOIN $S s ON s.id = c.$col";
        $w .= $sf;
        $p = array_merge($p, $sp);

        $per_page = max(10, min(200, (int) ($q['per_page'] ?? 50)));
        $page = max(1, (int) ($q['page'] ?? 1));
        $offset = ($page - 1) * $per_page;

        $total = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $C c $join WHERE $w", $p));
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT c.*, s.channel, s.source, s.medium, s.campaign, s.content, s.term, s.device, f.name AS funnel_name
             FROM $C c $join LEFT JOIN " . IWT_DB::t('funnels') . " f ON f.id = c.funnel_id
             WHERE $w ORDER BY c.converted_at DESC, c.id DESC LIMIT %d OFFSET %d",
            array_merge($p, [$per_page, $offset])
        ));
        $channels = IWT_Sources::channels();
        $items = array_map(function ($r) use ($channels) {
            return [
                'id' => (int) $r->id,
                'converted_at' => IWT_Helpers::to_local_iso($r->converted_at),
                'created_at' => IWT_Helpers::to_local_iso($r->created_at),
                'type' => $r->type,
                'status' => $r->status,
                'platform' => $r->platform,
                'transaction_id' => $r->transaction_id,
                'value' => (float) $r->value,
                'net_value' => (float) $r->net_value,
                'currency' => $r->currency,
                'product_name' => $r->product_name,
                'customer_name' => $r->customer_name,
                'customer_email' => $r->customer_email,
                'customer_phone' => $r->customer_phone,
                'payment_method' => $r->payment_method,
                'funnel_id' => (int) $r->funnel_id,
                'funnel_name' => (string) $r->funnel_name,
                'visitor_id' => (int) $r->visitor_id,
                'match_method' => $r->match_method,
                'channel' => $r->channel,
                'channel_label' => $r->channel ? ($channels[$r->channel] ?? $r->channel) : '',
                'source' => (string) $r->source,
                'medium' => (string) $r->medium,
                'campaign' => (string) $r->campaign,
                'content' => (string) $r->content,
                'term' => (string) $r->term,
                'device' => (string) $r->device,
            ];
        }, $rows);
        return ['items' => $items, 'total' => $total, 'page' => $page, 'per_page' => $per_page];
    }

    /** Jornada do visitante: visitas e últimos acontecimentos (para o detalhe da conversão). */
    public static function journey(int $visitor_id): array
    {
        global $wpdb;
        if ($visitor_id <= 0) {
            return ['sessions' => [], 'hits' => []];
        }
        $sessions = $wpdb->get_results($wpdb->prepare(
            'SELECT * FROM ' . IWT_DB::t('sessions') . ' WHERE visitor_id = %d ORDER BY started_at DESC LIMIT 30',
            $visitor_id
        ));
        $hits = $wpdb->get_results($wpdb->prepare(
            'SELECT h.*, n.name AS node_name, n.type AS node_type FROM ' . IWT_DB::t('hits') . ' h LEFT JOIN ' . IWT_DB::t('nodes') . ' n ON n.id = h.to_node_id
             WHERE h.visitor_id = %d ORDER BY h.id DESC LIMIT 60',
            $visitor_id
        ));
        $channels = IWT_Sources::channels();
        return [
            'sessions' => array_map(function ($s) use ($channels) {
                return [
                    'id' => (int) $s->id,
                    'started_at' => IWT_Helpers::to_local_iso($s->started_at),
                    'channel' => $channels[$s->channel] ?? $s->channel,
                    'source' => $s->source,
                    'medium' => $s->medium,
                    'campaign' => $s->campaign,
                    'content' => $s->content,
                    'landing' => $s->landing,
                    'device' => $s->device,
                    'pageviews' => (int) $s->pageviews,
                    'clicks' => (int) $s->clicks,
                    'is_paid' => (bool) $s->is_paid,
                ];
            }, $sessions),
            'hits' => array_map(function ($h) {
                return [
                    'created_at' => IWT_Helpers::to_local_iso($h->created_at),
                    'type' => $h->type,
                    'event' => $h->event,
                    'url' => $h->url,
                    'node_name' => (string) $h->node_name,
                    'node_type' => (string) $h->node_type,
                    'session_id' => (int) $h->session_id,
                ];
            }, $hits),
        ];
    }
}
