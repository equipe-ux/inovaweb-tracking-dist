<?php
/**
 * Identidade do visitante (cookie _iwt_vid), visitas (sessões) e registro de hits.
 *
 * Ponteiros de atribuição no visitante:
 *  - first_session_id       → primeira visita (primeiro toque)
 *  - last_touch_session_id  → última visita NÃO direta (último clique não-direto)
 *  - paid_session_id        → última visita vinda de mídia paga
 * A conversão copia esses três ponteiros no momento em que acontece.
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_Visitors
{
    const COOKIE = '_iwt_vid';

    /** Visitante da requisição atual (cache). */
    private static $current = null;

    public static function cookie_uid(): string
    {
        $value = isset($_COOKIE[self::COOKIE]) ? (string) wp_unslash($_COOKIE[self::COOKIE]) : '';
        return IWT_Helpers::is_uid($value) ? $value : '';
    }

    public static function find_by_uid(string $uid): ?object
    {
        global $wpdb;
        if (!IWT_Helpers::is_uid($uid)) {
            return null;
        }
        $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . IWT_DB::t('visitors') . ' WHERE uid = %s', $uid));
        return $row ?: null;
    }

    public static function find(int $id): ?object
    {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . IWT_DB::t('visitors') . ' WHERE id = %d', $id));
        return $row ?: null;
    }

    /**
     * Identifica (ou cria) o visitante.
     * Cookie vence o uid explícito (URL/payload): evita que um link compartilhado com iwt_vid
     * de outra pessoa junte duas pessoas num visitante só.
     */
    public static function identify(string $explicit_uid = '', bool $create = true): ?object
    {
        if (self::$current) {
            return self::$current;
        }
        $cookie = self::cookie_uid();
        $visitor = $cookie !== '' ? self::find_by_uid($cookie) : null;

        if (!$visitor && IWT_Helpers::is_uid($explicit_uid)) {
            $visitor = self::find_by_uid($explicit_uid);
            if (!$visitor && $create) {
                $visitor = self::create($explicit_uid);
            }
        }
        if (!$visitor && $create) {
            // Cookie com uid desconhecido (ex.: apagado pela retenção) é reaproveitado.
            $visitor = self::create($cookie !== '' ? $cookie : IWT_Helpers::new_uid());
        }
        if ($visitor) {
            if ($cookie !== $visitor->uid) {
                self::set_cookie($visitor->uid);
            }
            self::$current = $visitor;
        }
        return $visitor;
    }

    public static function create(string $uid): ?object
    {
        global $wpdb;
        $now = IWT_Helpers::now();
        $props = IWT_Request::props();
        $ok = $wpdb->insert(IWT_DB::t('visitors'), [
            'uid' => $uid,
            'created_at' => $now,
            'last_seen_at' => $now,
            'country' => $props['country'],
            'ip' => (int) IWT_Settings::get('ip_retention_days') > 0 ? $props['ip'] : '',
            'user_agent' => $props['user_agent'],
        ]);
        if (!$ok) {
            // Corrida: outra requisição criou o mesmo uid.
            return self::find_by_uid($uid);
        }
        return self::find((int) $wpdb->insert_id);
    }

    public static function set_cookie(string $uid): void
    {
        if (headers_sent()) {
            return;
        }
        $days = (int) IWT_Settings::get('cookie_days');
        // Não é HttpOnly de propósito: o script precisa ler o uid para marcar links de checkout.
        setcookie(self::COOKIE, $uid, [
            'expires'  => time() + $days * DAY_IN_SECONDS,
            'path'     => COOKIEPATH ? COOKIEPATH : '/',
            'domain'   => COOKIE_DOMAIN ? COOKIE_DOMAIN : '',
            'secure'   => IWT_Helpers::is_https_request(),
            'httponly' => false,
            'samesite' => 'Lax',
        ]);
        $_COOKIE[self::COOKIE] = $uid;
    }

    public static function get_session(int $id): ?object
    {
        global $wpdb;
        if ($id <= 0) {
            return null;
        }
        $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . IWT_DB::t('sessions') . ' WHERE id = %d', $id));
        return $row ?: null;
    }

    /**
     * Registra a origem desta requisição e devolve a sessão (visita) correspondente.
     *
     * @param array $attr resultado de IWT_Sources::classify()
     * @param array $ctx  landing, funnel_id, link_id, source_node_id, entry (bool: entrada por fonte do funil)
     */
    public static function touch(object $visitor, array $attr, array $ctx): object
    {
        global $wpdb;
        $now = IWT_Helpers::now();
        $props = IWT_Request::props();
        $timeout = max(5, (int) IWT_Settings::get('session_minutes')) * 60;

        $current = self::get_session((int) $visitor->current_session_id);
        $active = $current && (time() - strtotime($current->last_activity_at . ' UTC')) < $timeout;

        $continue = false;
        if ($active) {
            if (!empty($ctx['entry'])) {
                // Entrada por fonte do funil: mesma fonte/link dentro da janela = mesma visita (refresh, duplo clique).
                $continue = (int) $current->source_node_id === (int) ($ctx['source_node_id'] ?? 0)
                    && IWT_Sources::signature((array) $current) === IWT_Sources::signature($attr);
            } elseif (!empty($ctx['continue_if_active']) || $attr['is_direct']) {
                // Salto no meio do funil (botão da página → checkout) e eventos não abrem visita nova,
                // mesmo que o link carregue só parte das UTMs.
                $continue = true;
            } elseif ($attr['click_id'] !== '' && $attr['click_id'] === (string) $current->click_id) {
                $continue = true; // mesmo clique de anúncio (ex.: página de destino do redirecionamento)
            } elseif ((int) $current->source_node_id > 0 && $attr['source'] === (string) $current->source && $attr['campaign'] === (string) $current->campaign) {
                // Página de destino de um link de funil: o canal pode ser classificado diferente pelas UTMs
                // (a fonte do funil manda), mas é a mesma visita.
                $continue = true;
            } else {
                $continue = IWT_Sources::signature((array) $current) === IWT_Sources::signature($attr);
            }
        }

        if ($continue) {
            $session = $current;
            $wpdb->update(IWT_DB::t('sessions'), ['last_activity_at' => $now], ['id' => $session->id]);
            $session->last_activity_at = $now;
            $is_new = false;
        } else {
            $row = [
                'visitor_id' => (int) $visitor->id,
                'started_at' => $now,
                'last_activity_at' => $now,
                'channel' => $attr['channel'],
                'source' => IWT_Helpers::truncate($attr['source'], 100),
                'medium' => IWT_Helpers::truncate($attr['medium'], 100),
                'campaign' => IWT_Helpers::truncate($attr['campaign'], 191),
                'content' => IWT_Helpers::truncate($attr['content'], 191),
                'term' => IWT_Helpers::truncate($attr['term'], 191),
                'referrer_host' => $attr['referrer_host'],
                'landing' => IWT_Helpers::truncate((string) ($ctx['landing'] ?? ''), 255),
                'click_id_type' => $attr['click_id_type'],
                'click_id' => $attr['click_id'],
                'funnel_id' => (int) ($ctx['funnel_id'] ?? 0),
                'link_id' => (int) ($ctx['link_id'] ?? 0),
                'source_node_id' => (int) ($ctx['source_node_id'] ?? 0),
                'is_paid' => (int) $attr['is_paid'],
                'temperature' => (string) ($attr['temperature'] ?? ''),
                'visitor_stage' => self::stage($visitor),
                'is_bot' => (int) $props['is_bot'],
                'device' => $props['device'],
                'os' => $props['os'],
                'browser' => $props['browser'],
                'country' => $props['country'],
                'language' => $props['language'],
            ];
            $wpdb->insert(IWT_DB::t('sessions'), $row);
            $session = (object) ($row + ['id' => (int) $wpdb->insert_id, 'pageviews' => 0, 'clicks' => 0, 'events' => 0]);
            $is_new = true;
        }

        // Atualiza ponteiros do visitante.
        $update = ['last_seen_at' => $now, 'current_session_id' => (int) $session->id];
        if ($is_new) {
            $update['sessions'] = (int) $visitor->sessions + 1;
            if (!(int) $visitor->first_session_id) {
                $update['first_session_id'] = (int) $session->id;
            }
            if (!$attr['is_direct']) {
                $update['last_touch_session_id'] = (int) $session->id;
            }
            if ((int) $attr['is_paid']) {
                $update['paid_session_id'] = (int) $session->id;
            }
        }
        if ($attr['click_id_type'] === 'fbclid' && $attr['click_id'] !== '') {
            $fbclid = $attr['click_id'];
            if (substr((string) $visitor->fbc, -strlen($fbclid)) !== $fbclid) {
                $update['fbc'] = IWT_Helpers::truncate('fb.1.' . (int) (microtime(true) * 1000) . '.' . $fbclid, 255);
            }
        }
        if ((int) IWT_Settings::get('ip_retention_days') > 0 && $props['ip'] !== '') {
            $update['ip'] = $props['ip'];
        }
        if ($props['user_agent'] !== '') {
            $update['user_agent'] = $props['user_agent'];
        }
        if ($props['country'] !== '') {
            $update['country'] = $props['country'];
        }
        $wpdb->update(IWT_DB::t('visitors'), $update, ['id' => (int) $visitor->id]);
        foreach ($update as $k => $v) {
            $visitor->$k = $v;
        }
        return $session;
    }

    /**
     * Estágio real do visitante quando a visita começa: primeira visita, já visitou, já é lead, já comprou.
     * Mostra, por exemplo, se a campanha "fria" está gastando com quem já é cliente.
     */
    public static function stage(object $visitor): string
    {
        global $wpdb;
        if ((int) $visitor->sessions === 0) {
            return 'new';
        }
        $types = $wpdb->get_col($wpdb->prepare(
            'SELECT DISTINCT type FROM ' . IWT_DB::t('conversions') . " WHERE visitor_id = %d AND status = 'approved'",
            (int) $visitor->id
        ));
        if (in_array('sale', $types, true)) {
            return 'customer';
        }
        return $types ? 'lead' : 'returning';
    }

    /** Insere um hit e incrementa o contador correspondente da sessão. */
    public static function log_hit(array $data): int
    {
        global $wpdb;
        $row = array_merge([
            'created_at' => IWT_Helpers::now(),
            'visitor_id' => 0,
            'session_id' => 0,
            'type' => 'click',
            'event' => '',
            'funnel_id' => 0,
            'link_id' => 0,
            'from_node_id' => 0,
            'to_node_id' => 0,
            'url' => '',
            'cost' => 0,
            'is_bot' => 0,
        ], $data);
        $row['url'] = IWT_Helpers::truncate((string) $row['url'], 255);
        $wpdb->insert(IWT_DB::t('hits'), $row);
        $id = (int) $wpdb->insert_id;

        // Passagem por condição/A-B/distribuição (event=route) não conta como clique da visita.
        if ((int) $row['session_id'] > 0 && $row['event'] !== 'route') {
            $col = $row['type'] === 'pageview' ? 'pageviews' : ($row['type'] === 'event' ? 'events' : 'clicks');
            $wpdb->query($wpdb->prepare(
                'UPDATE ' . IWT_DB::t('sessions') . " SET $col = $col + 1, last_activity_at = %s WHERE id = %d",
                $row['created_at'],
                (int) $row['session_id']
            ));
        }
        return $id;
    }

    public static function get_hit(int $id): ?object
    {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . IWT_DB::t('hits') . ' WHERE id = %d', $id));
        return $row ?: null;
    }

    /** Guarda dados de identificação vindos de conversões (para casar vendas futuras e para o CAPI). */
    public static function enrich(int $visitor_id, string $email_hash, string $phone_hash): void
    {
        global $wpdb;
        if ($visitor_id <= 0) {
            return;
        }
        $update = [];
        if ($email_hash !== '') {
            $update['email_hash'] = $email_hash;
        }
        if ($phone_hash !== '') {
            $update['phone_hash'] = $phone_hash;
        }
        if ($update) {
            $wpdb->update(IWT_DB::t('visitors'), $update, ['id' => $visitor_id]);
        }
    }

    public static function find_by_email_hash(string $hash): ?object
    {
        global $wpdb;
        if ($hash === '') {
            return null;
        }
        $row = $wpdb->get_row($wpdb->prepare(
            'SELECT * FROM ' . IWT_DB::t('visitors') . ' WHERE email_hash = %s ORDER BY last_seen_at DESC LIMIT 1',
            $hash
        ));
        return $row ?: null;
    }

    /** Para testes/requisições longas: limpa o cache do visitante atual. */
    public static function reset(): void
    {
        self::$current = null;
    }
}
