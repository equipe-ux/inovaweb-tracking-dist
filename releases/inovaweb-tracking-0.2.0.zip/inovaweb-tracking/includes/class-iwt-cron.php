<?php
/**
 * Tarefas agendadas (WP-Cron):
 *  - de hora em hora: reenvio da fila do Meta CAPI;
 *  - diária: retenção (apaga hits/visitas antigos em lotes, limpa IPs, logs e fila enviada).
 * Sem cron externo nem chave de licença na URL (o Smart Funnel dependia de um "pinger" deles).
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_Cron
{
    const BATCH = 5000;

    public static function init(): void
    {
        add_action('iwt_cron_hourly', [__CLASS__, 'hourly']);
        add_action('iwt_cron_daily', [__CLASS__, 'daily']);
        add_action('iwt_backfill_020', [__CLASS__, 'backfill_020']);
    }

    public static function schedule(): void
    {
        if (!wp_next_scheduled('iwt_cron_hourly')) {
            wp_schedule_event(time() + 300, 'hourly', 'iwt_cron_hourly');
        }
        if (!wp_next_scheduled('iwt_cron_daily')) {
            // 03:30 no horário do site.
            $next = strtotime('tomorrow 03:30', time() + IWT_Helpers::tz_offset()) - IWT_Helpers::tz_offset();
            wp_schedule_event($next, 'daily', 'iwt_cron_daily');
        }
    }

    public static function unschedule(): void
    {
        wp_clear_scheduled_hook('iwt_cron_hourly');
        wp_clear_scheduled_hook('iwt_cron_daily');
    }

    public static function hourly(): void
    {
        IWT_Meta_CAPI::process_queue(50);
    }

    public static function daily(): void
    {
        global $wpdb;
        $s = IWT_Settings::all();

        // Hits antigos
        $cut = gmdate('Y-m-d H:i:s', time() - (int) $s['retention_hits_days'] * DAY_IN_SECONDS);
        self::delete_in_batches(IWT_DB::t('hits'), 'created_at < %s', [$cut]);

        // Visitas antigas — exceto as que ainda são referência de atribuição de alguma conversão.
        $cut = gmdate('Y-m-d H:i:s', time() - (int) $s['retention_sessions_days'] * DAY_IN_SECONDS);
        $C = IWT_DB::t('conversions');
        self::delete_in_batches(
            IWT_DB::t('sessions'),
            "started_at < %s AND id NOT IN (SELECT first_session_id FROM $C) AND id NOT IN (SELECT last_session_id FROM $C) AND id NOT IN (SELECT paid_session_id FROM $C)",
            [$cut]
        );

        // IP do visitante (usado só no CAPI) é apagado depois do prazo.
        $ip_days = (int) $s['ip_retention_days'];
        $wpdb->query($wpdb->prepare(
            'UPDATE ' . IWT_DB::t('visitors') . " SET ip = '' WHERE ip <> '' AND last_seen_at < %s",
            gmdate('Y-m-d H:i:s', time() - max(0, $ip_days) * DAY_IN_SECONDS)
        ));

        // Logs de webhook (90 dias) e fila enviada (30 dias)
        self::delete_in_batches(IWT_DB::t('webhook_logs'), 'created_at < %s', [gmdate('Y-m-d H:i:s', time() - 90 * DAY_IN_SECONDS)]);
        self::delete_in_batches(IWT_DB::t('outbox'), "status = 'sent' AND created_at < %s", [gmdate('Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS)]);
    }

    /**
     * Visitas gravadas antes da 0.2.0: temperatura (pela mesma regra das novas) e estágio (primeira visita ou já visitou;
     * lead/cliente não dá para reconstruir). Em lotes; se sobrar, agenda a próxima rodada.
     */
    public static function backfill_020(): void
    {
        global $wpdb;
        $S = IWT_DB::t('sessions');
        $wpdb->query("UPDATE $S SET temperature = 'organic' WHERE temperature = '' AND is_paid = 0");
        $wpdb->query("UPDATE $S SET visitor_stage = 'new' WHERE visitor_stage = '' AND id IN (SELECT first_session_id FROM " . IWT_DB::t('visitors') . ')');
        $wpdb->query("UPDATE $S SET visitor_stage = 'returning' WHERE visitor_stage = ''");
        $rows = $wpdb->get_results("SELECT id, campaign, term, is_paid FROM $S WHERE temperature = '' LIMIT 3000");
        $groups = [];
        foreach ($rows as $r) {
            $t = IWT_Sources::temperature(['campaign' => (string) $r->campaign, 'term' => (string) $r->term, 'is_paid' => (int) $r->is_paid]);
            $groups[$t][] = (int) $r->id;
        }
        foreach ($groups as $t => $ids) {
            foreach (array_chunk($ids, 500) as $chunk) {
                $wpdb->query($wpdb->prepare("UPDATE $S SET temperature = %s WHERE id IN (" . implode(',', $chunk) . ')', $t)); // ids inteiros
            }
        }
        if (count($rows) === 3000) {
            wp_schedule_single_event(time() + 30, 'iwt_backfill_020');
        }
    }

    private static function delete_in_batches(string $table, string $where, array $params): void
    {
        global $wpdb;
        for ($i = 0; $i < 200; $i++) { // teto de segurança: 1 milhão de linhas por execução
            $deleted = $wpdb->query($wpdb->prepare("DELETE FROM $table WHERE $where LIMIT " . self::BATCH, $params)); // phpcs:ignore
            if (!$deleted || $deleted < self::BATCH) {
                break;
            }
        }
    }
}
