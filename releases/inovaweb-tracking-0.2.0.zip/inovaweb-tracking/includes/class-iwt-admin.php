<?php
/**
 * Telas do painel. Cada submenu renderiza só um contêiner; quem desenha é o assets/admin/admin.js
 * (JS puro, sem build), conversando com a API REST /admin/*.
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_Admin
{
    const PAGES = [
        'iwt' => 'Visão geral',
        'iwt-funnels' => 'Funis',
        'iwt-conversions' => 'Conversões',
        'iwt-reports' => 'Relatórios',
        'iwt-costs' => 'Custos',
        'iwt-integrations' => 'Integrações',
        'iwt-settings' => 'Configurações',
        'iwt-help' => 'Ajuda e diagnóstico',
    ];

    const MANAGE_PAGES = ['iwt-integrations', 'iwt-settings'];

    /** Tema do painel, por usuário: light | dark | auto (segue o sistema). */
    const THEME_META = 'iwt_theme';

    public static function theme(): string
    {
        $t = (string) get_user_meta(get_current_user_id(), self::THEME_META, true);
        return in_array($t, ['light', 'dark', 'auto'], true) ? $t : 'light';
    }

    public static function init(): void
    {
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue']);
        add_filter('plugin_action_links_' . plugin_basename(IWT_FILE), [__CLASS__, 'action_links']);
        add_filter('admin_body_class', [__CLASS__, 'body_class']);
    }

    public static function menu(): void
    {
        $icon = 'data:image/svg+xml;base64,' . base64_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="#a7aaad" d="M3 16h14v2H1V2h2v14Zm2-3 3.5-4 3 2.5L16 5l1.5 1.3-5.8 7.2-3-2.5L6.5 14.3 5 13Z"/></svg>');
        add_menu_page('INOVAWEB Tracking', 'Tracking', IWT_Plugin::CAP_VIEW, 'iwt', [__CLASS__, 'render'], $icon, 26);
        foreach (self::PAGES as $slug => $title) {
            $cap = in_array($slug, self::MANAGE_PAGES, true) ? IWT_Plugin::CAP_MANAGE : IWT_Plugin::CAP_VIEW;
            add_submenu_page('iwt', $title . ' — INOVAWEB Tracking', $title, $cap, $slug, [__CLASS__, 'render']);
        }
    }

    public static function current_page(): string
    {
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        return isset(self::PAGES[$page]) ? $page : '';
    }

    public static function render(): void
    {
        $page = self::current_page() ?: 'iwt';
        $view = $page === 'iwt' ? 'dashboard' : substr($page, 4);
        echo '<div class="wrap iwt-wrap"><div id="iwt-app" data-view="' . esc_attr($view) . '">';
        echo '<div class="iwt-boot">Carregando…</div>';
        echo '<noscript>O painel do INOVAWEB Tracking precisa de JavaScript.</noscript>';
        echo '</div></div>';
    }

    public static function enqueue(string $hook): void
    {
        if (self::current_page() === '') {
            return;
        }
        $v = IWT_VERSION;
        wp_enqueue_style('iwt-admin', IWT_URL . 'assets/admin/admin.css', [], $v);
        wp_enqueue_script('iwt-charts', IWT_URL . 'assets/admin/charts.js', [], $v, true);
        wp_enqueue_script('iwt-editor', IWT_URL . 'assets/admin/funnel-editor.js', [], $v, true);
        wp_enqueue_script('iwt-admin', IWT_URL . 'assets/admin/admin.js', ['iwt-charts', 'iwt-editor'], $v, true);
        wp_localize_script('iwt-admin', 'IWT_ADMIN', [
            'api' => esc_url_raw(rest_url(IWT_REST_NS)),
            'nonce' => wp_create_nonce('wp_rest'),
            'adminUrl' => admin_url('admin.php'),
            'version' => $v,
            'theme' => self::theme(),
        ]);
    }

    public static function action_links(array $links): array
    {
        array_unshift($links, '<a href="' . esc_url(admin_url('admin.php?page=iwt')) . '">Painel</a>');
        return $links;
    }

    public static function body_class(string $classes): string
    {
        if (self::current_page() === '') {
            return $classes;
        }
        // Escuro já no HTML (sem piscar claro); o "Automático" é resolvido pelo JS.
        return $classes . ' iwt-screen' . (self::theme() === 'dark' ? ' iwt-dark' : '');
    }
}
