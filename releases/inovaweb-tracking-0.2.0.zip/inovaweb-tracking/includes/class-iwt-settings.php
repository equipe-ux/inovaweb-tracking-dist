<?php
/**
 * Configurações do plugin, guardadas num único option (iwt_settings).
 * Segredos (tokens) nunca são devolvidos inteiros para o JS — veja for_admin().
 */

if (!defined('ABSPATH')) {
    exit;
}

class IWT_Settings
{
    const OPTION = 'iwt_settings';

    /** Campos secretos: o admin vê só se estão preenchidos; enviar vazio mantém o valor salvo. */
    const SECRETS = ['meta_token', 'hotmart_hottok', 'kiwify_token'];

    private static $cache = null;

    public static function defaults(): array
    {
        return [
            // Links e redirecionamento
            'route_prefix'        => 'go',
            'redirect_code'       => 302,
            'fallback_url'        => '',
            'pass_vid'            => true,   // acrescenta iwt_vid quando o destino é outro domínio
            // Script de rastreamento (páginas do site)
            'tracker_enabled'     => true,
            'track_logged_admins' => false,
            'track_whatsapp'      => true,   // cliques em wa.me / api.whatsapp.com
            'track_phone_email'   => true,   // cliques em tel: e mailto:
            'decorate_checkouts'  => true,   // marca links de checkout com o token do visitante
            'consent_mode'        => 'off',  // off | required
            'session_minutes'     => 30,
            'cookie_days'         => 365,
            'excluded_ips'        => '',
            'extra_checkout_domains' => '',
            // Retenção de dados
            'retention_hits_days'     => 400,
            'retention_sessions_days' => 760,
            'ip_retention_days'       => 30,
            'store_customer_pii'      => true,
            'delete_on_uninstall'     => false,
            // Conversões
            'currency'            => 'BRL',
            'unique_lead_per_visitor' => true,
            // Temperatura do tráfego: palavras procuradas na campanha e no público (utm_campaign / utm_term)
            'temp_cold_words'     => IWT_Sources::default_temperature_words()['cold'],
            'temp_warm_words'     => IWT_Sources::default_temperature_words()['warm'],
            'temp_hot_words'      => IWT_Sources::default_temperature_words()['hot'],
            'webhook_key'         => '',
            'hotmart_hottok'      => '',
            'kiwify_token'        => '',
            'generic_mapping'     => [],
            'woocommerce_enabled' => true,
            // Meta Conversions API
            'meta_enabled'        => false,
            'meta_pixel_id'       => '',
            'meta_token'          => '',
            'meta_test_code'      => '',
            'meta_api_version'    => 'v23.0',
            'meta_send_initiate_checkout' => true,
            // Acesso
            'view_roles'          => ['administrator'],
            'api_token_hash'      => '',
            'api_token_hint'      => '',
        ];
    }

    public static function all(): array
    {
        if (self::$cache === null) {
            $saved = get_option(self::OPTION, []);
            self::$cache = array_merge(self::defaults(), is_array($saved) ? $saved : []);
            if (self::$cache['webhook_key'] === '') {
                self::$cache['webhook_key'] = IWT_Helpers::random_key(32);
                update_option(self::OPTION, self::$cache, false);
            }
        }
        return self::$cache;
    }

    public static function get(string $key)
    {
        $all = self::all();
        return $all[$key] ?? null;
    }

    public static function set(string $key, $value): void
    {
        $all = self::all();
        $all[$key] = $value;
        self::save_raw($all);
    }

    public static function save_raw(array $all): void
    {
        update_option(self::OPTION, $all, false);
        self::$cache = null;
    }

    /** Valida e grava o que veio da tela de configurações. Devolve o array final. */
    public static function update_from_admin(array $input): array
    {
        $current = self::all();
        $d = self::defaults();
        $out = $current;

        $bools = ['pass_vid', 'tracker_enabled', 'track_logged_admins', 'track_whatsapp', 'track_phone_email', 'decorate_checkouts',
            'store_customer_pii', 'delete_on_uninstall', 'unique_lead_per_visitor', 'woocommerce_enabled', 'meta_enabled', 'meta_send_initiate_checkout'];
        foreach ($bools as $key) {
            if (array_key_exists($key, $input)) {
                $out[$key] = (bool) $input[$key];
            }
        }

        if (isset($input['route_prefix'])) {
            $prefix = strtolower(trim(sanitize_title((string) $input['route_prefix']), '/'));
            $reserved = ['wp-admin', 'wp-json', 'wp-content', 'wp-includes', 'feed', 'page', 'category', 'tag', 'author'];
            $out['route_prefix'] = ($prefix !== '' && !in_array($prefix, $reserved, true)) ? $prefix : $d['route_prefix'];
        }
        if (isset($input['redirect_code'])) {
            $code = (int) $input['redirect_code'];
            $out['redirect_code'] = in_array($code, [301, 302, 303, 307], true) ? $code : 302;
        }
        if (isset($input['fallback_url'])) {
            $out['fallback_url'] = esc_url_raw((string) $input['fallback_url']);
        }
        if (isset($input['consent_mode'])) {
            $out['consent_mode'] = $input['consent_mode'] === 'required' ? 'required' : 'off';
        }
        $ints = [
            'session_minutes' => [5, 240],
            'cookie_days' => [1, 730],
            'retention_hits_days' => [30, 3650],
            'retention_sessions_days' => [30, 3650],
            'ip_retention_days' => [0, 365],
        ];
        foreach ($ints as $key => [$min, $max]) {
            if (isset($input[$key])) {
                $out[$key] = max($min, min($max, (int) $input[$key]));
            }
        }
        foreach (['temp_cold_words', 'temp_warm_words', 'temp_hot_words'] as $key) {
            if (isset($input[$key])) {
                $words = array_filter(array_map('trim', explode(',', remove_accents(strtolower(sanitize_text_field((string) $input[$key]))))));
                $out[$key] = $words ? implode(', ', array_unique($words)) : $d[$key];
            }
        }
        foreach (['excluded_ips', 'extra_checkout_domains'] as $key) {
            if (isset($input[$key])) {
                $out[$key] = sanitize_textarea_field((string) $input[$key]);
            }
        }
        if (isset($input['currency'])) {
            $cur = strtoupper(preg_replace('/[^A-Za-z]/', '', (string) $input['currency']));
            $out['currency'] = strlen($cur) === 3 ? $cur : 'BRL';
        }
        if (isset($input['meta_pixel_id'])) {
            $out['meta_pixel_id'] = preg_replace('/\D/', '', (string) $input['meta_pixel_id']);
        }
        if (isset($input['meta_test_code'])) {
            $out['meta_test_code'] = sanitize_text_field((string) $input['meta_test_code']);
        }
        if (isset($input['meta_api_version'])) {
            $v = (string) $input['meta_api_version'];
            $out['meta_api_version'] = preg_match('/^v\d{2}\.\d$/', $v) ? $v : $d['meta_api_version'];
        }
        foreach (self::SECRETS as $key) {
            if (isset($input[$key]) && is_string($input[$key]) && $input[$key] !== '') {
                $out[$key] = $input[$key] === '__clear__' ? '' : sanitize_text_field($input[$key]);
            }
        }
        if (isset($input['view_roles']) && is_array($input['view_roles'])) {
            $roles = array_values(array_filter(array_map('sanitize_key', $input['view_roles'])));
            if (!in_array('administrator', $roles, true)) {
                $roles[] = 'administrator';
            }
            $out['view_roles'] = $roles;
        }
        if (isset($input['generic_mapping']) && is_array($input['generic_mapping'])) {
            $map = [];
            foreach (IWT_Platforms::generic_fields() as $field => $label) {
                $map[$field] = sanitize_text_field((string) ($input['generic_mapping'][$field] ?? ''));
            }
            $out['generic_mapping'] = $map;
        }

        self::save_raw($out);
        IWT_Plugin::sync_capabilities();
        return self::all();
    }

    /** Versão segura para o painel: segredos viram booleano "configurado". */
    public static function for_admin(): array
    {
        $all = self::all();
        foreach (self::SECRETS as $key) {
            $all[$key . '_set'] = $all[$key] !== '';
            $all[$key] = '';
        }
        unset($all['api_token_hash']);
        return $all;
    }

    public static function excluded_ips(): array
    {
        $lines = preg_split('/[\s,]+/', (string) self::get('excluded_ips'));
        return array_values(array_filter(array_map('trim', $lines)));
    }

    public static function route_prefix(): string
    {
        return (string) self::get('route_prefix') ?: 'go';
    }
}
