/*!
 * INOVAWEB Tracking — painel administrativo (JS puro, sem build).
 * Cada submenu do WordPress renderiza <div id="iwt-app" data-view="..."> e este arquivo desenha a tela
 * consultando a API /wp-json/inovaweb-tracking/v1/admin/*. Padrão: render*() monta o HTML e bind*() liga eventos.
 * Toda saída de dado passa por esc().
 */
(function () {
  'use strict';

  var CFG = window.IWT_ADMIN;
  var app = document.getElementById('iwt-app');
  if (!app || !CFG) { return; }

  var BOOT = null;
  var VIEW = app.getAttribute('data-view') || 'dashboard';

  /* =================================================================== utilidades */

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function qs(params) {
    var out = [];
    Object.keys(params || {}).forEach(function (k) {
      var v = params[k];
      if (v === undefined || v === null || v === '') { return; }
      out.push(encodeURIComponent(k) + '=' + encodeURIComponent(v));
    });
    return out.length ? '?' + out.join('&') : '';
  }

  function api(path, opts) {
    opts = opts || {};
    var url = CFG.api + path + qs(opts.params);
    var init = { method: opts.method || 'GET', headers: { 'X-WP-Nonce': CFG.nonce }, credentials: 'same-origin' };
    if (opts.body !== undefined) {
      init.headers['Content-Type'] = 'application/json';
      init.body = JSON.stringify(opts.body);
    }
    return fetch(url, init).then(function (r) {
      return r.text().then(function (t) {
        var data = null;
        try { data = t ? JSON.parse(t) : null; } catch (e) { data = null; }
        if (!r.ok) {
          var msg = (data && (data.error || data.message)) || ('Erro ' + r.status);
          throw new Error(msg);
        }
        return data;
      });
    });
  }

  var NF = {};
  function nf(opts) {
    var key = JSON.stringify(opts);
    if (!NF[key]) { NF[key] = new Intl.NumberFormat('pt-BR', opts); }
    return NF[key];
  }
  function fmtInt(n) { return n == null ? '—' : nf({ maximumFractionDigits: 0 }).format(n); }
  function fmtNum(n, d) { return n == null ? '—' : nf({ minimumFractionDigits: d || 0, maximumFractionDigits: d || 0 }).format(n); }
  function currency() { return (BOOT && BOOT.currency) || 'BRL'; }
  function fmtMoney(n, cur) {
    if (n == null) { return '—'; }
    try { return nf({ style: 'currency', currency: cur || currency() }).format(n); } catch (e) { return fmtNum(n, 2); }
  }
  function fmtMoneyShort(n) {
    if (n == null) { return '—'; }
    if (Math.abs(n) >= 100000) { return nf({ style: 'currency', currency: currency(), notation: 'compact', maximumFractionDigits: 1 }).format(n); }
    return fmtMoney(n);
  }
  function fmtCompact(n) { return n == null ? '—' : (Math.abs(n) >= 10000 ? nf({ notation: 'compact', maximumFractionDigits: 1 }).format(n) : fmtInt(n)); }
  function plural(n, one, many) { return fmtInt(n) + ' ' + (n === 1 ? one : many); }
  function fmtPct(n, d) { return n == null ? '—' : fmtNum(n, d == null ? 1 : d) + '%'; }
  function fmtRoas(n) { return n == null ? '—' : fmtNum(n, 2) + 'x'; }
  function fmtDate(iso) {
    if (!iso) { return '—'; }
    var d = new Date(iso);
    return isNaN(d) ? iso : d.toLocaleDateString('pt-BR');
  }
  function fmtDateTime(iso) {
    if (!iso) { return '—'; }
    var d = new Date(iso);
    return isNaN(d) ? iso : d.toLocaleDateString('pt-BR') + ' ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  }
  function ymdLabel(ymd) {
    var p = String(ymd).split('-');
    return p.length === 3 ? p[2] + '/' + p[1] + '/' + p[0] : ymd;
  }

  var ICON = {
    up: '<path d="M12 19V5M5 12l7-7 7 7"/>',
    down: '<path d="M12 5v14M19 12l-7 7-7-7"/>',
    flat: '<path d="M5 12h14"/>',
    copy: '<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    alert: '<path d="M12 3l10 18H2z"/><path d="M12 10v4M12 17v.5"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>',
    back: '<path d="M15 5l-7 7 7 7"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"/>',
    download: '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
    external: '<path d="M14 4h6v6M20 4l-9 9M18 14v6H4V6h6"/>',
    filter: '<path d="M4 5h16l-6 8v6l-4-2v-4z"/>',
    moon: '<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>'
  };
  function icon(name, cls) {
    return '<svg class="iwt-ico ' + (cls || '') + '" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + (ICON[name] || '') + '</svg>';
  }

  /* ---- modo noturno (preferência de cada usuário: light | dark | auto) ---- */
  var THEME = (CFG && CFG.theme) || 'light';
  var darkQuery = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
  function isDark() { return THEME === 'dark' || (THEME === 'auto' && !!darkQuery && darkQuery.matches); }
  function themeLabel() { return isDark() ? 'Usar modo claro' : 'Usar modo noturno'; }
  function themeButton() {
    return '<button type="button" class="iwt-icon-btn iwt-theme-btn" data-theme-toggle aria-label="' + themeLabel() + '" title="' + themeLabel() + '">' + icon(isDark() ? 'sun' : 'moon') + '</button>';
  }
  function applyTheme() {
    document.body.classList.toggle('iwt-dark', isDark());
    document.querySelectorAll('[data-theme-toggle]').forEach(function (b) {
      b.innerHTML = icon(isDark() ? 'sun' : 'moon');
      b.setAttribute('aria-label', themeLabel());
      b.title = themeLabel();
    });
    var sel = document.getElementById('st-theme');
    if (sel) { sel.value = THEME; }
  }
  function setTheme(t) {
    THEME = t;
    applyTheme();
    return api('/admin/preferences', { method: 'POST', body: { theme: t } }).catch(function (err) { toast(err.message, 'error'); });
  }
  if (darkQuery) {
    var onScheme = function () { if (THEME === 'auto') { applyTheme(); } };
    if (darkQuery.addEventListener) { darkQuery.addEventListener('change', onScheme); } else if (darkQuery.addListener) { darkQuery.addListener(onScheme); }
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-theme-toggle]');
    if (b) { setTheme(isDark() ? 'light' : 'dark'); }
  });
  applyTheme();

  function toast(msg, type) {
    var host = document.querySelector('.iwt-toasts');
    if (!host) {
      host = document.createElement('div');
      host.className = 'iwt-toasts';
      host.setAttribute('role', 'status');
      host.setAttribute('aria-live', 'polite');
      document.body.appendChild(host);
    }
    var t = document.createElement('div');
    t.className = 'iwt-toast iwt-toast--' + (type || 'info');
    t.innerHTML = icon(type === 'error' ? 'alert' : (type === 'success' ? 'check' : 'info')) + '<span>' + esc(msg) + '</span>';
    host.appendChild(t);
    setTimeout(function () { t.classList.add('is-out'); }, 4200);
    setTimeout(function () { t.remove(); }, 4700);
  }

  function copy(text, label) {
    var done = function () { toast((label || 'Copiado') + '!', 'success'); };
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(done, function () { fallbackCopy(text); done(); });
    } else {
      fallbackCopy(text);
      done();
    }
  }
  function fallbackCopy(text) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); } catch (e) { /* ignore */ }
    ta.remove();
  }

  /** Modal acessível simples. actions: [{label, primary, danger, onClick(close)}] */
  function modal(o) {
    var wrap = document.createElement('div');
    wrap.className = 'iwt-modal-backdrop';
    wrap.innerHTML = '<div class="iwt-modal' + (o.wide ? ' iwt-modal--wide' : '') + '" role="dialog" aria-modal="true" aria-label="' + esc(o.title) + '">' +
      '<div class="iwt-modal-head"><h2>' + esc(o.title) + '</h2><button type="button" class="iwt-icon-btn" data-close aria-label="Fechar">' + icon('x') + '</button></div>' +
      '<div class="iwt-modal-body">' + (o.body || '') + '</div>' +
      (o.actions && o.actions.length ? '<div class="iwt-modal-foot"></div>' : '') + '</div>';
    document.body.appendChild(wrap);
    var prevFocus = document.activeElement;
    function close() {
      wrap.remove();
      document.removeEventListener('keydown', onKey);
      if (prevFocus && prevFocus.focus) { prevFocus.focus(); }
    }
    function onKey(e) { if (e.key === 'Escape') { close(); } }
    document.addEventListener('keydown', onKey);
    wrap.addEventListener('click', function (e) {
      if (e.target === wrap || e.target.closest('[data-close]')) { close(); }
    });
    var foot = wrap.querySelector('.iwt-modal-foot');
    (o.actions || []).forEach(function (a) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'iwt-btn' + (a.primary ? ' iwt-btn--primary' : '') + (a.danger ? ' iwt-btn--danger' : '');
      b.textContent = a.label;
      b.addEventListener('click', function () { a.onClick ? a.onClick(close, wrap, b) : close(); });
      foot.appendChild(b);
    });
    var first = wrap.querySelector('input, select, textarea, button:not([data-close])');
    if (first) { first.focus(); }
    return { close: close, el: wrap };
  }

  function confirmDialog(title, text, okLabel, danger) {
    return new Promise(function (resolve) {
      modal({
        title: title,
        body: '<p>' + esc(text) + '</p>',
        actions: [
          { label: 'Cancelar', onClick: function (close) { close(); resolve(false); } },
          { label: okLabel || 'Confirmar', primary: !danger, danger: !!danger, onClick: function (close) { close(); resolve(true); } }
        ]
      });
    });
  }

  function lsGet(k, d) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }
  function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* ignore */ } }

  function csvDownload(filename, header, rows) {
    var sep = ';';
    var line = function (cols) {
      return cols.map(function (c) {
        var s = c == null ? '' : String(c);
        return /[";\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
      }).join(sep);
    };
    var csv = '﻿' + [line(header)].concat(rows.map(line)).join('\r\n');
    var blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  }

  function badge(text, tone) {
    return '<span class="iwt-badge iwt-badge--' + (tone || 'neutral') + '">' + esc(text) + '</span>';
  }

  var PAYMENT_LABELS = { credit_card: 'Cartão de crédito', creditcard: 'Cartão de crédito', card: 'Cartão', debit_card: 'Cartão de débito', pix: 'Pix',
    billet: 'Boleto', boleto: 'Boleto', bank_slip: 'Boleto', paypal: 'PayPal', google_pay: 'Google Pay', apple_pay: 'Apple Pay', wallet: 'Carteira digital' };
  function paymentLabel(v) { return v ? (PAYMENT_LABELS[String(v).toLowerCase()] || v) : ''; }

  var TEMP_TONE = { cold: 'accent', warm: 'warn', hot: 'bad', organic: 'green', unknown: 'neutral' };
  var STATUS_TONE = { approved: 'good', pending: 'warn', refunded: 'bad', chargeback: 'bad', canceled: 'neutral' };
  var GOAL_TONE = { checkout: 'accent', thankyou: 'teal', whatsapp: 'green' };

  function pageUrl(page, extra) {
    return CFG.adminUrl + '?page=' + page + (extra || '');
  }

  function loading(target) {
    (target || app).innerHTML = '<div class="iwt-loading"><span class="iwt-spinner"></span> Carregando…</div>';
  }

  function errorBox(err) {
    return '<div class="iwt-notice iwt-notice--error">' + icon('alert') + '<div><strong>Não foi possível carregar.</strong> ' + esc(err && err.message ? err.message : err) + '</div></div>';
  }

  /* =================================================================== período */

  function addDays(ymd, n) {
    var d = new Date(ymd + 'T12:00:00Z');
    d.setUTCDate(d.getUTCDate() + n);
    return d.toISOString().slice(0, 10);
  }
  function presets() {
    var t = BOOT.today;
    var first = t.slice(0, 8) + '01';
    var lastMonthEnd = addDays(first, -1);
    var lastMonthStart = lastMonthEnd.slice(0, 8) + '01';
    return {
      today: { label: 'Hoje', from: t, to: t },
      yesterday: { label: 'Ontem', from: addDays(t, -1), to: addDays(t, -1) },
      '7d': { label: 'Últimos 7 dias', from: addDays(t, -6), to: t },
      '30d': { label: 'Últimos 30 dias', from: addDays(t, -29), to: t },
      month: { label: 'Este mês', from: first, to: t },
      lastmonth: { label: 'Mês passado', from: lastMonthStart, to: lastMonthEnd },
      '90d': { label: 'Últimos 90 dias', from: addDays(t, -89), to: t },
      custom: { label: 'Personalizado…' }
    };
  }
  var RANGE = null;
  function initRange() {
    var saved = lsGet('iwt_range', null);
    var p = presets();
    if (saved && saved.preset && p[saved.preset] && saved.preset !== 'custom') {
      RANGE = { preset: saved.preset, from: p[saved.preset].from, to: p[saved.preset].to };
    } else if (saved && saved.preset === 'custom' && saved.from && saved.to) {
      RANGE = saved;
    } else {
      RANGE = { preset: '30d', from: p['30d'].from, to: p['30d'].to };
    }
  }
  function rangeParams() { return { from: RANGE.from, to: RANGE.to }; }

  function periodPicker() {
    var p = presets();
    var opts = Object.keys(p).map(function (k) {
      return '<option value="' + k + '"' + (RANGE.preset === k ? ' selected' : '') + '>' + esc(p[k].label) + '</option>';
    }).join('');
    return '<div class="iwt-period">' +
      '<label class="screen-reader-text" for="iwt-period">Período</label>' +
      '<select id="iwt-period" class="iwt-select">' + opts + '</select>' +
      '<span class="iwt-period-custom"' + (RANGE.preset === 'custom' ? '' : ' hidden') + '>' +
      '<input type="date" class="iwt-input" data-range="from" value="' + esc(RANGE.from) + '" aria-label="Data inicial"> até ' +
      '<input type="date" class="iwt-input" data-range="to" value="' + esc(RANGE.to) + '" aria-label="Data final">' +
      '</span>' +
      '<span class="iwt-period-label">' + esc(ymdLabel(RANGE.from)) + ' – ' + esc(ymdLabel(RANGE.to)) + '</span>' +
      '</div>';
  }
  function bindPeriod(root, onChange) {
    var sel = root.querySelector('#iwt-period');
    if (!sel) { return; }
    var custom = root.querySelector('.iwt-period-custom');
    sel.addEventListener('change', function () {
      var p = presets();
      if (sel.value === 'custom') {
        custom.hidden = false;
        RANGE.preset = 'custom';
        lsSet('iwt_range', RANGE);
        return;
      }
      custom.hidden = true;
      RANGE = { preset: sel.value, from: p[sel.value].from, to: p[sel.value].to };
      lsSet('iwt_range', RANGE);
      onChange();
    });
    root.querySelectorAll('[data-range]').forEach(function (inp) {
      inp.addEventListener('change', function () {
        var from = root.querySelector('[data-range="from"]').value;
        var to = root.querySelector('[data-range="to"]').value;
        if (!from || !to) { return; }
        RANGE = { preset: 'custom', from: from <= to ? from : to, to: from <= to ? to : from };
        lsSet('iwt_range', RANGE);
        onChange();
      });
    });
  }

  function funnelSelect(id, value, emptyLabel) {
    var opts = '<option value="">' + esc(emptyLabel || 'Todos os funis') + '</option>' + (BOOT.funnels || []).map(function (f) {
      return '<option value="' + f.id + '"' + (String(value) === String(f.id) ? ' selected' : '') + '>' + esc(f.name) + (f.status === 'archived' ? ' (arquivado)' : '') + '</option>';
    }).join('');
    return '<select id="' + id + '" class="iwt-select">' + opts + '</select>';
  }

  function header(title, sub, right) {
    return '<header class="iwt-header"><div><h1 class="iwt-title">' + esc(title) + '</h1>' + (sub ? '<p class="iwt-sub">' + sub + '</p>' : '') + '</div>' +
      '<div class="iwt-header-right">' + (right || '') + themeButton() + '</div></header>';
  }

  function deltaChip(cur, prev, mode) {
    // mode: 'up' (subir é bom), 'down' (cair é bom), 'neutral'
    if (cur == null || prev == null) { return '<span class="iwt-delta iwt-delta--none">sem comparação</span>'; }
    if (prev === 0) {
      return cur === 0 ? '<span class="iwt-delta iwt-delta--flat">' + icon('flat') + 'igual ao período anterior</span>'
        : '<span class="iwt-delta iwt-delta--none">novo no período</span>';
    }
    var pct = ((cur - prev) / Math.abs(prev)) * 100;
    if (Math.abs(pct) < 0.5) { return '<span class="iwt-delta iwt-delta--flat">' + icon('flat') + 'estável vs anterior</span>'; }
    var upDir = pct > 0;
    var tone = mode === 'neutral' ? 'neutral' : ((upDir === (mode !== 'down')) ? 'good' : 'bad');
    return '<span class="iwt-delta iwt-delta--' + tone + '">' + icon(upDir ? 'up' : 'down') +
      (upDir ? '+' : '−') + fmtNum(Math.abs(pct), Math.abs(pct) < 10 ? 1 : 0) + '% vs anterior</span>';
  }

  function emptyState(title, text, action) {
    return '<div class="iwt-empty"><h3>' + esc(title) + '</h3><p>' + text + '</p>' + (action || '') + '</div>';
  }

  function barCell(value, max, label) {
    var pct = max > 0 && value > 0 ? Math.max(1.5, (value / max) * 100) : 0;
    // A barra mede a fração de uma trilha de largura fixa: 1 tem exatamente metade do tamanho de 2.
    return '<div class="iwt-barcell"><span class="iwt-barcell-track"><span class="iwt-barcell-bar" style="width:' + pct.toFixed(1) + '%"></span></span><span class="iwt-barcell-val">' + label + '</span></div>';
  }

  /* =================================================================== VISÃO GERAL */

  var DASH = { metric: 'visits', filters: lsGet('iwt_dash_filters', {}) };

  var FILTER_LABELS = { channel: 'Canal', temperature: 'Temperatura', visitor_stage: 'Estágio', source: 'Fonte', medium: 'Mídia', campaign: 'Campanha', content: 'Conteúdo', device: 'Dispositivo', country: 'País', funnel: 'Funil', source_node: 'Fonte do funil' };

  function filterChips(filters, labels) {
    var keys = Object.keys(filters);
    if (!keys.length) { return ''; }
    return '<div class="iwt-chips">' + icon('filter') + keys.map(function (k) {
      var label = (labels && labels[k] && labels[k][filters[k]]) || filters[k];
      if (k === 'funnel') {
        var f = (BOOT.funnels || []).filter(function (x) { return String(x.id) === String(filters[k]); })[0];
        label = f ? f.name : label;
      }
      return '<button type="button" class="iwt-chip" data-unfilter="' + esc(k) + '">' + esc(FILTER_LABELS[k] || k) + ': <strong>' + esc(label) + '</strong> ' + icon('x') + '</button>';
    }).join('') + '<button type="button" class="iwt-link-btn" data-unfilter="*">Limpar filtros</button></div>';
  }

  function chipLabels() {
    return { channel: BOOT.channels, temperature: BOOT.temperatures, visitor_stage: BOOT.visitor_stages };
  }

  function renderDashboard() {
    app.innerHTML =
      header('Visão geral', 'Visitas, origens e conversões do site e dos funis.', periodPicker() + funnelSelect('iwt-dash-funnel', DASH.filters.funnel)) +
      '<div id="iwt-dash-onboarding"></div>' +
      '<div id="iwt-dash-chips">' + filterChips(DASH.filters, chipLabels()) + '</div>' +
      '<section class="iwt-kpis" id="iwt-kpis" aria-label="Indicadores principais"></section>' +
      '<section class="iwt-card iwt-card--chart"><div class="iwt-card-head"><h2 id="iwt-chart-title">Visitas por dia</h2><span class="iwt-card-hint">Clique em um indicador acima para trocar o gráfico.</span></div><div class="iwt-chart" id="iwt-chart"></div></section>' +
      '<section class="iwt-mini" id="iwt-mini" aria-label="Outros indicadores"></section>' +
      '<div class="iwt-grid-2">' +
      '<section class="iwt-card" data-dim="channel"><div class="iwt-card-head"><h2>Canais</h2></div><div class="iwt-card-body"></div></section>' +
      '<section class="iwt-card" data-dim="temperature"><div class="iwt-card-head"><h2>Temperatura do tráfego</h2><span class="iwt-card-hint">Frio, morno, quente e orgânico</span></div><div class="iwt-card-body"></div></section>' +
      '<section class="iwt-card" data-dim="campaign"><div class="iwt-card-head"><h2>Campanhas</h2></div><div class="iwt-card-body"></div></section>' +
      '<section class="iwt-card" data-dim="source"><div class="iwt-card-head"><h2>Fontes</h2></div><div class="iwt-card-body"></div></section>' +
      '<section class="iwt-card" data-dim="landing"><div class="iwt-card-head"><h2>Páginas de entrada</h2></div><div class="iwt-card-body"></div></section>' +
      '<section class="iwt-card" data-dim="device"><div class="iwt-card-head"><h2>Dispositivos</h2></div><div class="iwt-card-body"></div></section>' +
      '<section class="iwt-card" data-dim="visitor_stage"><div class="iwt-card-head"><h2>Estágio do visitante</h2><span class="iwt-card-hint">Quem já conhecia o site</span></div><div class="iwt-card-body"></div></section>' +
      '<section class="iwt-card" id="iwt-latest"><div class="iwt-card-head"><h2>Últimas conversões</h2><a class="iwt-link-btn" href="' + esc(pageUrl('iwt-conversions')) + '">Ver todas</a></div><div class="iwt-card-body"></div></section>' +
      '</div>';

    bindPeriod(app, loadDashboard);
    app.querySelector('#iwt-dash-funnel').addEventListener('change', function (e) {
      if (e.target.value) { DASH.filters.funnel = e.target.value; } else { delete DASH.filters.funnel; }
      lsSet('iwt_dash_filters', DASH.filters);
      renderDashboard();
    });
    if (!app.iwtDashBound) { app.addEventListener('click', onDashClick); app.iwtDashBound = true; }
    loadDashboard();
  }

  function onDashClick(e) {
    var un = e.target.closest('[data-unfilter]');
    if (un) {
      var k = un.getAttribute('data-unfilter');
      if (k === '*') { DASH.filters = {}; } else { delete DASH.filters[k]; }
      lsSet('iwt_dash_filters', DASH.filters);
      renderDashboard();
      return;
    }
    var f = e.target.closest('[data-filter]');
    if (f) {
      DASH.filters[f.getAttribute('data-filter')] = f.getAttribute('data-value');
      lsSet('iwt_dash_filters', DASH.filters);
      renderDashboard();
      return;
    }
    var tile = e.target.closest('[data-metric]');
    if (tile) {
      DASH.metric = tile.getAttribute('data-metric');
      app.querySelectorAll('[data-metric]').forEach(function (t) { t.classList.toggle('is-active', t === tile); t.setAttribute('aria-pressed', t === tile ? 'true' : 'false'); });
      drawDashChart();
    }
  }

  var DASH_DATA = null;
  var METRICS = {
    visits: { label: 'Visitas', fmt: fmtInt, mode: 'up' },
    visitors: { label: 'Visitantes únicos', fmt: fmtInt, mode: 'up' },
    conversions: { label: 'Conversões', fmt: fmtInt, mode: 'up' },
    conv_rate: { label: 'Taxa de conversão', fmt: function (v) { return fmtPct(v, 2); }, mode: 'up', noChart: true },
    revenue: { label: 'Receita', fmt: fmtMoneyShort, mode: 'up' },
    cost: { label: 'Investimento', fmt: fmtMoneyShort, mode: 'neutral' },
    roas: { label: 'ROAS', fmt: fmtRoas, mode: 'up', noChart: true },
    cpa: { label: 'Custo por conversão', fmt: fmtMoney, mode: 'down', noChart: true }
  };

  function loadDashboard() {
    var params = Object.assign(rangeParams(), DASH.filters);
    var kpis = app.querySelector('#iwt-kpis');
    kpis.innerHTML = '<div class="iwt-loading"><span class="iwt-spinner"></span> Calculando…</div>';
    Promise.all([
      api('/admin/overview', { params: params }),
      api('/admin/timeseries', { params: params }),
      api('/admin/conversions', { params: Object.assign({ per_page: 6 }, params) })
    ]).then(function (res) {
      DASH_DATA = { overview: res[0], series: res[1].series };
      renderKpis(res[0]);
      drawDashChart();
      renderLatest(res[2].items);
      renderOnboarding(res[0]);
    }).catch(function (err) { kpis.innerHTML = errorBox(err); });

    app.querySelectorAll('[data-dim]').forEach(function (card) {
      var dim = card.getAttribute('data-dim');
      var body = card.querySelector('.iwt-card-body');
      body.innerHTML = '<div class="iwt-loading"><span class="iwt-spinner"></span></div>';
      api('/admin/breakdown', { params: Object.assign({ dimension: dim, limit: 8 }, params) }).then(function (r) {
        body.innerHTML = breakdownMini(dim, r.rows);
      }).catch(function (err) { body.innerHTML = errorBox(err); });
    });
  }

  function renderKpis(o) {
    var c = o.current;
    var p = o.previous;
    var html = Object.keys(METRICS).map(function (k) {
      var m = METRICS[k];
      var clickable = !m.noChart;
      var tag = clickable ? 'button type="button"' : 'div';
      var end = clickable ? 'button' : 'div';
      return '<' + tag + ' class="iwt-kpi' + (DASH.metric === k ? ' is-active' : '') + (clickable ? ' is-clickable' : '') + '"' + (clickable ? ' data-metric="' + k + '" aria-pressed="' + (DASH.metric === k) + '"' : '') + '>' +
        '<span class="iwt-kpi-label">' + esc(m.label) + '</span>' +
        '<span class="iwt-kpi-value">' + m.fmt(c[k]) + '</span>' +
        deltaChip(c[k], p[k], m.mode) +
        '</' + end + '>';
    }).join('');
    app.querySelector('#iwt-kpis').innerHTML = html;

    var mini = [
      ['Páginas vistas', fmtInt(c.pageviews)],
      ['Cliques nos links dos funis', fmtInt(c.clicks)],
      ['Cliques no WhatsApp', fmtInt(c.whatsapp_clicks)],
      ['Cliques em telefone / e-mail', fmtInt(c.phone_clicks + c.email_clicks)],
      ['Chegaram ao checkout', fmtInt(c.checkout_visitors) + (c.checkout_rate != null ? ' <small>' + fmtPct(c.checkout_rate, 1) + ' dos visitantes</small>' : '')],
      ['Vendas aprovadas', fmtInt(c.sales) + (c.ticket != null ? ' <small>ticket ' + fmtMoney(c.ticket) + '</small>' : '')],
      ['Pendentes (boleto/pix)', fmtInt(c.pending) + ' <small>' + fmtMoney(c.pending_value) + '</small>'],
      ['Reembolsos e chargebacks', fmtInt(c.refunds) + ' <small>' + fmtMoney(c.refunds_value) + '</small>']
    ];
    app.querySelector('#iwt-mini').innerHTML = mini.map(function (x) {
      return '<div class="iwt-mini-item"><span>' + esc(x[0]) + '</span><strong>' + x[1] + '</strong></div>';
    }).join('');
  }

  function drawDashChart() {
    if (!DASH_DATA) { return; }
    var m = METRICS[DASH.metric] || METRICS.visits;
    app.querySelector('#iwt-chart-title').textContent = m.label + ' por dia';
    var data = DASH_DATA.series.map(function (d) { return { date: d.date, value: d[DASH.metric] || 0 }; });
    var isMoney = DASH.metric === 'revenue' || DASH.metric === 'cost';
    window.IWTCharts.line(app.querySelector('#iwt-chart'), {
      data: data,
      label: m.label.toLowerCase(),
      format: function (v, axis) { return isMoney ? (axis ? fmtMoneyShort(v) : fmtMoney(v)) : (axis ? fmtCompact(v) : fmtInt(v)); },
      dateLabel: function (d) { return ymdLabel(d); }
    });
  }

  var DIM_FILTER = { channel: 'channel', temperature: 'temperature', visitor_stage: 'visitor_stage', campaign: 'campaign', source: 'source', device: 'device', source_node: 'source_node', funnel: 'funnel' };

  function breakdownMini(dim, rows) {
    if (!rows.length) { return '<p class="iwt-muted iwt-pad">Sem dados no período.</p>'; }
    var max = 0;
    rows.forEach(function (r) { if (r.visits > max) { max = r.visits; } });
    var filterKey = DIM_FILTER[dim];
    return '<table class="iwt-table iwt-table--compact"><thead><tr><th scope="col">' + esc(BOOT.dimensions[dim] || dim) + '</th><th scope="col" class="iwt-w-bar">Visitas</th><th scope="col" class="num">Conv.</th><th scope="col" class="num">Receita</th></tr></thead><tbody>' +
      rows.map(function (r) {
        var label = esc(r.label);
        var cell = filterKey && r.key !== null && r.key !== '' ? '<button type="button" class="iwt-link-btn" data-filter="' + filterKey + '" data-value="' + esc(r.key) + '" title="Filtrar por este item">' + label + '</button>' : label;
        return '<tr><td class="iwt-ellipsis">' + cell + '</td><td>' + barCell(r.visits, max, fmtInt(r.visits)) + '</td><td class="num">' + fmtInt(r.conversions) + '</td><td class="num">' + (r.revenue ? fmtMoney(r.revenue) : '—') + '</td></tr>';
      }).join('') + '</tbody></table>';
  }

  function renderLatest(items) {
    var body = app.querySelector('#iwt-latest .iwt-card-body');
    if (!items.length) { body.innerHTML = '<p class="iwt-muted iwt-pad">Nenhuma conversão no período.</p>'; return; }
    body.innerHTML = '<ul class="iwt-feed">' + items.map(function (c) {
      return '<li><span class="iwt-feed-main"><strong>' + esc(BOOT.types[c.type] || c.type) + '</strong> ' + (c.value ? fmtMoney(c.value, c.currency) : '') +
        ' ' + badge(BOOT.statuses[c.status] || c.status, STATUS_TONE[c.status]) + '</span>' +
        '<span class="iwt-feed-sub">' + esc([c.funnel_name, c.channel_label, c.source, c.campaign].filter(Boolean).join(' · ') || 'sem atribuição') + ' — ' + fmtDateTime(c.converted_at) + '</span></li>';
    }).join('') + '</ul>';
  }

  function renderOnboarding(o) {
    var box = app.querySelector('#iwt-dash-onboarding');
    var c = o.current;
    if (c.visits > 0 || c.conversions > 0 || (BOOT.funnels || []).length) { box.innerHTML = ''; return; }
    box.innerHTML = '<section class="iwt-card iwt-onboarding"><div class="iwt-card-head"><h2>Primeiros passos</h2></div><ol class="iwt-steps">' +
      '<li class="' + (BOOT.tracker_enabled ? 'is-done' : '') + '"><strong>Script de rastreamento</strong> ' + (BOOT.tracker_enabled ? 'ativo em todas as páginas do site. As visitas aparecem aqui em poucos minutos (visitas de administradores logados não contam).' : 'desligado — ative em <a href="' + esc(pageUrl('iwt-settings')) + '">Configurações</a>.') + '</li>' +
      '<li><strong>Crie um funil</strong> com as fontes de tráfego, páginas e o checkout, e use os links gerados nos anúncios. <a href="' + esc(pageUrl('iwt-funnels')) + '">Criar funil</a></li>' +
      '<li><strong>Conecte o checkout</strong> (Hotmart, Kiwify, Eduzz…) para as vendas voltarem atribuídas. <a href="' + esc(pageUrl('iwt-integrations')) + '">Integrações</a></li>' +
      '</ol></section>';
  }

  /* =================================================================== FUNIS (lista) */

  var FUNNELS_SHOW_ARCHIVED = false;

  function renderFunnels() {
    var m = /[?&]funnel=(\d+)/.exec(window.location.search);
    if (m) { return renderEditor(parseInt(m[1], 10)); }
    var manage = BOOT.can_manage;
    app.innerHTML = header('Funis', 'Cada conexão do funil gera um link rastreável. Use os links nos anúncios e nos botões das páginas.',
      periodPicker() + (manage ? '<button type="button" class="iwt-btn iwt-btn--primary" id="iwt-new-funnel">' + icon('plus') + 'Novo funil</button>' : '')) +
      '<section class="iwt-card"><div class="iwt-card-head"><h2>Seus funis</h2><label class="iwt-check"><input type="checkbox" id="iwt-show-archived"' + (FUNNELS_SHOW_ARCHIVED ? ' checked' : '') + '> Mostrar arquivados</label></div><div class="iwt-card-body" id="iwt-funnels-body"></div></section>';
    bindPeriod(app, loadFunnels);
    var nb = app.querySelector('#iwt-new-funnel');
    if (nb) { nb.addEventListener('click', newFunnelDialog); }
    app.querySelector('#iwt-show-archived').addEventListener('change', function (e) { FUNNELS_SHOW_ARCHIVED = e.target.checked; loadFunnels(); });
    app.querySelector('#iwt-funnels-body').addEventListener('click', onFunnelAction);
    loadFunnels();
  }

  function loadFunnels() {
    var body = app.querySelector('#iwt-funnels-body');
    loading(body);
    api('/admin/funnels', { params: rangeParams() }).then(function (r) {
      var list = r.funnels.filter(function (f) { return FUNNELS_SHOW_ARCHIVED || f.status !== 'archived'; });
      BOOT.funnels = r.funnels.map(function (f) { return { id: f.id, name: f.name, goal: f.goal, status: f.status }; });
      if (!list.length) {
        body.innerHTML = emptyState('Nenhum funil ainda', 'Um funil liga suas fontes de tráfego (anúncios, bio, e-mail) às páginas e ao checkout, e mede cada passo.',
          BOOT.can_manage ? '<button type="button" class="iwt-btn iwt-btn--primary" data-act="new">' + icon('plus') + 'Criar o primeiro funil</button>' : '');
        return;
      }
      body.innerHTML = '<div class="iwt-table-wrap"><table class="iwt-table"><thead><tr><th scope="col">Funil</th><th scope="col">Objetivo</th><th scope="col">Status</th>' +
        '<th scope="col" class="num">Visitas</th><th scope="col" class="num" title="Visitantes que clicaram no link do checkout (funciona sem webhook)">Checkout</th><th scope="col" class="num">Conversões</th><th scope="col" class="num">Taxa</th><th scope="col" class="num">Receita</th><th scope="col" class="num">Investimento</th><th scope="col" class="num">ROAS</th><th scope="col"><span class="screen-reader-text">Ações</span></th></tr></thead><tbody>' +
        list.map(function (f) {
          var status = { active: badge('Ativo', 'good'), paused: badge('Pausado', 'warn'), archived: badge('Arquivado', 'neutral') }[f.status];
          var actions = '<a class="iwt-btn iwt-btn--small" href="' + esc(pageUrl('iwt-funnels', '&funnel=' + f.id)) + '">Abrir</a>';
          if (BOOT.can_manage) {
            actions += '<button type="button" class="iwt-btn iwt-btn--small iwt-btn--ghost" data-act="duplicate" data-id="' + f.id + '">Duplicar</button>';
            if (f.status === 'active') { actions += '<button type="button" class="iwt-btn iwt-btn--small iwt-btn--ghost" data-act="pause" data-id="' + f.id + '">Pausar</button>'; }
            else { actions += '<button type="button" class="iwt-btn iwt-btn--small iwt-btn--ghost" data-act="activate" data-id="' + f.id + '">Ativar</button>'; }
            if (f.status !== 'archived') { actions += '<button type="button" class="iwt-btn iwt-btn--small iwt-btn--ghost" data-act="archive" data-id="' + f.id + '">Arquivar</button>'; }
          }
          return '<tr><td><a class="iwt-strong-link" href="' + esc(pageUrl('iwt-funnels', '&funnel=' + f.id)) + '">' + esc(f.name) + '</a></td>' +
            '<td>' + badge(BOOT.goals[f.goal] ? BOOT.goals[f.goal].label : f.goal, GOAL_TONE[f.goal]) + (f.platform ? ' <span class="iwt-muted">' + esc(platformLabel(f.platform)) + '</span>' : '') + '</td>' +
            '<td>' + status + '</td><td class="num">' + fmtInt(f.visits) + '</td><td class="num">' + (f.goal === 'checkout' ? fmtInt(f.checkout_visitors) : '—') + '</td><td class="num">' + fmtInt(f.conversions) + '</td><td class="num">' + fmtPct(f.conv_rate, 2) + '</td>' +
            '<td class="num">' + fmtMoney(f.revenue, f.currency) + '</td><td class="num">' + (f.cost ? fmtMoney(f.cost, f.currency) : '—') + '</td><td class="num">' + fmtRoas(f.roas) + '</td>' +
            '<td class="iwt-actions">' + actions + '</td></tr>';
        }).join('') + '</tbody></table></div>';
    }).catch(function (err) { body.innerHTML = errorBox(err); });
  }

  function platformLabel(key) {
    var p = (BOOT.platforms || []).filter(function (x) { return x.key === key; })[0];
    return p ? p.label : key;
  }

  function onFunnelAction(e) {
    var b = e.target.closest('[data-act]');
    if (!b) { return; }
    var act = b.getAttribute('data-act');
    var id = b.getAttribute('data-id');
    if (act === 'new') { newFunnelDialog(); return; }
    if (act === 'duplicate') {
      api('/admin/funnels/' + id + '/duplicate', { method: 'POST' }).then(function () { toast('Funil duplicado.', 'success'); loadFunnels(); }).catch(function (err) { toast(err.message, 'error'); });
    }
    if (act === 'pause' || act === 'activate') {
      api('/admin/funnels/' + id + '/status', { method: 'POST', body: { status: act === 'pause' ? 'paused' : 'active' } }).then(function () {
        toast(act === 'pause' ? 'Funil pausado: os links continuam redirecionando, mas param de contar.' : 'Funil ativado.', 'success');
        loadFunnels();
      }).catch(function (err) { toast(err.message, 'error'); });
    }
    if (act === 'archive') {
      confirmDialog('Arquivar funil?', 'O funil sai da lista e para de contar. Os links continuam redirecionando para não quebrar anúncios ativos.', 'Arquivar').then(function (ok) {
        if (!ok) { return; }
        api('/admin/funnels/' + id + '/status', { method: 'POST', body: { status: 'archived' } }).then(function () { toast('Funil arquivado.', 'success'); loadFunnels(); });
      });
    }
  }

  function platformOptions(selected, includeInternal) {
    return (BOOT.platforms || []).filter(function (p) { return includeInternal || !p.internal; }).map(function (p) {
      return '<option value="' + p.key + '"' + (p.key === selected ? ' selected' : '') + '>' + esc(p.label) + (p.beta ? ' (beta)' : '') + '</option>';
    }).join('');
  }

  function newFunnelDialog() {
    var goals = BOOT.goals;
    var body = '<div class="iwt-form">' +
      '<label class="iwt-field"><span>Nome do funil</span><input type="text" class="iwt-input" id="nf-name" placeholder="Ex.: Lançamento Curso X — Meta Ads" maxlength="120"></label>' +
      '<fieldset class="iwt-field"><legend>O que conta como conversão?</legend><div class="iwt-goal-cards">' +
      Object.keys(goals).map(function (k, i) {
        return '<label class="iwt-goal-card"><input type="radio" name="nf-goal" value="' + k + '"' + (i === 0 ? ' checked' : '') + '><span class="iwt-goal-title">' + esc(goals[k].label) + '</span><span class="iwt-goal-help">' + esc(goals[k].help) + '</span></label>';
      }).join('') + '</div></fieldset>' +
      '<label class="iwt-field" id="nf-platform-wrap"><span>Plataforma do checkout</span><select class="iwt-select" id="nf-platform">' + platformOptions('hotmart', true) + '</select></label>' +
      '<label class="iwt-field iwt-field--short"><span>Moeda</span><select class="iwt-select" id="nf-currency"><option>BRL</option><option>USD</option><option>EUR</option></select></label>' +
      '<p class="iwt-help">O funil já nasce com fonte → página → ' + 'etapa final. Depois é só ajustar no editor.</p>' +
      '</div>';
    var m = modal({
      title: 'Novo funil', body: body, wide: true, actions: [
        { label: 'Cancelar' },
        {
          label: 'Criar e abrir o editor', primary: true, onClick: function (close, wrap, btn) {
            var name = wrap.querySelector('#nf-name').value.trim();
            if (!name) { wrap.querySelector('#nf-name').focus(); toast('Dê um nome ao funil.', 'error'); return; }
            var goal = wrap.querySelector('input[name="nf-goal"]:checked').value;
            btn.disabled = true;
            api('/admin/funnels', { method: 'POST', body: { name: name, goal: goal, platform: wrap.querySelector('#nf-platform').value, currency: wrap.querySelector('#nf-currency').value } })
              .then(function (r) { window.location.href = pageUrl('iwt-funnels', '&funnel=' + r.id); })
              .catch(function (err) { btn.disabled = false; toast(err.message, 'error'); });
          }
        }
      ]
    });
    var wrap = m.el;
    var sync = function () {
      var goal = wrap.querySelector('input[name="nf-goal"]:checked').value;
      wrap.querySelector('#nf-platform-wrap').hidden = goal !== 'checkout';
    };
    wrap.querySelectorAll('input[name="nf-goal"]').forEach(function (r) { r.addEventListener('change', sync); });
    sync();
  }

  /* =================================================================== EDITOR DE FUNIL */

  var ED = null;

  var NODE_DEFAULTS = {
    source: function () { return { name: 'Meta Ads', config: { platform: 'meta_ads', paid: true, cpc: 0 } }; },
    page: function () { return { name: 'Página', config: { url: '' } }; },
    offer: function () { return { name: 'Checkout', config: { url: '', platform: ED.funnel.platform || '' } }; },
    thankyou: function () { return { name: 'Obrigado', config: { url: '', match: 'path' } }; },
    whatsapp: function () { return { name: 'WhatsApp', config: { phone: '', message: 'Olá! Vim pelo site.' } }; },
    condition: function () { return { name: 'Celular ou computador?', config: { field: 'device', operator: 'equals', value: 'mobile' } }; },
    rotator: function () { return { name: 'Teste A/B', config: { sticky: true } }; },
    distribution: function () { return { name: 'Distribuição', config: { mode: 'sequential' } }; },
    script: function () { return { name: 'Página com script', config: { code: '', delay: 800, message: 'Carregando…' } }; }
  };

  var FIELD_LABELS = { param: 'Parâmetro da URL', device: 'Dispositivo', os: 'Sistema', browser: 'Navegador', country: 'País (sigla)', language: 'Idioma', referrer: 'Site de origem', hour: 'Hora do dia', weekday: 'Dia da semana', in_app: 'App (Instagram, Facebook…)', channel: 'Canal' };
  var OP_LABELS = { equals: '=', not_equals: '≠', contains: 'contém', not_contains: 'não contém', in: 'está em', not_in: 'não está em', exists: 'existe', not_exists: 'não existe', gt: '>', lt: '<' };
  var CAPI_EVENTS = ['Purchase', 'Lead', 'Contact', 'CompleteRegistration', 'Schedule', 'SubmitApplication', 'Subscribe', 'StartTrial', 'InitiateCheckout'];

  // Modelos de UTM sugeridos por plataforma (macros oficiais de cada rede).
  var UTM_TEMPLATES = {
    meta_ads: 'utm_source=facebook&utm_medium=paid&utm_campaign={{campaign.name}}&utm_content={{ad.name}}&utm_term={{adset.name}}',
    google_ads: 'utm_source=google&utm_medium=cpc&utm_campaign={campaignid}&utm_content={creative}&utm_term={keyword}',
    youtube_ads: 'utm_source=youtube&utm_medium=cpc&utm_campaign={campaignid}&utm_content={creative}',
    tiktok_ads: 'utm_source=tiktok&utm_medium=paid&utm_campaign=__CAMPAIGN_NAME__&utm_content=__CID_NAME__&utm_term=__AID_NAME__',
    kwai_ads: 'utm_source=kwai&utm_medium=paid&utm_campaign={{campaign_name}}&utm_content={{creative_name}}'
  };

  function renderEditor(id) {
    loading();
    api('/admin/funnels/' + id).then(function (g) {
      ED = { id: id, funnel: g.funnel, dirty: false, editor: null, showStats: lsGet('iwt_ed_stats', true), stats: null };
      var manage = BOOT.can_manage;
      var palette = Object.keys(BOOT.node_types).map(function (t) {
        return '<button type="button" class="iwt-palette-btn iwt-palette-btn--' + t + '" data-add="' + t + '" title="' + esc(BOOT.node_types[t].help) + '">' + window.IWTEditor.icon(t) + '<span>' + esc(BOOT.node_types[t].label) + '</span></button>';
      }).join('');
      app.innerHTML =
        '<header class="iwt-header iwt-header--editor">' +
        '<a class="iwt-btn iwt-btn--ghost iwt-btn--small" href="' + esc(pageUrl('iwt-funnels')) + '">' + icon('back') + 'Funis</a>' +
        '<label class="screen-reader-text" for="ed-name">Nome do funil</label><input id="ed-name" class="iwt-title-input" size="' + Math.max(20, g.funnel.name.length + 2) + '" value="' + esc(g.funnel.name) + '"' + (manage ? '' : ' readonly') + '>' +
        badge(BOOT.goals[g.funnel.goal].label, GOAL_TONE[g.funnel.goal]) +
        (g.funnel.platform ? ' <span class="iwt-muted">' + esc(platformLabel(g.funnel.platform)) + '</span>' : '') +
        '<span class="iwt-spacer"></span>' +
        '<select id="ed-status" class="iwt-select" aria-label="Status do funil"' + (manage ? '' : ' disabled') + '>' +
        ['active', 'paused', 'archived'].map(function (s) { return '<option value="' + s + '"' + (g.funnel.status === s ? ' selected' : '') + '>' + { active: 'Ativo', paused: 'Pausado', archived: 'Arquivado' }[s] + '</option>'; }).join('') + '</select>' +
        (manage ? '<button type="button" class="iwt-btn iwt-btn--ghost" id="ed-settings">' + icon('gear') + 'Configurações do funil</button>' +
          '<button type="button" class="iwt-btn iwt-btn--primary" id="ed-save" disabled>Salvo</button>' : '') +
        themeButton() +
        '</header>' +
        '<div class="iwt-editor-bar">' + (manage ? '<div class="iwt-palette" role="toolbar" aria-label="Adicionar etapa">' + palette + '</div>' : '<div></div>') +
        '<div class="iwt-editor-bar-right">' + periodPicker() + '<label class="iwt-check"><input type="checkbox" id="ed-stats"' + (ED.showStats ? ' checked' : '') + '> Mostrar números</label></div></div>' +
        '<div class="iwt-editor">' +
        '<div class="iwt-editor-canvas" id="ed-canvas"></div>' +
        '<aside class="iwt-inspector" id="ed-inspector" aria-label="Configuração da etapa selecionada"></aside>' +
        '</div>' +
        '<div id="ed-ab" class="iwt-ab-list"></div>' +
        '<section class="iwt-kpis iwt-kpis--funnel" id="ed-kpis"></section>' +
        '<div class="iwt-grid-2">' +
        '<section class="iwt-card"><div class="iwt-card-head"><h2>Por fonte de tráfego</h2></div><div class="iwt-card-body" id="ed-sources"></div></section>' +
        '<section class="iwt-card"><div class="iwt-card-head"><h2>Links do funil</h2><span class="iwt-card-hint">Cada conexão é um link rastreável.</span></div><div class="iwt-card-body" id="ed-links"></div></section>' +
        '</div>';

      var platformsMap = {};
      (BOOT.traffic_platforms || []).forEach(function (p) { platformsMap[p.key] = p.label; });
      ED.editor = window.IWTEditor.create(app.querySelector('#ed-canvas'), {
        graph: g,
        types: BOOT.node_types,
        readOnly: !manage,
        labels: { platforms: platformsMap, fields: FIELD_LABELS, operators: OP_LABELS, temperatures: BOOT.temperatures }
      });
      ED.editor.on('change', function () { setDirty(true); renderLinksTable(); abOnChange(); });
      ED.editor.on('select', function () { renderInspector(); });
      ED.editor.on('notice', function (msg) { toast(msg, 'error'); });
      setTimeout(function () { ED.editor.fit(); }, 30);

      bindEditor();
      bindSplitEvents(app.querySelector('#ed-inspector'));
      bindSplitEvents(app.querySelector('#ed-ab'));
      renderInspector();
      renderAbCards();
      renderLinksTable();
      loadEditorStats();
    }).catch(function (err) { app.innerHTML = errorBox(err); });
  }

  function setDirty(v) {
    ED.dirty = v;
    var b = app.querySelector('#ed-save');
    if (b) {
      b.disabled = !v;
      b.textContent = v ? 'Salvar alterações' : 'Salvo';
    }
  }

  function bindEditor() {
    var manage = BOOT.can_manage;
    window.addEventListener('beforeunload', function (e) {
      if (ED && ED.dirty) { e.preventDefault(); e.returnValue = ''; }
    });
    bindPeriod(app, loadEditorStats);
    app.querySelector('#ed-stats').addEventListener('change', function (e) {
      ED.showStats = e.target.checked;
      lsSet('iwt_ed_stats', ED.showStats);
      ED.editor.setStats(ED.showStats ? ED.stats : null);
    });
    if (!manage) { return; }
    app.querySelector('#ed-name').addEventListener('input', function (e) { ED.funnel.name = e.target.value; e.target.size = Math.max(20, e.target.value.length + 2); setDirty(true); });
    app.querySelector('#ed-status').addEventListener('change', function (e) { ED.funnel.status = e.target.value; setDirty(true); });
    app.querySelector('#ed-save').addEventListener('click', saveFunnel);
    app.querySelector('#ed-settings').addEventListener('click', funnelSettingsDialog);
    app.querySelectorAll('[data-add]').forEach(function (b) {
      b.addEventListener('click', function () {
        var t = b.getAttribute('data-add');
        var d = NODE_DEFAULTS[t]();
        ED.editor.addNode(t, d.name, d.config);
      });
    });
    document.addEventListener('keydown', function (e) {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's' && ED && ED.dirty) {
        e.preventDefault();
        saveFunnel();
      }
    });
  }

  function saveFunnel() {
    var btn = app.querySelector('#ed-save');
    btn.disabled = true;
    btn.textContent = 'Salvando…';
    var g = ED.editor.graph();
    var sel = ED.editor.selected();
    api('/admin/funnels/' + ED.id, { method: 'POST', body: { funnel: ED.funnel, nodes: g.nodes, links: g.links } }).then(function (r) {
      ED.funnel = r.graph.funnel;
      ED.editor.load(r.graph);
      if (sel && r.map && r.map[sel.id] !== undefined) { ED.editor.select(sel.kind, String(r.map[sel.id])); }
      setDirty(false);
      renderInspector();
      renderLinksTable();
      if (r.warnings && r.warnings.length) {
        toast('Salvo, com avisos: ' + r.warnings.join(' '), 'error');
      } else {
        toast('Funil salvo.', 'success');
      }
      loadEditorStats();
    }).catch(function (err) {
      setDirty(true);
      toast(err.message, 'error');
    });
  }

  function loadEditorStats() {
    api('/admin/funnels/' + ED.id + '/stats', { params: rangeParams() }).then(function (s) {
      var links = {};
      s.links.forEach(function (l) { links[l.link_id] = l; });
      var nodes = {};
      s.nodes.forEach(function (n) { nodes[n.node_id] = n; });
      var conv = {};
      s.conversions.forEach(function (c) {
        if (c.status !== 'approved') { return; }
        conv[c.node_id] = conv[c.node_id] || { count: 0, value: 0 };
        conv[c.node_id].count += c.count;
        conv[c.node_id].value += c.value;
      });
      ED.stats = { links: links, nodes: nodes, conversions: conv, raw: s };
      ED.editor.setStats(ED.showStats ? ED.stats : null);
      renderEditorKpis(s.totals);
      renderSourcesTable(s.sources);
      renderLinksTable();
      renderInspector();
      renderAbCards();
    }).catch(function (err) { toast('Números do funil: ' + err.message, 'error'); });
  }

  function renderEditorKpis(t) {
    var cur = ED.funnel.currency;
    var items = [
      ['Visitas', fmtInt(t.visits)], ['Visitantes únicos', fmtInt(t.visitors)], ED.funnel.goal === 'checkout' ? ['Chegaram ao checkout', fmtInt(t.checkout_visitors) + (t.checkout_rate != null ? ' · ' + fmtPct(t.checkout_rate, 1) : '')] : ['Cliques nos links', fmtInt(t.clicks)],
      ['Conversões', fmtInt(t.conversions)], ['Taxa de conversão', fmtPct(t.conv_rate, 2)], ['Receita', fmtMoney(t.revenue, cur)],
      ['Pendentes', fmtInt(t.pending) + ' · ' + fmtMoney(t.pending_value, cur)], ['Investimento', fmtMoney(t.cost, cur)], ['ROAS', fmtRoas(t.roas)], ['CPA', fmtMoney(t.cpa, cur)]
    ];
    var noWebhook = ED.funnel.goal === 'checkout' && t.checkout_visitors > 0 && !t.sales && !t.pending && !t.refunds;
    app.querySelector('#ed-kpis').innerHTML = items.map(function (x) {
      return '<div class="iwt-kpi"><span class="iwt-kpi-label">' + esc(x[0]) + '</span><span class="iwt-kpi-value iwt-kpi-value--sm">' + x[1] + '</span></div>';
    }).join('') + (noWebhook ? '<p class="iwt-notice iwt-notice--info iwt-kpis-note">' + icon('info') + '<span>O funil já mede tudo até o checkout. Para ver as <strong>vendas</strong> e a receita, cadastre o webhook da plataforma em <a href="' + esc(pageUrl('iwt-integrations')) + '">Integrações</a>.</span></p>' : '');
  }

  function renderSourcesTable(rows) {
    var box = app.querySelector('#ed-sources');
    if (!rows.length) { box.innerHTML = '<p class="iwt-muted iwt-pad">Sem tráfego no período.</p>'; return; }
    var cur = ED.funnel.currency;
    box.innerHTML = '<table class="iwt-table iwt-table--compact"><thead><tr><th scope="col">Fonte</th><th scope="col" class="num">Visitas</th><th scope="col" class="num">Conv.</th><th scope="col" class="num">Receita</th><th scope="col" class="num">Invest.</th><th scope="col" class="num">ROAS</th><th scope="col" class="num">CPA</th></tr></thead><tbody>' +
      rows.map(function (r) {
        var n = r.node_id ? ED.editor.node(r.node_id) : null;
        var name = n ? n.name : (r.node_id ? 'Fonte removida #' + r.node_id : '(fora das fontes do funil)');
        var temp = n && n.config && n.config.temperature && n.config.temperature !== 'auto' ? n.config.temperature : '';
        return '<tr><td>' + esc(name) + (temp ? ' ' + badge(BOOT.temperatures[temp] || temp, TEMP_TONE[temp]) : '') + '</td><td class="num">' + fmtInt(r.visits) + '</td><td class="num">' + fmtInt(r.conversions) + '</td><td class="num">' + fmtMoney(r.revenue, cur) +
          '</td><td class="num">' + (r.cost ? fmtMoney(r.cost, cur) : '—') + '</td><td class="num">' + fmtRoas(r.roas) + '</td><td class="num">' + (r.cpa != null ? fmtMoney(r.cpa, cur) : '—') + '</td></tr>';
      }).join('') + '</tbody></table>';
  }

  function linkWhere(l) {
    var from = ED.editor.node(l.from);
    var to = ED.editor.node(l.to);
    if (!from || !to) { return ''; }
    if (from.type === 'source') { return 'No anúncio / divulgação de "' + from.name + '"'; }
    if (from.type === 'page' || from.type === 'thankyou') { return 'No botão da página "' + from.name + '"'; }
    return 'Usado internamente (depois de "' + from.name + '")';
  }

  function renderLinksTable() {
    var box = app.querySelector('#ed-links');
    if (!box || !ED) { return; }
    var links = ED.editor.links();
    if (!links.length) { box.innerHTML = '<p class="iwt-muted iwt-pad">Conecte as etapas para gerar links.</p>'; return; }
    box.innerHTML = '<ul class="iwt-linklist">' + links.map(function (l) {
      var from = ED.editor.node(l.from);
      var to = ED.editor.node(l.to);
      var s = ED.stats && ED.stats.links[l.id];
      var internal = from && ['condition', 'rotator', 'distribution', 'script'].indexOf(from.type) !== -1;
      return '<li><div class="iwt-linklist-route"><strong>' + esc(from ? from.name : '?') + '</strong> → <strong>' + esc(to ? to.name : '?') + '</strong>' +
        (s ? ' <span class="iwt-muted">· ' + plural(s.clicks, 'clique', 'cliques') + ' · ' + plural(s.visitors, 'visitante', 'visitantes') + '</span>' : '') + '</div>' +
        (l.url ? '<div class="iwt-copyrow"><code>' + esc(l.url) + '</code><button type="button" class="iwt-icon-btn" data-copy="' + esc(l.url) + '" aria-label="Copiar link">' + icon('copy') + '</button></div>'
          : '<div class="iwt-muted">Salve o funil para gerar o link.</div>') +
        '<div class="iwt-help">' + esc(internal ? 'Link interno, gerado automaticamente.' : linkWhere(l)) + '</div></li>';
    }).join('') + '</ul>';
    box.querySelectorAll('[data-copy]').forEach(function (b) { b.addEventListener('click', function () { copy(b.getAttribute('data-copy'), 'Link copiado'); }); });
  }

  function field(label, input, help) {
    return '<label class="iwt-field"><span>' + esc(label) + '</span>' + input + (help ? '<small class="iwt-help">' + help + '</small>' : '') + '</label>';
  }
  function inputText(name, value, attrs) {
    return '<input type="text" class="iwt-input" data-cfg="' + name + '" value="' + esc(value == null ? '' : value) + '" ' + (attrs || '') + '>';
  }
  function checkbox(name, checked, label) {
    return '<label class="iwt-check"><input type="checkbox" data-cfg="' + name + '"' + (checked ? ' checked' : '') + '> ' + esc(label) + '</label>';
  }

  function renderInspector() {
    var box = app.querySelector('#ed-inspector');
    if (!box || !ED) { return; }
    var sel = ED.editor.selected();
    var ro = !BOOT.can_manage;
    if (!sel) {
      box.innerHTML = '<div class="iwt-inspector-empty"><h3>Como montar</h3><ol>' +
        '<li>Adicione etapas pela barra acima.</li><li>Arraste da bolinha à direita de uma etapa até a próxima para conectar.</li>' +
        '<li>Clique numa etapa ou conexão para configurar.</li><li>Salve: cada conexão vira um link rastreável.</li></ol>' +
        '<p class="iwt-help">Dica: o link que sai da <strong>Fonte de tráfego</strong> é o que vai no anúncio. O link que sai de uma <strong>Página</strong> vai no botão daquela página.</p></div>';
      return;
    }
    if (sel.kind === 'link') { return renderLinkInspector(box, ED.editor.link(sel.id), ro); }
    var n = ED.editor.node(sel.id);
    if (!n) { box.innerHTML = ''; return; }
    var c = n.config || {};
    var t = BOOT.node_types[n.type];
    var html = '<div class="iwt-inspector-head"><span class="iwt-inspector-icon iwt-node--' + n.type + '">' + window.IWTEditor.icon(n.type) + '</span><div><h3>' + esc(t.label) + '</h3><p class="iwt-help">' + esc(t.help) + '</p></div></div>';
    html += '<div class="iwt-form">' + field('Nome', '<input type="text" class="iwt-input" data-name value="' + esc(n.name) + '">');

    if (n.type === 'source') {
      html += field('Plataforma', '<select class="iwt-select" data-cfg="platform">' + BOOT.traffic_platforms.map(function (p) {
        return '<option value="' + p.key + '"' + (p.key === c.platform ? ' selected' : '') + '>' + esc(p.label) + '</option>';
      }).join('') + '</select>');
      html += checkbox('paid', c.paid, 'É mídia paga (entra em "último clique pago" e no ROAS)');
      html += field('Temperatura do público', '<select class="iwt-select" data-cfg="temperature">' + [['auto', 'Automática (pela campanha e público da UTM)'], ['cold', 'Frio'], ['warm', 'Morno'], ['hot', 'Quente (remarketing, base)'], ['organic', 'Orgânico']].map(function (o) {
        return '<option value="' + o[0] + '"' + ((c.temperature || 'auto') === o[0] ? ' selected' : '') + '>' + esc(o[1]) + '</option>';
      }).join('') + '</select>', 'Fixe aqui quando este link for usado para um público só (ex.: uma fonte "Meta — Frio" e outra "Meta — Quente"). Na automática, o plugin procura frio, quente, remarketing, lookalike… no nome da campanha e do conjunto (veja Configurações).');
      html += field('Custo por clique (CPC)', inputText('cpc', c.cpc || '', 'inputmode="decimal" placeholder="0,00"'), 'Opcional. Para custo real por dia use a tela Custos.');
      html += field('Parâmetro da URL com o custo', inputText('cost_param', c.cost_param || '', 'placeholder="ex.: cost"'), 'Opcional: se o anúncio passar o custo do clique num parâmetro, ele substitui o CPC.');
      var outs = ED.editor.links().filter(function (l) { return String(l.from) === String(n.id); });
      var tpl = UTM_TEMPLATES[c.platform];
      if (outs.length) {
        html += '<div class="iwt-field"><span>Link para usar no anúncio</span>' + outs.map(function (l) {
          if (!l.url) { return '<div class="iwt-muted">Salve o funil para gerar o link.</div>'; }
          var withUtm = tpl ? l.url + (l.url.indexOf('?') === -1 ? '?' : '&') + tpl : '';
          return '<div class="iwt-copyrow"><code>' + esc(l.url) + '</code><button type="button" class="iwt-icon-btn" data-copy="' + esc(l.url) + '" aria-label="Copiar link">' + icon('copy') + '</button></div>' +
            (withUtm ? '<button type="button" class="iwt-link-btn" data-copy="' + esc(withUtm) + '">Copiar com UTMs sugeridas para ' + esc(platformName(c.platform)) + '</button>' : '');
        }).join('') + '</div>';
      } else {
        html += '<p class="iwt-help">Conecte esta fonte à primeira página do funil para gerar o link do anúncio.</p>';
      }
    } else if (n.type === 'page' || n.type === 'thankyou') {
      html += field('URL da página', inputText('url', c.url, 'placeholder="https://"'), 'Pode usar {utm_source}, {iwt_vid} e qualquer {parametro} recebido.');
      if (n.type === 'thankyou') {
        html += field('Reconhecer a página por', '<select class="iwt-select" data-cfg="match"><option value="path"' + (c.match === 'path' || !c.match ? ' selected' : '') + '>Mesmo caminho (ignora parâmetros)</option><option value="prefix"' + (c.match === 'prefix' ? ' selected' : '') + '>Caminho que começa com</option><option value="exact"' + (c.match === 'exact' ? ' selected' : '') + '>URL exata</option></select>',
          'Conta conversão quando o visitante abre esta página (com o script do plugin) ou quando passa por um link que aponta para cá.');
      }
      var pageOuts = ED.editor.links().filter(function (l) { return String(l.from) === String(n.id); });
      if (pageOuts.length) {
        html += '<div class="iwt-field"><span>Links para os botões desta página</span>' + pageOuts.map(function (l) {
          var to = ED.editor.node(l.to);
          return '<div class="iwt-help">→ ' + esc(to ? to.name : '') + '</div>' + (l.url ? '<div class="iwt-copyrow"><code>' + esc(l.url) + '</code><button type="button" class="iwt-icon-btn" data-copy="' + esc(l.url) + '" aria-label="Copiar link">' + icon('copy') + '</button></div>' : '<div class="iwt-muted">Salve para gerar.</div>');
        }).join('') + '</div>';
      }
    } else if (n.type === 'offer') {
      html += field('URL do checkout', inputText('url', c.url, 'placeholder="https://pay.hotmart.com/..."'));
      html += field('Plataforma', '<select class="iwt-select" data-cfg="platform"><option value="">Igual à do funil (' + esc(platformLabel(ED.funnel.platform) || '—') + ')</option>' + platformOptions(c.platform, true) + '</select>');
      var pkey = c.platform || ED.funnel.platform;
      var pp = (BOOT.platforms || []).filter(function (x) { return x.key === pkey; })[0];
      if (pp && pp.params && pp.params.length) {
        html += '<p class="iwt-help">O código de rastreio entra automaticamente em <code>' + esc(pp.params.join(', ')) + '</code> e volta no webhook da venda.' + (pp.beta ? ' Preset beta: confira o log do primeiro webhook.' : '') + '</p>';
      }
      html += field('ID do produto (opcional)', inputText('product_id', c.product_id || ''), 'Ajuda a atribuir ao funil vendas que chegarem sem o código de rastreio.');
      html += field('URL reserva (opcional)', inputText('backup_url', c.backup_url || '', 'placeholder="https://"'));
    } else if (n.type === 'whatsapp') {
      html += field('Número com DDD', inputText('phone', c.phone || '', 'inputmode="tel" placeholder="(11) 99999-9999"'), 'Sem DDI, o plugin assume Brasil (+55).');
      html += field('Mensagem', '<textarea class="iwt-input" data-cfg="message" rows="3">' + esc(c.message || '') + '</textarea>', 'Pode usar {utm_campaign} e outros {parametros}.');
      html += checkbox('append_code', c.append_code, 'Acrescentar código de referência na mensagem (para cruzar com a conversa)');
      html += field('Ou link personalizado (opcional)', inputText('url', c.url || '', 'placeholder="https://wa.link/..."'));
    } else if (n.type === 'condition') {
      html += field('Testar', '<select class="iwt-select" data-cfg="field">' + BOOT.condition_fields.map(function (f) {
        return '<option value="' + f + '"' + (f === c.field ? ' selected' : '') + '>' + esc(FIELD_LABELS[f] || f) + '</option>';
      }).join('') + '</select>');
      if (c.field === 'param') { html += field('Nome do parâmetro', inputText('param', c.param || '', 'placeholder="ex.: utm_source"')); }
      html += field('Operador', '<select class="iwt-select" data-cfg="operator">' + Object.keys(OP_LABELS).map(function (o) {
        return '<option value="' + o + '"' + (o === c.operator ? ' selected' : '') + '>' + esc(OP_LABELS[o]) + '</option>';
      }).join('') + '</select>');
      html += field('Valor', inputText('value', c.value || ''), conditionHint(c.field));
      html += '<p class="iwt-help">Ligue a bolinha <strong>Sim</strong> ao destino de quando a regra é verdadeira e a <strong>Não</strong> ao destino contrário.</p>';
    } else if (n.type === 'rotator') {
      var nOuts = ED.editor.outputs(n.id).length;
      html += splitCompact(n, ro);
      if (nOuts > 4) {
        html += '<p class="iwt-help">Com ' + nOuts + ' versões cada página recebe menos visitas e o teste demora mais para dar resultado. Pause (0%) as que ficarem para trás.</p>';
      }
      html += checkbox('sticky', c.sticky !== false, 'Fixar variação: o mesmo visitante sempre vê a mesma versão');
      if (nOuts) {
        html += '<button type="button" class="iwt-btn iwt-btn--small" data-goto-ab="' + esc(n.id) + '">' + icon('down') + 'Ver resultados e divisão em tela cheia</button>';
      }
    } else if (n.type === 'distribution') {
      html += field('Modo', '<select class="iwt-select" data-cfg="mode"><option value="sequential"' + (c.mode !== 'balanced' ? ' selected' : '') + '>Sequencial (enche uma saída, depois a próxima)</option><option value="balanced"' + (c.mode === 'balanced' ? ' selected' : '') + '>Equilibrado (sempre a que tem menos acessos)</option></select>');
      var outsD = ED.editor.outputs(n.id);
      if (!outsD.length) {
        html += '<p class="iwt-help">Conecte duas ou mais saídas a partir daqui.</p>';
      } else {
        html += '<div class="iwt-field"><span>Limite de acessos por saída</span>' + outsD.map(function (l) {
          var to = ED.editor.node(l.to);
          var lc = l.config || {};
          return '<div class="iwt-inline"><span class="iwt-ellipsis">' + esc(to ? to.name : '') + '</span><input type="number" min="0" class="iwt-input iwt-input--num" data-link-limit="' + esc(l.id) + '" value="' + esc(lc.limit != null ? lc.limit : 100) + '">' +
            '<label class="iwt-check"><input type="radio" name="dist-default" data-link-default="' + esc(l.id) + '"' + (lc.is_default ? ' checked' : '') + '> padrão</label></div>';
        }).join('') + '</div>';
        html += '<p class="iwt-help">0 = sem limite. Quando todas lotarem, vai para a saída marcada como padrão.</p>';
      }
    } else if (n.type === 'script') {
      html += field('Código (pixel, tag…)', '<textarea class="iwt-input iwt-code" data-cfg="code" rows="6"' + (BOOT.can_script ? '' : ' disabled') + '>' + esc(c.code || '') + '</textarea>',
        BOOT.can_script ? 'É executado numa página intermediária antes de seguir para a próxima etapa.' : 'Só administradores com permissão para HTML sem filtro podem editar o código.');
      html += field('Espera antes de seguir (ms)', inputText('delay', c.delay != null ? c.delay : 800, 'inputmode="numeric"'));
      html += field('Mensagem na tela', inputText('message', c.message || ''));
    }

    var st = ED.stats && ED.stats.nodes[n.id];
    var cv = ED.stats && ED.stats.conversions[n.id];
    if (st || cv) {
      html += '<div class="iwt-inspector-stats"><span>No período:</span> ' + (st ? '<strong>' + fmtInt(st.visitors) + '</strong> visitantes · ' + fmtInt(st.arrivals) + ' acessos' : '') +
        (cv ? ' · <strong>' + fmtInt(cv.count) + '</strong> conversões (' + fmtMoney(cv.value, ED.funnel.currency) + ')' : '') + '</div>';
    }
    if (!ro) { html += '<button type="button" class="iwt-btn iwt-btn--danger iwt-btn--small" data-remove>' + icon('trash') + 'Remover etapa</button>'; }
    html += '</div>';
    box.innerHTML = html;
    if (ro) { box.querySelectorAll('input, select, textarea').forEach(function (i) { i.disabled = true; }); }
    bindInspector(box, 'node', n);
    refreshSplits();
  }

  /* ---- Teste A/B: divisão do tráfego (painel lateral + cartão largo abaixo do desenho) e resultados ---- */

  function linkWeight(l) { return l.config && l.config.weight != null ? Math.max(0, +l.config.weight || 0) : 50; }
  function shortUrl(u) { return String(u || '').replace(/^https?:\/\/(www\.)?/, '').replace(/\/$/, ''); }

  function splitControl(l, idx, ro) {
    var w = linkWeight(l);
    var lt = window.IWTEditor.letter(idx);
    var dis = ro ? ' disabled' : '';
    return '<div class="iwt-split-ctl"><input type="range" class="iwt-split-range" min="0" max="100" step="1" value="' + w + '" data-split-weight="' + esc(l.id) + '" aria-label="Tráfego da versão ' + lt + ' (%)"' + dis + '>' +
      '<input type="number" class="iwt-input iwt-split-num" min="0" max="100" step="1" value="' + w + '" data-split-weight="' + esc(l.id) + '" aria-label="Tráfego da versão ' + lt + ' (%)"' + dis + '><span class="iwt-split-unit">%</span></div>';
  }

  function splitFoot(rid, ro) {
    return '<div class="iwt-split-foot"><span class="iwt-split-total" data-split-total></span>' +
      (ro ? '' : '<span class="iwt-spacer"></span><button type="button" class="iwt-btn iwt-btn--small" data-split-even="' + esc(rid) + '">Dividir igualmente</button>' +
        '<button type="button" class="iwt-btn iwt-btn--small iwt-btn--primary" data-split-fix="' + esc(rid) + '" hidden>Ajustar para 100%</button>') +
      '</div><p class="iwt-split-warn" data-split-warn hidden></p>';
  }

  function splitCompact(n, ro) {
    var outs = ED.editor.outputs(n.id);
    if (!outs.length) {
      return '<p class="iwt-help">Conecte as páginas que vão disputar o tráfego: arraste da bolinha à direita deste bloco até cada página. Pode ligar quantas quiser.</p>';
    }
    return '<div class="iwt-field"><span>Divisão do tráfego</span><div class="iwt-split" data-split="' + esc(n.id) + '">' + outs.map(function (l, i) {
      var to = ED.editor.node(l.to);
      return '<div class="iwt-split-row" data-split-row="' + esc(l.id) + '"><div class="iwt-split-label"><span class="iwt-split-letter">' + window.IWTEditor.letter(i) + '</span>' +
        '<span class="iwt-ellipsis">' + esc(to ? to.name : '') + '</span><span class="iwt-split-paused">pausada</span></div>' + splitControl(l, i, ro) + '</div>';
    }).join('') + splitFoot(n.id, ro) + '</div></div>';
  }

  /** Atualiza números, totais e avisos de todas as divisões na tela, sem redesenhar (não atrapalha quem está arrastando). */
  function refreshSplits() {
    if (!ED || !ED.editor) { return; }
    app.querySelectorAll('[data-split]').forEach(function (box) {
      var outs = ED.editor.outputs(box.getAttribute('data-split'));
      var total = 0;
      outs.forEach(function (l) {
        var w = linkWeight(l);
        total += w;
        box.querySelectorAll('[data-split-weight="' + l.id + '"]').forEach(function (inp) {
          if (inp !== document.activeElement || inp.type === 'range') { inp.value = w; }
        });
        var row = box.querySelector('[data-split-row="' + l.id + '"]');
        if (row) { row.classList.toggle('is-paused', w === 0); }
      });
      var ok = total === 100;
      var t = box.querySelector('[data-split-total]');
      if (t) {
        t.className = 'iwt-split-total ' + (ok ? 'is-ok' : 'is-off');
        t.innerHTML = icon(ok ? 'check' : 'alert') + '<span>Total: <strong>' + fmtInt(total) + '%</strong></span>';
      }
      var fix = box.querySelector('[data-split-fix]');
      if (fix) { fix.hidden = ok || total === 0; }
      var warn = box.querySelector('[data-split-warn]');
      if (warn) {
        warn.hidden = ok;
        warn.textContent = total === 0 ? 'Todas as versões estão em 0%: o tráfego será dividido igualmente.'
          : 'A soma está em ' + fmtInt(total) + '%. O tráfego é dividido proporcionalmente; clique em "Ajustar para 100%" para deixar os números exatos.';
      }
    });
  }

  function bindSplitEvents(root) {
    if (!root) { return; }
    root.addEventListener('click', function (e) {
      var go = e.target.closest('[data-goto-ab]');
      if (go) {
        var card = app.querySelector('#ed-ab-' + go.getAttribute('data-goto-ab'));
        if (card) { card.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
        return;
      }
      if (!BOOT.can_manage) { return; }
      var b = e.target.closest('[data-split-even], [data-split-fix], [data-ab-apply]');
      if (!b) { return; }
      var shares = window.IWTEditor.shares;
      var rid, outs, weights;
      if (b.hasAttribute('data-ab-apply')) {
        var p = b.getAttribute('data-ab-apply').split(':'); // teste:conexão:%
        rid = p[0];
        outs = ED.editor.outputs(rid);
        var others = outs.filter(function (l) { return String(l.id) !== p[1]; });
        var rest = shares(others.map(function () { return 1; }), 100 - (+p[2]));
        weights = outs.map(function (l) { return String(l.id) === p[1] ? +p[2] : rest[others.indexOf(l)]; });
      } else {
        var even = b.hasAttribute('data-split-even');
        rid = b.getAttribute(even ? 'data-split-even' : 'data-split-fix');
        outs = ED.editor.outputs(rid);
        weights = shares(outs.map(function (l) { return even ? 1 : linkWeight(l); }));
      }
      outs.forEach(function (l, i) { ED.editor.updateLink(l.id, { config: { weight: weights[i] } }); });
      toast('Divisão atualizada. Clique em "Salvar alterações" para valer.');
    });
    if (!BOOT.can_manage) { return; }
    root.addEventListener('input', function (e) {
      var inp = e.target.closest('[data-split-weight]');
      if (!inp) { return; }
      var v = parseInt(inp.value, 10);
      if (isNaN(v)) { return; }
      var w = Math.max(0, Math.min(100, v));
      if (w !== v) { inp.value = w; } // acima de 100 ou negativo: o campo mostra o valor que vale
      ED.editor.updateLink(inp.getAttribute('data-split-weight'), { config: { weight: w } });
    });
    root.addEventListener('change', function (e) { if (e.target.closest('[data-split-weight]')) { refreshSplits(); } });
  }

  // Gerador pseudoaleatório com semente: a "chance de ser a melhor" não muda a cada vez que a tela redesenha.
  function seededRandom(seed) {
    var t = seed >>> 0;
    return function () {
      t += 0x6D2B79F5;
      var r = Math.imul(t ^ (t >>> 15), 1 | t);
      r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
      return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
    };
  }
  function sampleGamma(k, rnd) { // Marsaglia-Tsang (k >= 1)
    var d = k - 1 / 3, c = 1 / Math.sqrt(9 * d);
    for (;;) {
      var x, v;
      do {
        var u1 = rnd() || 1e-12, u2 = rnd();
        x = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
        v = 1 + c * x;
      } while (v <= 0);
      v = v * v * v;
      var u = rnd();
      if (u < 1 - 0.0331 * x * x * x * x || Math.log(u) < 0.5 * x * x + d * (1 - v + Math.log(v))) { return d * v; }
    }
  }
  /** Probabilidade de cada versão ter a maior taxa real: Beta(1 + sucessos, 1 + fracassos), 4.000 sorteios. */
  function chanceToBeBest(pairs) {
    var draws = 4000;
    var wins = pairs.map(function () { return 0; });
    var rnd = seededRandom(pairs.reduce(function (s, p) { return (s * 31 + p[0] * 7 + p[1]) % 2147483647; }, 17));
    for (var i = 0; i < draws; i++) {
      var best = 0, bestVal = -1;
      for (var j = 0; j < pairs.length; j++) {
        var g1 = sampleGamma(1 + pairs[j][0], rnd), g2 = sampleGamma(1 + Math.max(0, pairs[j][1] - pairs[j][0]), rnd);
        var val = g1 / (g1 + g2);
        if (val > bestVal) { bestVal = val; best = j; }
      }
      wins[best]++;
    }
    return wins.map(function (w) { return w / draws; });
  }

  function abNotice(tone, html) {
    return '<p class="iwt-notice iwt-notice--' + tone + '">' + icon(tone === 'good' ? 'check' : (tone === 'warn' ? 'alert' : 'info')) + '<span>' + html + '</span></p>';
  }

  /** Junta a divisão atual com os números do período e decide a recomendação. */
  function abAnalysis(n, outs) {
    var raw = ED.stats && ED.stats.raw;
    var exp = raw ? (raw.experiments || []).filter(function (x) { return String(x.node_id) === String(n.id); })[0] : null;
    var byLink = {};
    (exp ? exp.variants : []).forEach(function (v) {
      var k = String(v.link_id);
      if (!byLink[k]) { byLink[k] = { visitors: 0, checkout: 0, conversions: 0, revenue: 0, node_id: v.node_id }; }
      ['visitors', 'checkout', 'conversions', 'revenue'].forEach(function (f) { byLink[k][f] += +v[f] || 0; });
    });
    var goal = ED.funnel.goal;
    var totalConv = Object.keys(byLink).reduce(function (s, k) { return s + byLink[k].conversions; }, 0);
    var metric = goal === 'checkout' && totalConv === 0 ? 'checkout' : 'conversions';
    var names = { checkout: ['Vendas', 'vendas'], thankyou: ['Leads', 'leads'], whatsapp: ['Contatos', 'contatos'] }[goal] || ['Conversões', 'conversões'];
    if (metric === 'checkout') { names = ['Checkout', 'chegadas ao checkout']; }
    var rows = outs.map(function (l, i) {
      var to = ED.editor.node(l.to);
      var tc = (to && to.config) || {};
      return { link: l, letter: window.IWTEditor.letter(i), name: to ? to.name : '(sem destino)', sub: shortUrl(tc.url || tc.phone || ''), st: byLink[String(l.id)] || null };
    });
    Object.keys(byLink).forEach(function (k) {
      if (outs.some(function (l) { return String(l.id) === k; }) || !byLink[k].visitors) { return; }
      var node = ED.editor.node(byLink[k].node_id);
      rows.push({ link: null, letter: '–', name: (node ? node.name : 'Página') + ' (conexão removida)', sub: '', st: byLink[k] });
    });
    var live = rows.filter(function (r) { return r.st && r.st.visitors > 0; });
    var best = null;
    if (live.length >= 2) {
      var ch = chanceToBeBest(live.map(function (r) { return [r.st[metric], r.st.visitors]; }));
      live.forEach(function (r, i) { r.chance = ch[i]; if (!best || r.chance > best.chance) { best = r; } });
    }
    var rec;
    var minEvents = Math.max(20, 10 * live.length);
    if (!raw) {
      rec = '<p class="iwt-help">Carregando os números do período…</p>';
    } else if (!live.length) {
      rec = abNotice('info', 'Ainda sem visitas neste teste no período escolhido. Os resultados aparecem aqui assim que o tráfego começar.');
    } else if (live.length < 2) {
      rec = abNotice('info', 'Só uma versão recebeu visitas no período. Confira se as outras estão com mais de 0%.');
    } else {
      var minV = Math.min.apply(null, live.map(function (r) { return r.st.visitors; }));
      var events = live.reduce(function (s, r) { return s + r.st[metric]; }, 0);
      var pct = Math.round(best.chance * 100);
      var bname = 'Versão ' + best.letter + ' (' + esc(best.name) + ')';
      if (minV < 100 || events < minEvents) {
        rec = abNotice('warn', '<strong>Ainda é cedo para decidir.</strong> Espere cada versão ter pelo menos 100 visitantes e o teste somar ' + minEvents + ' ' + names[1] + '. Agora: ' +
          plural(minV, 'visitante', 'visitantes') + ' na versão com menos tráfego e ' + fmtInt(events) + ' ' + names[1] + ' no total.');
      } else if (best.chance >= 0.95) {
        rec = abNotice('good', '<strong>' + bname + ' venceu</strong> em ' + names[1] + ', com ' + pct + '% de chance de ser a melhor.');
        if (BOOT.can_manage && best.link) {
          rec += '<div class="iwt-form-actions"><button type="button" class="iwt-btn iwt-btn--primary iwt-btn--small" data-ab-apply="' + esc(n.id) + ':' + esc(best.link.id) + ':100">Mandar 100% para a versão ' + best.letter + '</button>' +
            '<button type="button" class="iwt-btn iwt-btn--small" data-ab-apply="' + esc(n.id) + ':' + esc(best.link.id) + ':90">90% para ela (continuar observando)</button></div>';
        }
      } else if (best.chance >= 0.8) {
        rec = abNotice('info', '<strong>' + bname + ' está à frente</strong> (' + pct + '% de chance de ser a melhor), mas ainda pode virar. Continue o teste.');
      } else {
        rec = abNotice('info', '<strong>Empate técnico até agora.</strong> As versões estão parecidas: continue o teste ou teste uma diferença maior entre as páginas.');
      }
    }
    return { rows: rows, metric: metric, names: names, best: best, rec: rec, ready: !!raw, showRevenue: goal === 'checkout' && totalConv > 0 };
  }

  function abCard(n) {
    var ro = !BOOT.can_manage;
    var outs = ED.editor.outputs(n.id);
    var c = n.config || {};
    var html = '<section class="iwt-card iwt-ab-card" id="ed-ab-' + esc(n.id) + '" data-split="' + esc(n.id) + '"><div class="iwt-card-head"><h2>Teste A/B: ' + esc(n.name || '(sem nome)') + '</h2>' +
      '<span class="iwt-card-hint">' + (outs.length ? plural(outs.length, 'versão', 'versões') + ' · ' + (c.sticky === false ? 'sorteio a cada acesso' : 'cada visitante sempre vê a mesma versão') : '') + '</span></div>';
    if (!outs.length) {
      return html + '<p class="iwt-muted iwt-pad">Conecte as páginas que vão disputar o tráfego: no desenho, arraste da bolinha à direita do bloco "' + esc(n.name || 'Teste A/B') + '" até cada página.</p></section>';
    }
    var an = abAnalysis(n, outs);
    var cur = ED.funnel.currency;
    var dash = an.ready ? '—' : '…';
    html += '<div class="iwt-card-body"><div class="iwt-table-wrap"><table class="iwt-table iwt-ab-table"><thead><tr><th scope="col">Versão</th><th scope="col" class="iwt-ab-split-col">Divisão do tráfego</th>' +
      '<th scope="col" class="num">Visitantes</th><th scope="col" class="num">' + esc(an.names[0]) + '</th><th scope="col" class="num">Taxa</th>' +
      (an.showRevenue ? '<th scope="col" class="num">Receita por visitante</th>' : '') + '<th scope="col" class="iwt-ab-chance-col">Chance de ser a melhor</th></tr></thead><tbody>' +
      an.rows.map(function (r) {
        var st = r.st;
        var rate = st && st.visitors ? st[an.metric] / st.visitors * 100 : null;
        var chance = r.chance != null ? Math.round(r.chance * 100) : null;
        return '<tr' + (r.link ? ' data-split-row="' + esc(r.link.id) + '"' : ' class="is-removed"') + '>' +
          '<td><div class="iwt-ab-version"><span class="iwt-split-letter">' + r.letter + '</span><span class="iwt-ab-name"><strong>' + esc(r.name) + ' <span class="iwt-split-paused">pausada</span></strong>' +
          (r.sub ? '<small>' + esc(r.sub) + '</small>' : '') + '</span></div></td>' +
          '<td>' + (r.link ? splitControl(r.link, outs.indexOf(r.link), ro) : '<span class="iwt-muted">—</span>') + '</td>' +
          '<td class="num">' + (st ? fmtInt(st.visitors) : dash) + '</td><td class="num">' + (st ? fmtInt(st[an.metric]) : dash) + '</td>' +
          '<td class="num">' + (rate != null ? fmtPct(rate, 1) : dash) + '</td>' +
          (an.showRevenue ? '<td class="num">' + (st && st.visitors ? fmtMoney(st.revenue / st.visitors, cur) : dash) + '</td>' : '') +
          '<td>' + (chance != null ? barCell(chance, 100, chance + '%') : '<span class="iwt-muted">' + dash + '</span>') + '</td></tr>';
      }).join('') + '</tbody></table></div>' +
      '<div class="iwt-ab-foot">' + splitFoot(n.id, ro) + an.rec +
      '<p class="iwt-help">Números do período escolhido no topo. "Chance de ser a melhor" compara a taxa de ' + esc(an.names[1]) + ' de cada versão com estatística bayesiana. ' +
      (c.sticky === false ? '' : 'Quem já visitou continua vendo a mesma versão mesmo se você mudar a divisão (exceto se ela for pausada com 0%).') + '</p></div></div></section>';
    return html;
  }

  function abSignature() {
    return ED.editor.nodes().filter(function (n) { return n.type === 'rotator'; }).map(function (n) {
      return n.id + '|' + n.name + '|' + ((n.config || {}).sticky === false ? 0 : 1) + '|' + ED.editor.outputs(n.id).map(function (l) {
        var to = ED.editor.node(l.to);
        return l.id + '>' + (to ? to.name + '@' + ((to.config || {}).url || '') : '');
      }).join(',');
    }).join(';');
  }

  function renderAbCards() {
    var box = app.querySelector('#ed-ab');
    if (!box || !ED || !ED.editor) { return; }
    ED.abSig = abSignature();
    box.innerHTML = ED.editor.nodes().filter(function (n) { return n.type === 'rotator'; }).map(abCard).join('');
    refreshSplits();
  }

  /** Mudança no desenho: redesenha os cartões só quando muda a estrutura (versões, nomes); pesos só atualizam os números. */
  function abOnChange() {
    if (abSignature() !== ED.abSig) { renderAbCards(); } else { refreshSplits(); }
  }

  function platformName(key) {
    var p = (BOOT.traffic_platforms || []).filter(function (x) { return x.key === key; })[0];
    return p ? p.label.replace(/ \(.*\)$/, '') : key;
  }

  function conditionHint(fieldName) {
    return {
      device: 'desktop, mobile ou tablet', os: 'Windows, macOS, iOS, Android, Linux', browser: 'Chrome, Safari, Firefox, Edge, Instagram, Facebook…',
      country: 'sigla de 2 letras: BR, PT, US…', language: 'ex.: pt-br, en', hour: '0 a 23 (horário do site)', weekday: '1 = segunda … 7 = domingo',
      in_app: 'Instagram, Facebook, TikTok…', referrer: 'domínio, ex.: google.com', channel: 'paid_social, paid_search, organic_social, direct…', param: 'Para "está em", separe valores por vírgula.'
    }[fieldName] || '';
  }

  function renderLinkInspector(box, l, ro) {
    if (!l) { box.innerHTML = ''; return; }
    var from = ED.editor.node(l.from);
    var to = ED.editor.node(l.to);
    var c = l.config || {};
    var s = ED.stats && ED.stats.links[l.id];
    var html = '<div class="iwt-inspector-head"><span class="iwt-inspector-icon">' + icon('external') + '</span><div><h3>Conexão</h3><p class="iwt-help">' + esc(from ? from.name : '') + ' → ' + esc(to ? to.name : '') + '</p></div></div><div class="iwt-form">';
    html += '<div class="iwt-field"><span>Link rastreável</span>' + (l.url ? '<div class="iwt-copyrow"><code>' + esc(l.url) + '</code><button type="button" class="iwt-icon-btn" data-copy="' + esc(l.url) + '" aria-label="Copiar link">' + icon('copy') + '</button></div><small class="iwt-help">' + esc(linkWhere(l)) + '</small>' : '<div class="iwt-muted">Salve o funil para gerar o link.</div>') + '</div>';
    html += field('Apelido do link (opcional)', '<input type="text" class="iwt-input" data-alias value="' + esc(l.alias || '') + '" placeholder="ex.: lancamento-meta">', 'Deixa o link legível: ' + esc(BOOT.link_base) + '<strong>apelido</strong>. Números puros ficam reservados ao ID.');
    if (from && from.type === 'condition') {
      html += field('Saída', '<select class="iwt-select" data-lcfg="branch"><option value="yes"' + (c.branch !== 'no' ? ' selected' : '') + '>Sim (regra verdadeira)</option><option value="no"' + (c.branch === 'no' ? ' selected' : '') + '>Não</option></select>');
    }
    if (from && from.type === 'rotator') {
      var sibs = ED.editor.outputs(from.id);
      html += field('Tráfego para a versão ' + window.IWTEditor.letter(sibs.indexOf(l)) + ' (%)', '<input type="number" min="0" max="100" class="iwt-input iwt-input--num" data-lcfg="weight" value="' + esc(c.weight != null ? c.weight : 50) + '">', 'Para ver e ajustar todas as versões juntas, clique no bloco "' + esc(from.name || 'Teste A/B') + '".');
    }
    if (from && from.type === 'distribution') {
      html += field('Limite de acessos (0 = sem limite)', '<input type="number" min="0" class="iwt-input iwt-input--num" data-lcfg="limit" value="' + esc(c.limit != null ? c.limit : 100) + '">');
      html += '<label class="iwt-check"><input type="checkbox" data-lcfg="is_default"' + (c.is_default ? ' checked' : '') + '> Saída padrão quando todas lotarem</label>';
    }
    html += '<label class="iwt-check"><input type="checkbox" data-lcfg="keep_params"' + (c.keep_params !== false ? ' checked' : '') + '> Repassar os parâmetros da URL (UTMs, fbclid, gclid…) para o destino</label>';
    html += field('Parâmetros extras (opcional)', '<input type="text" class="iwt-input" data-lcfg="extra_params" value="' + esc(c.extra_params || '') + '" placeholder="ex.: cupom=BLACK&origem={utm_source}">');
    if (s) { html += '<div class="iwt-inspector-stats"><span>No período:</span> ' + plural(s.clicks, 'clique', 'cliques') + ' · ' + plural(s.visitors, 'visitante', 'visitantes') + (s.bots ? ' · ' + fmtInt(s.bots) + ' robôs ignorados' : '') + (s.cost ? ' · ' + fmtMoney(s.cost, ED.funnel.currency) : '') + '</div>'; }
    if (!ro) { html += '<button type="button" class="iwt-btn iwt-btn--danger iwt-btn--small" data-remove>' + icon('trash') + 'Remover conexão</button>'; }
    html += '</div>';
    box.innerHTML = html;
    if (ro) { box.querySelectorAll('input, select, textarea').forEach(function (i) { i.disabled = true; }); }
    bindInspector(box, 'link', l);
  }

  function bindInspector(box, kind, obj) {
    box.querySelectorAll('[data-copy]').forEach(function (b) { b.addEventListener('click', function () { copy(b.getAttribute('data-copy'), 'Link copiado'); }); });
    if (!BOOT.can_manage) { return; }
    var rem = box.querySelector('[data-remove]');
    if (rem) { rem.addEventListener('click', function () { ED.editor.remove(kind, obj.id); }); }

    if (kind === 'node') {
      var nameInput = box.querySelector('[data-name]');
      nameInput.addEventListener('input', function () { ED.editor.updateNode(obj.id, { name: nameInput.value }); });
      box.querySelectorAll('[data-cfg]').forEach(function (inp) {
        var key = inp.getAttribute('data-cfg');
        var evt = inp.tagName === 'SELECT' || inp.type === 'checkbox' ? 'change' : 'input';
        inp.addEventListener(evt, function () {
          var patch = {};
          patch[key] = inp.type === 'checkbox' ? inp.checked : inp.value;
          if (key === 'platform' && obj.type === 'source') {
            var p = BOOT.traffic_platforms.filter(function (x) { return x.key === inp.value; })[0];
            if (p) {
              patch.paid = p.paid;
              var current = ED.editor.node(obj.id);
              var oldLabel = (BOOT.traffic_platforms.filter(function (x) { return x.key === (current.config || {}).platform; })[0] || {}).label;
              if (!current.name || current.name === oldLabel || current.name === 'Meta Ads') { ED.editor.updateNode(obj.id, { name: platformName(p.key) }); }
            }
          }
          ED.editor.updateNode(obj.id, { config: patch });
          // Campos que mudam o formulário (ex.: condição por parâmetro) redesenham o painel.
          if (key === 'field' || key === 'platform') { renderInspector(); }
        });
      });
      box.querySelectorAll('[data-link-limit]').forEach(function (inp) {
        inp.addEventListener('input', function () { ED.editor.updateLink(inp.getAttribute('data-link-limit'), { config: { limit: Math.max(0, parseInt(inp.value, 10) || 0) } }); });
      });
      box.querySelectorAll('[data-link-default]').forEach(function (inp) {
        inp.addEventListener('change', function () {
          ED.editor.links().filter(function (l) { return String(l.from) === String(obj.id); }).forEach(function (l) {
            ED.editor.updateLink(l.id, { config: { is_default: String(l.id) === inp.getAttribute('data-link-default') } });
          });
        });
      });
    } else {
      var alias = box.querySelector('[data-alias]');
      alias.addEventListener('input', function () {
        var v = alias.value.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9\-_]+/g, '-').replace(/^-+/, '');
        if (v !== alias.value) { alias.value = v; }
        ED.editor.updateLink(obj.id, { alias: v });
      });
      box.querySelectorAll('[data-lcfg]').forEach(function (inp) {
        var key = inp.getAttribute('data-lcfg');
        var evt = inp.tagName === 'SELECT' || inp.type === 'checkbox' ? 'change' : 'input';
        inp.addEventListener(evt, function () {
          var patch = {};
          if (inp.type === 'checkbox') { patch[key] = inp.checked; }
          else if (inp.type === 'number') { patch[key] = Math.max(0, parseInt(inp.value, 10) || 0); }
          else { patch[key] = inp.value; }
          ED.editor.updateLink(obj.id, { config: patch });
        });
      });
    }
  }

  function funnelSettingsDialog() {
    var f = ED.funnel;
    var s = f.settings || {};
    var isCheckout = f.goal === 'checkout';
    var body = '<div class="iwt-form">' +
      (isCheckout ? field('Plataforma do checkout', '<select class="iwt-select" id="fs-platform">' + platformOptions(f.platform, true) + '</select>', 'Define em qual parâmetro do link do checkout vai o código de rastreio.') +
        field('IDs de produto (opcional)', '<input type="text" class="iwt-input" id="fs-products" value="' + esc(s.product_ids || '') + '" placeholder="ex.: 1234567, 7654321">', 'Vendas desses produtos que chegarem sem código de rastreio ficam neste funil.')
        : field('Valor estimado de cada conversão (opcional)', '<input type="text" class="iwt-input" id="fs-value" inputmode="decimal" value="' + esc(s.lead_value || '') + '" placeholder="0,00">', 'Usado para calcular ROAS e receita estimada de leads/contatos.')) +
      field('Moeda', '<select class="iwt-select" id="fs-currency">' + ['BRL', 'USD', 'EUR'].map(function (c) { return '<option' + (f.currency === c ? ' selected' : '') + '>' + c + '</option>'; }).join('') + '</select>') +
      '<fieldset class="iwt-fieldset"><legend>Meta — API de Conversões</legend>' +
      (BOOT.capi_configured ? '' : '<p class="iwt-help">' + icon('info') + ' Configure o pixel e o token em <a href="' + esc(pageUrl('iwt-integrations')) + '">Integrações</a> para ativar.</p>') +
      '<label class="iwt-check"><input type="checkbox" id="fs-capi"' + (s.capi_enabled !== false ? ' checked' : '') + '> Enviar as conversões deste funil para o Meta</label>' +
      field('Evento', '<select class="iwt-select" id="fs-event"><option value="">Padrão (' + ({ checkout: 'Purchase', thankyou: 'Lead', whatsapp: 'Contact' }[f.goal]) + ')</option>' + CAPI_EVENTS.map(function (e) {
        return '<option' + (s.capi_event === e ? ' selected' : '') + '>' + e + '</option>';
      }).join('') + '</select>') +
      field('Pixel específico deste funil (opcional)', '<input type="text" class="iwt-input" id="fs-pixel" inputmode="numeric" value="' + esc(s.capi_pixel_id || '') + '">', 'Em branco usa o pixel padrão das Integrações.') +
      '</fieldset>' +
      field('Anotações', '<textarea class="iwt-input" id="fs-notes" rows="3">' + esc(s.notes || '') + '</textarea>') +
      '</div>';
    modal({
      title: 'Configurações do funil', body: body, actions: [
        { label: 'Cancelar' },
        {
          label: 'Aplicar', primary: true, onClick: function (close, wrap) {
            var q = function (sel) { var el = wrap.querySelector(sel); return el ? el : null; };
            if (q('#fs-platform')) { f.platform = q('#fs-platform').value; }
            f.currency = q('#fs-currency').value;
            f.settings = Object.assign({}, s, {
              product_ids: q('#fs-products') ? q('#fs-products').value : (s.product_ids || ''),
              lead_value: q('#fs-value') ? q('#fs-value').value : (s.lead_value || 0),
              capi_enabled: q('#fs-capi').checked,
              capi_event: q('#fs-event').value,
              capi_pixel_id: q('#fs-pixel').value,
              notes: q('#fs-notes').value
            });
            setDirty(true);
            close();
            toast('Configurações aplicadas. Clique em "Salvar alterações".', 'info');
          }
        }
      ]
    });
  }

  /* =================================================================== CONVERSÕES */

  var CONV = { page: 1, status: '', type: '', platform: '', funnel: '', search: '', model: 'last' };

  function renderConversions() {
    var statusOpts = '<option value="">Todos os status</option>' + Object.keys(BOOT.statuses).map(function (k) { return '<option value="' + k + '"' + (CONV.status === k ? ' selected' : '') + '>' + esc(BOOT.statuses[k]) + '</option>'; }).join('');
    var typeOpts = '<option value="">Todos os tipos</option>' + Object.keys(BOOT.types).map(function (k) { return '<option value="' + k + '"' + (CONV.type === k ? ' selected' : '') + '>' + esc(BOOT.types[k]) + '</option>'; }).join('');
    var platOpts = '<option value="">Todas as plataformas</option>' + (BOOT.platforms || []).filter(function (p) { return !p.generic; }).map(function (p) { return '<option value="' + p.key + '"' + (CONV.platform === p.key ? ' selected' : '') + '>' + esc(p.label) + '</option>'; }).join('') + '<option value="generic"' + (CONV.platform === 'generic' ? ' selected' : '') + '>Webhook genérico</option>';
    app.innerHTML = header('Conversões', 'Vendas, leads e contatos com a origem de cada um.', periodPicker() +
      '<button type="button" class="iwt-btn iwt-btn--ghost" id="cv-export">' + icon('download') + 'Exportar CSV</button>') +
      '<div class="iwt-toolbar">' +
      '<select class="iwt-select" id="cv-status" aria-label="Status">' + statusOpts + '</select>' +
      '<select class="iwt-select" id="cv-type" aria-label="Tipo">' + typeOpts + '</select>' +
      '<select class="iwt-select" id="cv-platform" aria-label="Plataforma">' + platOpts + '</select>' +
      funnelSelect('cv-funnel', CONV.funnel) +
      '<select class="iwt-select" id="cv-model" aria-label="Modelo de atribuição">' + modelOptions(CONV.model) + '</select>' +
      '<input type="search" class="iwt-input" id="cv-search" placeholder="Buscar e-mail, nome, produto, transação" value="' + esc(CONV.search) + '">' +
      '</div>' +
      '<section class="iwt-card"><div class="iwt-card-body" id="cv-body"></div></section>';
    bindPeriod(app, function () { CONV.page = 1; loadConversions(); });
    ['status', 'type', 'platform', 'funnel', 'model'].forEach(function (k) {
      app.querySelector('#cv-' + k).addEventListener('change', function (e) { CONV[k] = e.target.value; CONV.page = 1; loadConversions(); });
    });
    var t;
    app.querySelector('#cv-search').addEventListener('input', function (e) {
      clearTimeout(t);
      t = setTimeout(function () { CONV.search = e.target.value; CONV.page = 1; loadConversions(); }, 350);
    });
    app.querySelector('#cv-export').addEventListener('click', exportConversions);
    app.querySelector('#cv-body').addEventListener('click', onConversionClick);
    loadConversions();
  }

  function modelOptions(v) {
    var m = { last: 'Atribuição: último clique', first: 'Atribuição: primeiro clique', paid: 'Atribuição: último clique pago' };
    return Object.keys(m).map(function (k) { return '<option value="' + k + '"' + (v === k ? ' selected' : '') + '>' + m[k] + '</option>'; }).join('');
  }

  function convParams(extra) {
    return Object.assign(rangeParams(), { page: CONV.page, status: CONV.status, type: CONV.type, platform: CONV.platform, funnel: CONV.funnel, search: CONV.search, model: CONV.model }, extra || {});
  }

  var CONV_ITEMS = [];

  function loadConversions() {
    var body = app.querySelector('#cv-body');
    loading(body);
    api('/admin/conversions', { params: convParams() }).then(function (r) {
      CONV_ITEMS = r.items;
      if (!r.items.length) {
        body.innerHTML = emptyState('Nenhuma conversão encontrada', 'Ajuste o período ou os filtros. Vendas chegam pelos webhooks configurados em Integrações.', '');
        return;
      }
      var pages = Math.ceil(r.total / r.per_page);
      body.innerHTML = '<div class="iwt-table-wrap"><table class="iwt-table"><thead><tr><th scope="col">Data</th><th scope="col">Tipo</th><th scope="col">Status</th><th scope="col" class="num">Valor</th><th scope="col">Produto / cliente</th><th scope="col">Funil</th><th scope="col">Origem</th><th scope="col"><span class="screen-reader-text">Detalhes</span></th></tr></thead><tbody>' +
        r.items.map(function (c, i) {
          var origin = c.channel_label ? esc(c.channel_label) + '<br><span class="iwt-muted">' + esc([c.source, c.campaign].filter(Boolean).join(' · ')) + '</span>' : '<span class="iwt-muted">não atribuída</span>';
          return '<tr><td>' + fmtDateTime(c.converted_at) + '</td><td>' + esc(BOOT.types[c.type] || c.type) + (c.platform ? '<br><span class="iwt-muted">' + esc(platformLabel(c.platform)) + '</span>' : '') + '</td>' +
            '<td>' + badge(BOOT.statuses[c.status] || c.status, STATUS_TONE[c.status]) + '</td><td class="num">' + (c.value ? fmtMoney(c.value, c.currency) : '—') + '</td>' +
            '<td class="iwt-ellipsis">' + esc(c.product_name || '—') + '<br><span class="iwt-muted">' + esc(c.customer_name || c.customer_email || '') + '</span></td>' +
            '<td>' + esc(c.funnel_name || '—') + '</td><td>' + origin + '</td>' +
            '<td><button type="button" class="iwt-btn iwt-btn--small iwt-btn--ghost" data-detail="' + i + '">Detalhes</button></td></tr>';
        }).join('') + '</tbody></table></div>' +
        '<div class="iwt-pager"><span>' + fmtInt(r.total) + ' conversões</span>' +
        '<button type="button" class="iwt-btn iwt-btn--small" data-page="' + (r.page - 1) + '"' + (r.page <= 1 ? ' disabled' : '') + '>Anterior</button>' +
        '<span>Página ' + r.page + ' de ' + pages + '</span>' +
        '<button type="button" class="iwt-btn iwt-btn--small" data-page="' + (r.page + 1) + '"' + (r.page >= pages ? ' disabled' : '') + '>Próxima</button></div>';
    }).catch(function (err) { body.innerHTML = errorBox(err); });
  }

  function onConversionClick(e) {
    var p = e.target.closest('[data-page]');
    if (p && !p.disabled) { CONV.page = parseInt(p.getAttribute('data-page'), 10); loadConversions(); return; }
    var d = e.target.closest('[data-detail]');
    if (d) { conversionDetail(CONV_ITEMS[parseInt(d.getAttribute('data-detail'), 10)]); }
  }

  var MATCH_TEXT = {
    hit: 'Pelo clique no link do checkout (o código voltou no webhook). Atribuição exata.',
    visitor: 'Pelo código do visitante (link de checkout marcado pelo script).',
    email: 'Pelo e-mail do comprador, já visto em outra conversão.',
    product: 'Pelo ID do produto configurado no funil (sem visitante identificado).',
    none: 'Sem atribuição: o webhook não trouxe o código de rastreio.'
  };

  function touchCard(title, t) {
    if (!t) { return '<div class="iwt-touch"><h4>' + esc(title) + '</h4><p class="iwt-muted">—</p></div>'; }
    return '<div class="iwt-touch"><h4>' + esc(title) + '</h4><p><strong>' + esc(t.channel) + '</strong></p><dl>' +
      [['Fonte', t.source], ['Mídia', t.medium], ['Campanha', t.campaign], ['Conteúdo', t.content], ['Termo', t.term], ['Entrada', t.landing], ['Click ID', t.click_id_type], ['Quando', fmtDateTime(t.started_at)]]
        .filter(function (x) { return x[1]; }).map(function (x) { return '<dt>' + esc(x[0]) + '</dt><dd>' + esc(x[1]) + '</dd>'; }).join('') + '</dl></div>';
  }

  function conversionDetail(c) {
    if (!c) { return; }
    var m = modal({ title: (BOOT.types[c.type] || c.type) + ' #' + c.id, wide: true, body: '<div class="iwt-loading"><span class="iwt-spinner"></span> Carregando…</div>', actions: BOOT.can_manage ? [
      { label: 'Excluir conversão', danger: true, onClick: function (close) {
        confirmDialog('Excluir conversão?', 'Use só para remover testes. Não dá para desfazer.', 'Excluir', true).then(function (ok) {
          if (!ok) { return; }
          api('/admin/conversions/' + c.id, { method: 'DELETE' }).then(function () { close(); toast('Conversão excluída.', 'success'); loadConversions(); });
        });
      } },
      { label: 'Fechar', primary: true }
    ] : [{ label: 'Fechar', primary: true }] });
    api('/admin/conversions/' + c.id).then(function (d) {
      var info = [['Status', BOOT.statuses[c.status] || c.status], ['Valor', c.value ? fmtMoney(c.value, c.currency) : '—'], ['Líquido', c.net_value ? fmtMoney(c.net_value, c.currency) : '—'],
        ['Produto', c.product_name], ['Plataforma', c.platform ? platformLabel(c.platform) : ''], ['Transação', c.transaction_id], ['Pagamento', paymentLabel(c.payment_method)],
        ['Cliente', c.customer_name], ['E-mail', c.customer_email], ['Telefone', c.customer_phone], ['Funil', c.funnel_name], ['Data', fmtDateTime(c.converted_at)]]
        .filter(function (x) { return x[1]; });
      var journey = d.journey.sessions.length ? '<ol class="iwt-timeline">' + d.journey.sessions.map(function (s) {
        return '<li><span class="iwt-timeline-date">' + fmtDateTime(s.started_at) + '</span> <strong>' + esc(s.channel) + '</strong> · ' + esc([s.source, s.campaign].filter(Boolean).join(' · ')) +
          (s.is_paid ? ' ' + badge('pago', 'accent') : '') + '<br><span class="iwt-muted">entrada: ' + esc(s.landing || '—') + ' · ' + plural(s.pageviews, 'página', 'páginas') + ' · ' + plural(s.clicks, 'clique', 'cliques') + '</span></li>';
      }).join('') + '</ol>' : '<p class="iwt-muted">Visitante não identificado.</p>';
      m.el.querySelector('.iwt-modal-body').innerHTML =
        '<dl class="iwt-dl">' + info.map(function (x) { return '<dt>' + esc(x[0]) + '</dt><dd>' + esc(x[1]) + '</dd>'; }).join('') + '</dl>' +
        '<p class="iwt-notice iwt-notice--info">' + icon('info') + '<span>' + esc(MATCH_TEXT[d.match_method] || '') + '</span></p>' +
        '<h3>Atribuição</h3><div class="iwt-touches">' + touchCard('Primeiro contato', d.attribution.first) + touchCard('Último clique', d.attribution.last) + touchCard('Última mídia paga', d.attribution.paid) + '</div>' +
        '<h3>Jornada do visitante</h3>' + journey;
    }).catch(function (err) { m.el.querySelector('.iwt-modal-body').innerHTML = errorBox(err); });
  }

  function exportConversions() {
    api('/admin/conversions', { params: convParams({ page: 1, per_page: 200 }) }).then(function (r) {
      csvDownload('conversoes-' + RANGE.from + '-a-' + RANGE.to + '.csv',
        ['Data', 'Tipo', 'Status', 'Valor', 'Moeda', 'Produto', 'Plataforma', 'Transação', 'Cliente', 'E-mail', 'Funil', 'Canal', 'Fonte', 'Mídia', 'Campanha', 'Conteúdo', 'Termo', 'Atribuição'],
        r.items.map(function (c) {
          return [fmtDateTime(c.converted_at), BOOT.types[c.type] || c.type, BOOT.statuses[c.status] || c.status, String(c.value).replace('.', ','), c.currency, c.product_name, c.platform, c.transaction_id,
            c.customer_name, c.customer_email, c.funnel_name, c.channel_label, c.source, c.medium, c.campaign, c.content, c.term, c.match_method];
        }));
      if (r.total > r.items.length) { toast('Exportadas as ' + r.items.length + ' mais recentes. Reduza o período para exportar o resto.', 'info'); }
    }).catch(function (err) { toast(err.message, 'error'); });
  }

  /* =================================================================== RELATÓRIOS */

  var REP = { dimension: lsGet('iwt_rep_dim', 'channel'), model: 'last', filters: {}, sort: 'visits', dir: -1, rows: [] };

  function renderReports() {
    var dimOpts = Object.keys(BOOT.dimensions).map(function (k) { return '<option value="' + k + '"' + (REP.dimension === k ? ' selected' : '') + '>' + esc(BOOT.dimensions[k]) + '</option>'; }).join('');
    app.innerHTML = header('Relatórios', 'Quebre visitas, conversões, receita e investimento por qualquer dimensão. Clique numa linha para filtrar.', periodPicker() +
      '<button type="button" class="iwt-btn iwt-btn--ghost" id="rp-export">' + icon('download') + 'Exportar CSV</button>') +
      '<div class="iwt-toolbar"><label class="iwt-inline-label">Agrupar por <select class="iwt-select" id="rp-dim">' + dimOpts + '</select></label>' +
      '<select class="iwt-select" id="rp-model" aria-label="Modelo de atribuição">' + modelOptions(REP.model) + '</select>' +
      funnelSelect('rp-funnel', REP.filters.funnel) + '</div>' +
      '<div id="rp-chips">' + filterChips(REP.filters, chipLabels()) + '</div>' +
      '<section class="iwt-card"><div class="iwt-card-body" id="rp-body"></div></section>' +
      '<p class="iwt-help">Visitas e visitantes contam pela data da visita; conversões e receita pela data da aprovação, atribuídas à visita escolhida no modelo de atribuição. Investimento soma o CPC dos links e os custos lançados.</p>';
    bindPeriod(app, loadReport);
    app.querySelector('#rp-dim').addEventListener('change', function (e) { REP.dimension = e.target.value; lsSet('iwt_rep_dim', REP.dimension); loadReport(); });
    app.querySelector('#rp-model').addEventListener('change', function (e) { REP.model = e.target.value; loadReport(); });
    app.querySelector('#rp-funnel').addEventListener('change', function (e) { if (e.target.value) { REP.filters.funnel = e.target.value; } else { delete REP.filters.funnel; } renderReports(); });
    app.querySelector('#rp-export').addEventListener('click', exportReport);
    app.querySelector('#rp-chips').addEventListener('click', function (e) {
      var un = e.target.closest('[data-unfilter]');
      if (!un) { return; }
      var k = un.getAttribute('data-unfilter');
      if (k === '*') { REP.filters = {}; } else { delete REP.filters[k]; }
      renderReports();
    });
    app.querySelector('#rp-body').addEventListener('click', onReportClick);
    loadReport();
  }

  var REPORT_COLS = [
    ['label', 'Item', 'text'], ['visits', 'Visitas', 'int'], ['visitors', 'Visitantes', 'int'], ['pageviews', 'Páginas', 'int'],
    ['conversions', 'Conversões', 'int'], ['conv_rate', 'Taxa', 'pct'], ['revenue', 'Receita', 'money'], ['pending', 'Pendentes', 'int'],
    ['cost', 'Investimento', 'money'], ['roas', 'ROAS', 'roas'], ['cpa', 'CPA', 'money']
  ];

  function fmtCol(type, v) {
    if (type === 'int') { return fmtInt(v); }
    if (type === 'pct') { return fmtPct(v, 2); }
    if (type === 'money') { return v ? fmtMoney(v) : '—'; }
    if (type === 'roas') { return fmtRoas(v); }
    return esc(v);
  }

  function loadReport() {
    var body = app.querySelector('#rp-body');
    loading(body);
    api('/admin/breakdown', { params: Object.assign(rangeParams(), { dimension: REP.dimension, model: REP.model, limit: 500 }, REP.filters) }).then(function (r) {
      REP.rows = r.rows;
      drawReport();
    }).catch(function (err) { body.innerHTML = errorBox(err); });
  }

  function drawReport() {
    var body = app.querySelector('#rp-body');
    var rows = REP.rows.slice();
    if (!rows.length) { body.innerHTML = emptyState('Sem dados no período', 'Tente um período maior ou remova filtros.', ''); return; }
    var timeDim = ['day', 'hour', 'weekday'].indexOf(REP.dimension) !== -1;
    if (!timeDim || REP.sort !== 'label') {
      rows.sort(function (a, b) {
        var x = a[REP.sort], y = b[REP.sort];
        if (REP.sort === 'label') { return String(x).localeCompare(String(y), 'pt-BR') * REP.dir; }
        return ((x == null ? -1 : x) - (y == null ? -1 : y)) * REP.dir;
      });
    }
    if (timeDim && REP.sort === 'visits' && REP.dir === -1) { rows = REP.rows.slice(); }
    var max = 0;
    var tot = { visits: 0, visitors: 0, pageviews: 0, conversions: 0, revenue: 0, pending: 0, cost: 0 };
    rows.forEach(function (r) {
      if (r.visits > max) { max = r.visits; }
      Object.keys(tot).forEach(function (k) { tot[k] += r[k] || 0; });
    });
    var filterKey = DIM_FILTER[REP.dimension] || (['medium', 'content', 'country'].indexOf(REP.dimension) !== -1 ? REP.dimension : null);
    body.innerHTML = '<div class="iwt-table-wrap"><table class="iwt-table iwt-table--report"><thead><tr>' + REPORT_COLS.map(function (c) {
      var active = REP.sort === c[0];
      return '<th scope="col" class="' + (c[2] !== 'text' ? 'num' : '') + '" aria-sort="' + (active ? (REP.dir === 1 ? 'ascending' : 'descending') : 'none') + '"><button type="button" class="iwt-sort" data-sort="' + c[0] + '">' + esc(c[0] === 'label' ? BOOT.dimensions[REP.dimension] : c[1]) + (active ? (REP.dir === 1 ? ' ↑' : ' ↓') : '') + '</button></th>';
    }).join('') + '</tr></thead><tbody>' + rows.map(function (r) {
      return '<tr>' + REPORT_COLS.map(function (c) {
        if (c[0] === 'label') {
          var label = esc(r.label);
          return '<td class="iwt-ellipsis">' + (filterKey && r.key !== null && r.key !== '' ? '<button type="button" class="iwt-link-btn" data-filter="' + filterKey + '" data-value="' + esc(r.key) + '">' + label + '</button>' : label) + '</td>';
        }
        if (c[0] === 'visits') { return '<td class="iwt-w-bar">' + barCell(r.visits, max, fmtInt(r.visits)) + '</td>'; }
        return '<td class="num">' + fmtCol(c[2], r[c[0]]) + '</td>';
      }).join('') + '</tr>';
    }).join('') + '</tbody><tfoot><tr><th scope="row">Total</th><td class="num">' + fmtInt(tot.visits) + '</td><td class="num" title="Soma por linha: um visitante pode aparecer em mais de uma linha">' + fmtInt(tot.visitors) + '*</td><td class="num">' + fmtInt(tot.pageviews) +
      '</td><td class="num">' + fmtInt(tot.conversions) + '</td><td></td><td class="num">' + fmtMoney(tot.revenue) + '</td><td class="num">' + fmtInt(tot.pending) + '</td><td class="num">' + fmtMoney(tot.cost) +
      '</td><td class="num">' + (tot.cost ? fmtRoas(tot.revenue / tot.cost) : '—') + '</td><td></td></tr></tfoot></table></div>' +
      '<p class="iwt-help iwt-pad">* Visitantes no total somam as linhas; o número real de visitantes únicos está na Visão geral.</p>';
  }

  function onReportClick(e) {
    var s = e.target.closest('[data-sort]');
    if (s) {
      var key = s.getAttribute('data-sort');
      if (REP.sort === key) { REP.dir = -REP.dir; } else { REP.sort = key; REP.dir = key === 'label' ? 1 : -1; }
      drawReport();
      return;
    }
    var f = e.target.closest('[data-filter]');
    if (f) {
      REP.filters[f.getAttribute('data-filter')] = f.getAttribute('data-value');
      renderReports();
    }
  }

  function exportReport() {
    csvDownload('relatorio-' + REP.dimension + '-' + RANGE.from + '-a-' + RANGE.to + '.csv',
      REPORT_COLS.map(function (c) { return c[0] === 'label' ? BOOT.dimensions[REP.dimension] : c[1]; }),
      REP.rows.map(function (r) {
        return REPORT_COLS.map(function (c) {
          var v = r[c[0]];
          return typeof v === 'number' ? String(v).replace('.', ',') : (v == null ? '' : v);
        });
      }));
  }

  /* =================================================================== CUSTOS */

  function renderCosts() {
    var manage = BOOT.can_manage;
    var channelOpts = '<option value="">—</option>' + Object.keys(BOOT.channels).map(function (k) { return '<option value="' + k + '">' + esc(BOOT.channels[k]) + '</option>'; }).join('');
    app.innerHTML = header('Custos', 'Lance o investimento em mídia para calcular ROAS, ROI e custo por conversão.', periodPicker()) +
      (manage ? '<section class="iwt-card"><div class="iwt-card-head"><h2>Lançar investimento</h2></div><form class="iwt-form iwt-form--grid" id="ct-form">' +
        field('De', '<input type="date" class="iwt-input" name="date" required value="' + esc(BOOT.today) + '">') +
        field('Até (opcional)', '<input type="date" class="iwt-input" name="until">', 'Com período, o valor é dividido igualmente entre os dias.') +
        field('Valor', '<input type="text" class="iwt-input" name="amount" required inputmode="decimal" placeholder="0,00">') +
        field('Funil', funnelSelect('ct-funnel', '', 'Sem funil (site todo)').replace('id="ct-funnel"', 'id="ct-funnel" name="funnel_id"')) +
        field('Fonte do funil', '<select class="iwt-select" name="node_id" id="ct-node"><option value="">—</option></select>') +
        field('Canal', '<select class="iwt-select" name="channel">' + channelOpts + '</select>') +
        field('Temperatura', '<select class="iwt-select" name="temperature"><option value="">—</option>' + ['cold', 'warm', 'hot', 'organic'].map(function (t) { return '<option value="' + t + '">' + esc(BOOT.temperatures[t]) + '</option>'; }).join('') + '</select>', 'Ex.: o valor gasto só nas campanhas de remarketing = Quente.') +
        field('Fonte (utm_source)', '<input type="text" class="iwt-input" name="source" placeholder="ex.: facebook">') +
        field('Campanha (utm_campaign)', '<input type="text" class="iwt-input" name="campaign">') +
        field('Observação', '<input type="text" class="iwt-input" name="note">') +
        '<div class="iwt-form-actions"><button type="submit" class="iwt-btn iwt-btn--primary">' + icon('plus') + 'Lançar</button></div>' +
        '</form><p class="iwt-help iwt-pad">Preencha os campos que identificam onde o dinheiro foi gasto: o investimento aparece nos relatórios por funil, fonte do funil, canal, temperatura, fonte e campanha. Para custo por clique fixo, configure o CPC na fonte de tráfego do funil.</p></section>' : '') +
      '<section class="iwt-card"><div class="iwt-card-head"><h2>Lançamentos do período</h2></div><div class="iwt-card-body" id="ct-body"></div></section>';
    bindPeriod(app, loadCosts);
    if (manage) {
      var form = app.querySelector('#ct-form');
      app.querySelector('#ct-funnel').addEventListener('change', function (e) {
        var sel = app.querySelector('#ct-node');
        sel.innerHTML = '<option value="">—</option>';
        if (!e.target.value) { return; }
        api('/admin/funnels/' + e.target.value).then(function (g) {
          sel.innerHTML = '<option value="">—</option>' + g.nodes.filter(function (n) { return n.type === 'source'; }).map(function (n) { return '<option value="' + n.id + '">' + esc(n.name) + '</option>'; }).join('');
        });
      });
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var data = {};
        new FormData(form).forEach(function (v, k) { data[k] = v; });
        api('/admin/costs', { method: 'POST', body: data }).then(function (r) {
          toast(r.days > 1 ? 'Investimento lançado em ' + r.days + ' dias.' : 'Investimento lançado.', 'success');
          form.querySelector('[name="amount"]').value = '';
          loadCosts();
        }).catch(function (err) { toast(err.message, 'error'); });
      });
    }
    app.querySelector('#ct-body').addEventListener('click', function (e) {
      var b = e.target.closest('[data-del]');
      if (!b) { return; }
      api('/admin/costs/' + b.getAttribute('data-del'), { method: 'DELETE' }).then(function () { toast('Lançamento removido.', 'success'); loadCosts(); });
    });
    loadCosts();
  }

  function loadCosts() {
    var body = app.querySelector('#ct-body');
    loading(body);
    api('/admin/costs', { params: rangeParams() }).then(function (r) {
      if (!r.items.length) { body.innerHTML = '<p class="iwt-muted iwt-pad">Nenhum lançamento no período.</p>'; return; }
      var total = r.items.reduce(function (s, c) { return s + c.amount; }, 0);
      body.innerHTML = '<div class="iwt-table-wrap"><table class="iwt-table iwt-table--compact"><thead><tr><th scope="col">Data</th><th scope="col">Funil</th><th scope="col">Fonte do funil</th><th scope="col">Canal</th><th scope="col">Temperatura</th><th scope="col">Fonte</th><th scope="col">Campanha</th><th scope="col" class="num">Valor</th><th scope="col">Obs.</th><th></th></tr></thead><tbody>' +
        r.items.map(function (c) {
          return '<tr><td>' + esc(ymdLabel(c.date)) + '</td><td>' + esc(c.funnel_name || '—') + '</td><td>' + esc(c.node_name || '—') + '</td><td>' + esc(BOOT.channels[c.channel] || '—') + '</td><td>' + esc(BOOT.temperatures[c.temperature] || '—') + '</td><td>' + esc(c.source || '—') + '</td><td>' + esc(c.campaign || '—') +
            '</td><td class="num">' + fmtMoney(c.amount) + '</td><td>' + esc(c.note) + '</td><td>' + (BOOT.can_manage ? '<button type="button" class="iwt-icon-btn" data-del="' + c.id + '" aria-label="Remover lançamento">' + icon('trash') + '</button>' : '') + '</td></tr>';
        }).join('') + '</tbody><tfoot><tr><th scope="row" colspan="7">Total</th><td class="num">' + fmtMoney(total) + '</td><td colspan="2"></td></tr></tfoot></table></div>';
    }).catch(function (err) { body.innerHTML = errorBox(err); });
  }

  /* =================================================================== INTEGRAÇÕES */

  var SETTINGS = null;

  function renderIntegrations() {
    loading();
    api('/admin/settings').then(function (r) {
      SETTINGS = r.settings;
      var s = SETTINGS;
      var platformOpts = (BOOT.platforms || []).filter(function (p) { return !p.internal; }).map(function (p) {
        return '<option value="' + p.key + '">' + esc(p.label) + (p.beta ? ' (beta)' : '') + '</option>';
      }).join('');
      app.innerHTML = header('Integrações', 'Receba vendas dos checkouts e envie conversões para o Meta.', '') +
        '<section class="iwt-card"><div class="iwt-card-head"><h2>Webhooks de checkout</h2></div><div class="iwt-card-body iwt-pad">' +
        '<p>Cadastre a URL abaixo no painel da plataforma de pagamento. A venda volta com o código de rastreio que o plugin colocou no link do checkout e é atribuída à origem do visitante.</p>' +
        '<div class="iwt-form iwt-form--narrow">' + field('Plataforma', '<select class="iwt-select" id="ig-platform">' + platformOpts + '</select>') + '</div>' +
        '<div id="ig-platform-detail"></div>' +
        '<p class="iwt-help">Todas as URLs levam a chave secreta do site. <button type="button" class="iwt-link-btn" id="ig-regen">Gerar nova chave</button> (as URLs antigas param de funcionar).</p>' +
        '</div></section>' +
        '<section class="iwt-card"><div class="iwt-card-head"><h2>WooCommerce</h2>' + (BOOT.woocommerce ? badge('Instalado', 'good') : badge('Não instalado', 'neutral')) + '</div><div class="iwt-card-body iwt-pad">' +
        '<label class="iwt-check"><input type="checkbox" id="ig-woo"' + (s.woocommerce_enabled ? ' checked' : '') + '> Registrar pedidos do WooCommerce deste site como conversões (pago = aprovado, aguardando = pendente, reembolsado/cancelado atualizam o status)</label></div></section>' +
        '<section class="iwt-card"><div class="iwt-card-head"><h2>Meta — API de Conversões</h2>' + (BOOT.capi_configured ? badge('Ativa', 'good') : badge('Inativa', 'neutral')) + '</div><form class="iwt-card-body iwt-pad iwt-form iwt-form--narrow" id="ig-meta">' +
        '<label class="iwt-check"><input type="checkbox" name="meta_enabled"' + (s.meta_enabled ? ' checked' : '') + '> Enviar conversões para o Meta</label>' +
        field('ID do pixel (conjunto de dados)', '<input type="text" class="iwt-input" name="meta_pixel_id" inputmode="numeric" value="' + esc(s.meta_pixel_id) + '">') +
        field('Token de acesso', '<input type="password" class="iwt-input" name="meta_token" autocomplete="off" placeholder="' + (s.meta_token_set ? '•••••••• (salvo — preencha só para trocar)' : 'Gerenciador de Eventos → Configurações → Gerar token') + '">') +
        field('Código de evento de teste (opcional)', '<input type="text" class="iwt-input" name="meta_test_code" value="' + esc(s.meta_test_code) + '" placeholder="TEST12345">', 'Com o código preenchido os eventos aparecem em "Testar eventos" e NÃO contam nas campanhas. Apague depois de testar.') +
        '<label class="iwt-check"><input type="checkbox" name="meta_send_initiate_checkout"' + (s.meta_send_initiate_checkout ? ' checked' : '') + '> Enviar InitiateCheckout quando o visitante clicar no checkout de um funil</label>' +
        field('Versão da Graph API', '<input type="text" class="iwt-input iwt-input--short" name="meta_api_version" value="' + esc(s.meta_api_version) + '">') +
        '<div class="iwt-form-actions"><button type="submit" class="iwt-btn iwt-btn--primary">Salvar</button><button type="button" class="iwt-btn" id="ig-meta-test">Enviar evento de teste</button></div>' +
        '<p class="iwt-help">Os eventos usam event_id <code>iwt-c{id}</code>: se o pixel do navegador mandar o mesmo evento com esse ID, o Meta deduplica. E-mail, telefone e nome vão criptografados (SHA-256).</p>' +
        '</form></section>' +
        '<section class="iwt-card"><div class="iwt-card-head"><h2>Fila de envio ao Meta</h2><button type="button" class="iwt-link-btn" data-reload="outbox">Atualizar</button></div><div class="iwt-card-body" id="ig-outbox"></div></section>' +
        '<section class="iwt-card"><div class="iwt-card-head"><h2>Log de webhooks recebidos</h2><button type="button" class="iwt-link-btn" data-reload="logs">Atualizar</button></div><div class="iwt-card-body" id="ig-logs"></div></section>';
      bindIntegrations();
    }).catch(function (err) { app.innerHTML = errorBox(err); });
  }

  function bindIntegrations() {
    var sel = app.querySelector('#ig-platform');
    var drawPlatform = function () {
      var key = sel.value;
      var p = (BOOT.platforms || []).filter(function (x) { return x.key === key; })[0];
      var url = BOOT.webhook_urls[key];
      var html = '<div class="iwt-field"><span>URL do webhook</span><div class="iwt-copyrow"><code>' + esc(url) + '</code><button type="button" class="iwt-icon-btn" data-copy="' + esc(url) + '" aria-label="Copiar URL">' + icon('copy') + '</button></div></div>';
      if (p && p.help) { html += '<p class="iwt-help">' + esc(p.help) + '</p>'; }
      if (p && p.params && p.params.length) { html += '<p class="iwt-help">Código de rastreio no link do checkout: <code>' + esc(p.params.join(', ')) + '</code>' + (p.beta ? ' · preset beta — confira o primeiro webhook no log abaixo.' : '') + '</p>'; }
      if (key === 'hotmart') {
        html += '<form class="iwt-form iwt-form--narrow" data-secret-form>' + field('Hottok de verificação (recomendado)', '<input type="password" class="iwt-input" name="hotmart_hottok" autocomplete="off" placeholder="' + (SETTINGS.hotmart_hottok_set ? '•••••••• (salvo)' : 'cole o hottok') + '">', 'Com o hottok salvo, webhooks sem o cabeçalho correto são recusados.') + '<div class="iwt-form-actions"><button class="iwt-btn" type="submit">Salvar hottok</button></div></form>';
      }
      if (key === 'kiwify') {
        html += '<form class="iwt-form iwt-form--narrow" data-secret-form>' + field('Token do webhook (recomendado)', '<input type="password" class="iwt-input" name="kiwify_token" autocomplete="off" placeholder="' + (SETTINGS.kiwify_token_set ? '•••••••• (salvo)' : 'cole o token') + '">', 'Com o token salvo, a assinatura de cada webhook é conferida.') + '<div class="iwt-form-actions"><button class="iwt-btn" type="submit">Salvar token</button></div></form>';
      }
      if (key === 'generic') {
        api('/admin/settings').then(function (r) {
          var map = r.settings.generic_mapping || {};
          var fields = r.generic_fields;
          var box = app.querySelector('#ig-generic');
          if (!box) { return; }
          box.innerHTML = '<form class="iwt-form iwt-form--grid" id="ig-generic-form">' + Object.keys(fields).map(function (k) {
            return field(fields[k], '<input type="text" class="iwt-input" name="' + k + '" value="' + esc(map[k] || '') + '">');
          }).join('') + '<div class="iwt-form-actions"><button class="iwt-btn iwt-btn--primary" type="submit">Salvar mapeamento</button></div></form>' +
            '<p class="iwt-help">Caminhos com ponto: <code>data.buyer.email</code>; listas: <code>items[0].name</code>; filtro: <code>commissions[source=PRODUCER].value</code>; concatenar: <code>ddd+phone</code>. Se o código de rastreio não for encontrado no caminho, o plugin procura em todo o payload.</p>';
          box.querySelector('#ig-generic-form').addEventListener('submit', function (e) {
            e.preventDefault();
            var data = {};
            new FormData(e.target).forEach(function (v, k) { data[k] = v; });
            saveSettings({ generic_mapping: data }).then(function () { toast('Mapeamento salvo.', 'success'); });
          });
        });
        html += '<div id="ig-generic"></div>';
      }
      var detail = app.querySelector('#ig-platform-detail');
      detail.innerHTML = html;
      detail.querySelectorAll('[data-copy]').forEach(function (b) { b.addEventListener('click', function () { copy(b.getAttribute('data-copy'), 'URL copiada'); }); });
      var sf = detail.querySelector('[data-secret-form]');
      if (sf) {
        sf.addEventListener('submit', function (e) {
          e.preventDefault();
          var data = {};
          new FormData(sf).forEach(function (v, k) { if (v) { data[k] = v; } });
          if (!Object.keys(data).length) { toast('Preencha o campo para salvar.', 'error'); return; }
          saveSettings(data).then(function (s) { SETTINGS = s; toast('Salvo.', 'success'); drawPlatform(); });
        });
      }
    };
    sel.addEventListener('change', drawPlatform);
    drawPlatform();

    app.querySelector('#ig-regen').addEventListener('click', function () {
      confirmDialog('Gerar nova chave?', 'Todas as URLs de webhook mudam. Você vai precisar atualizar a URL em cada plataforma de pagamento.', 'Gerar nova chave', true).then(function (ok) {
        if (!ok) { return; }
        api('/admin/settings/webhook-key', { method: 'POST' }).then(function () {
          return api('/admin/bootstrap');
        }).then(function (b) { BOOT = b; toast('Nova chave gerada.', 'success'); drawPlatform(); });
      });
    });
    app.querySelector('#ig-woo').addEventListener('change', function (e) {
      saveSettings({ woocommerce_enabled: e.target.checked }).then(function () { toast('Salvo.', 'success'); });
    });
    var metaForm = app.querySelector('#ig-meta');
    metaForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var data = {
        meta_enabled: metaForm.querySelector('[name="meta_enabled"]').checked,
        meta_send_initiate_checkout: metaForm.querySelector('[name="meta_send_initiate_checkout"]').checked,
        meta_pixel_id: metaForm.querySelector('[name="meta_pixel_id"]').value,
        meta_test_code: metaForm.querySelector('[name="meta_test_code"]').value,
        meta_api_version: metaForm.querySelector('[name="meta_api_version"]').value
      };
      var token = metaForm.querySelector('[name="meta_token"]').value;
      if (token) { data.meta_token = token; }
      saveSettings(data).then(function (s) {
        SETTINGS = s;
        BOOT.capi_configured = s.meta_enabled && !!s.meta_pixel_id && s.meta_token_set;
        metaForm.querySelector('[name="meta_token"]').value = '';
        toast('Configurações do Meta salvas.', 'success');
      });
    });
    app.querySelector('#ig-meta-test').addEventListener('click', function (e) {
      var btn = e.currentTarget;
      btn.disabled = true;
      api('/admin/meta/test', { method: 'POST' }).then(function (r) {
        btn.disabled = false;
        if (r.ok) { toast(r.test_code_used ? 'Evento de teste recebido pelo Meta. Confira em "Testar eventos".' : 'Evento recebido pelo Meta (sem código de teste: conta como evento real).', 'success'); }
        else { toast(r.local ? r.error : 'Meta recusou: ' + r.error, 'error'); }
      }).catch(function (err) { btn.disabled = false; toast(err.message, 'error'); });
    });
    app.addEventListener('click', function (e) {
      var r = e.target.closest('[data-reload]');
      if (r) { if (r.getAttribute('data-reload') === 'outbox') { loadOutbox(); } else { loadLogs(); } }
      var retry = e.target.closest('[data-retry]');
      if (retry) {
        api('/admin/outbox/' + retry.getAttribute('data-retry') + '/retry', { method: 'POST' }).then(function (res) {
          toast(res.ok ? 'Reenviado com sucesso.' : 'Falhou de novo: ' + res.error, res.ok ? 'success' : 'error');
          loadOutbox();
        });
      }
      var pl = e.target.closest('[data-payload]');
      if (pl) {
        api('/admin/webhook-logs/' + pl.getAttribute('data-payload')).then(function (res) {
          var text = typeof res.payload === 'string' ? res.payload : JSON.stringify(res.payload, null, 2);
          modal({ title: 'Payload recebido #' + res.id, wide: true, body: '<pre class="iwt-pre">' + esc(text) + '</pre>', actions: [{ label: 'Copiar', onClick: function () { copy(text); } }, { label: 'Fechar', primary: true }] });
        });
      }
    });
    loadOutbox();
    loadLogs();
  }

  function saveSettings(patch) {
    return api('/admin/settings', { method: 'POST', body: patch }).then(function (r) { return r.settings; }).catch(function (err) { toast(err.message, 'error'); throw err; });
  }

  function loadOutbox() {
    var box = app.querySelector('#ig-outbox');
    loading(box);
    api('/admin/outbox').then(function (r) {
      if (!r.items.length) { box.innerHTML = '<p class="iwt-muted iwt-pad">Nenhum evento enviado ainda.</p>'; return; }
      var tone = { sent: 'good', pending: 'warn', retry: 'warn', failed: 'bad' };
      var label = { sent: 'Enviado', pending: 'Na fila', retry: 'Tentando de novo', failed: 'Falhou' };
      box.innerHTML = '<div class="iwt-table-wrap"><table class="iwt-table iwt-table--compact"><thead><tr><th scope="col">Data</th><th scope="col">Evento</th><th scope="col">Conversão</th><th scope="col">Status</th><th scope="col">Tentativas</th><th scope="col">Erro</th><th></th></tr></thead><tbody>' +
        r.items.map(function (o) {
          return '<tr><td>' + fmtDateTime(o.created_at) + '</td><td>' + esc(o.event_name) + '<br><span class="iwt-muted">' + esc(o.event_id) + '</span></td><td>' + (o.conversion_id ? '#' + o.conversion_id : '—') +
            '</td><td>' + badge(label[o.status] || o.status, tone[o.status]) + '</td><td>' + o.attempts + '</td><td class="iwt-ellipsis" title="' + esc(o.last_error) + '">' + esc(o.last_error || '') +
            '</td><td>' + (o.status !== 'sent' ? '<button type="button" class="iwt-btn iwt-btn--small" data-retry="' + o.id + '">Reenviar</button>' : '') + '</td></tr>';
        }).join('') + '</tbody></table></div>';
    }).catch(function (err) { box.innerHTML = errorBox(err); });
  }

  function loadLogs() {
    var box = app.querySelector('#ig-logs');
    loading(box);
    api('/admin/webhook-logs').then(function (r) {
      if (!r.items.length) { box.innerHTML = '<p class="iwt-muted iwt-pad">Nenhum webhook recebido ainda.</p>'; return; }
      var tone = { ok: 'good', ignored: 'neutral', unauthorized: 'bad', error: 'bad' };
      var label = { ok: 'Processado', ignored: 'Ignorado', unauthorized: 'Recusado', error: 'Erro' };
      box.innerHTML = '<div class="iwt-table-wrap"><table class="iwt-table iwt-table--compact"><thead><tr><th scope="col">Data</th><th scope="col">Plataforma</th><th scope="col">Status</th><th scope="col">Resultado</th><th></th></tr></thead><tbody>' +
        r.items.map(function (l) {
          return '<tr><td>' + fmtDateTime(l.created_at) + '</td><td>' + esc(platformLabel(l.platform)) + '</td><td>' + badge(label[l.status] || l.status, tone[l.status]) + '</td><td>' + esc(l.message) +
            '</td><td><button type="button" class="iwt-btn iwt-btn--small iwt-btn--ghost" data-payload="' + l.id + '">Ver payload</button></td></tr>';
        }).join('') + '</tbody></table></div>';
    }).catch(function (err) { box.innerHTML = errorBox(err); });
  }

  /* =================================================================== CONFIGURAÇÕES */

  function renderSettings() {
    loading();
    api('/admin/settings').then(function (r) {
      var s = r.settings;
      var roles = r.roles;
      var chk = function (k, label, help) {
        return '<label class="iwt-check"><input type="checkbox" name="' + k + '"' + (s[k] ? ' checked' : '') + '> ' + esc(label) + '</label>' + (help ? '<small class="iwt-help iwt-help--indent">' + help + '</small>' : '');
      };
      var num = function (k, label, help) { return field(label, '<input type="number" class="iwt-input iwt-input--short" name="' + k + '" value="' + esc(s[k]) + '">', help); };
      app.innerHTML = header('Configurações', 'Comportamento do rastreamento, links, retenção de dados e acesso.', '') +
        '<form id="st-form">' +
        '<section class="iwt-card"><div class="iwt-card-head"><h2>Script de rastreamento</h2></div><div class="iwt-card-body iwt-pad iwt-form">' +
        chk('tracker_enabled', 'Rastrear visitas em todas as páginas do site', 'Necessário para "Visitas", "Fontes" e páginas de obrigado. Os links dos funis funcionam mesmo sem o script.') +
        chk('track_logged_admins', 'Contar também visitas de usuários logados que editam o site') +
        chk('track_whatsapp', 'Registrar cliques em links de WhatsApp') +
        chk('track_phone_email', 'Registrar cliques em telefone (tel:) e e-mail (mailto:)') +
        chk('decorate_checkouts', 'Marcar links de checkout (Hotmart, Kiwify, Eduzz…) com o código do visitante', 'Assim vendas de quem chegou pelo site — mesmo sem passar por um funil — voltam atribuídas.') +
        field('Consentimento (LGPD)', '<select class="iwt-select" name="consent_mode"><option value="off"' + (s.consent_mode !== 'required' ? ' selected' : '') + '>Rastrear sempre (interesse legítimo, dados próprios)</option><option value="required"' + (s.consent_mode === 'required' ? ' selected' : '') + '>Só depois do consentimento do banner de cookies</option></select>',
          'No modo consentimento o script espera CookieYes, Complianz, Cookiebot ou GDPR Cookie Compliance, ou uma chamada a <code>iwtTracking.consent()</code>.') +
        num('session_minutes', 'Fim da visita após inatividade (minutos)') +
        num('cookie_days', 'Duração do cookie do visitante (dias)') +
        field('IPs ignorados', '<textarea class="iwt-input" name="excluded_ips" rows="2" placeholder="Um por linha. Prefixo termina com ponto: 189.10.">' + esc(s.excluded_ips) + '</textarea>', 'Use para não contar o escritório da equipe.') +
        field('Outros domínios de checkout', '<textarea class="iwt-input" name="extra_checkout_domains" rows="2" placeholder="checkout.minhaloja.com=src">' + esc(s.extra_checkout_domains) + '</textarea>', 'Um por linha, no formato dominio=parametro.') +
        '</div></section>' +
        '<section class="iwt-card"><div class="iwt-card-head"><h2>Links e redirecionamento</h2></div><div class="iwt-card-body iwt-pad iwt-form">' +
        field('Prefixo dos links', '<input type="text" class="iwt-input iwt-input--short" name="route_prefix" value="' + esc(s.route_prefix) + '">', 'Links ficam como ' + esc(BOOT.link_base.replace(/[^/]+\/$/, '')) + '<strong>' + esc(s.route_prefix) + '</strong>/123. Mudar o prefixo quebra links já divulgados.') +
        field('Tipo de redirecionamento', '<select class="iwt-select" name="redirect_code">' + [302, 303, 307, 301].map(function (c) { return '<option value="' + c + '"' + (+s.redirect_code === c ? ' selected' : '') + '>' + c + (c === 302 ? ' (recomendado)' : (c === 301 ? ' (permanente — navegador guarda em cache, não recomendado)' : '')) + '</option>'; }).join('') + '</select>') +
        field('Destino se o link não existir', '<input type="url" class="iwt-input" name="fallback_url" value="' + esc(s.fallback_url) + '" placeholder="Em branco: página inicial">') +
        chk('pass_vid', 'Passar o ID do visitante (iwt_vid) quando o destino é outro domínio', 'Permite continuar o rastreamento em landing pages fora deste WordPress que tenham o script.') +
        '</div></section>' +
        '<section class="iwt-card"><div class="iwt-card-head"><h2>Temperatura do tráfego</h2></div><div class="iwt-card-body iwt-pad iwt-form">' +
        '<p class="iwt-help">Quando a fonte do funil está em "Automática" (e para visitas que chegam direto ao site), o plugin procura estas palavras no nome da <strong>campanha</strong> e do <strong>conjunto/público</strong> (utm_campaign e utm_term). Se a temperatura estiver escrita (frio, morno, quente), ela vence. Sem palavra encontrada: "Orgânico" se não é pago, "Pago sem temperatura" se é.</p>' +
        field('Frio (público novo)', '<textarea class="iwt-input" name="temp_cold_words" rows="2">' + esc(s.temp_cold_words) + '</textarea>') +
        field('Morno (já interagiu)', '<textarea class="iwt-input" name="temp_warm_words" rows="2">' + esc(s.temp_warm_words) + '</textarea>') +
        field('Quente (remarketing, base, clientes)', '<textarea class="iwt-input" name="temp_hot_words" rows="2">' + esc(s.temp_hot_words) + '</textarea>', 'Palavras separadas por vírgula, sem acento. Vale para as visitas novas; as antigas mantêm a temperatura que tinham.') +
        '</div></section>' +
        '<section class="iwt-card"><div class="iwt-card-head"><h2>Conversões</h2></div><div class="iwt-card-body iwt-pad iwt-form">' +
        field('Moeda padrão', '<select class="iwt-select iwt-input--short" name="currency">' + ['BRL', 'USD', 'EUR'].map(function (c) { return '<option' + (s.currency === c ? ' selected' : '') + '>' + c + '</option>'; }).join('') + '</select>') +
        chk('unique_lead_per_visitor', 'Contar no máximo 1 conversão de obrigado/WhatsApp por visitante em cada funil') +
        chk('store_customer_pii', 'Guardar nome, e-mail e telefone do comprador (aparecem na tela de Conversões)', 'Desmarcado, guarda só o hash usado para atribuição e para o Meta.') +
        '</div></section>' +
        '<section class="iwt-card"><div class="iwt-card-head"><h2>Retenção de dados</h2></div><div class="iwt-card-body iwt-pad iwt-form">' +
        num('retention_hits_days', 'Apagar cliques e páginas vistas após (dias)') +
        num('retention_sessions_days', 'Apagar visitas após (dias)', 'Visitas ligadas a conversões são preservadas.') +
        num('ip_retention_days', 'Apagar o IP do visitante após (dias)', 'O IP só é usado para o Meta CAPI. 0 = não guardar.') +
        chk('delete_on_uninstall', 'Apagar todos os dados ao excluir o plugin') +
        '</div></section>' +
        '<section class="iwt-card"><div class="iwt-card-head"><h2>Acesso</h2></div><div class="iwt-card-body iwt-pad iwt-form">' +
        '<fieldset class="iwt-field"><legend>Quem pode ver os relatórios</legend>' + Object.keys(roles).map(function (k) {
          return '<label class="iwt-check"><input type="checkbox" name="view_roles" value="' + esc(k) + '"' + ((s.view_roles || []).indexOf(k) !== -1 ? ' checked' : '') + (k === 'administrator' ? ' disabled checked' : '') + '> ' + esc(roles[k]) + '</label>';
        }).join('') + '<small class="iwt-help">Só administradores criam funis e mexem em integrações e configurações.</small></fieldset>' +
        '<div class="iwt-field"><span>Token da API de leitura</span><p class="iwt-help">Para painéis externos, planilhas ou agentes de IA lerem os relatórios (somente leitura, sem dados pessoais). ' + (s.api_token_hint ? 'Token atual: <code>' + esc(s.api_token_hint) + '</code>' : 'Nenhum token gerado.') + '</p>' +
        '<button type="button" class="iwt-btn" id="st-token">' + (s.api_token_hint ? 'Gerar novo token' : 'Gerar token') + '</button></div>' +
        '</div></section>' +
        '<section class="iwt-card"><div class="iwt-card-head"><h2>Aparência do painel</h2></div><div class="iwt-card-body iwt-pad iwt-form">' +
        field('Tema', '<select class="iwt-select iwt-select--fit" id="st-theme">' + [['light', 'Claro'], ['dark', 'Noturno'], ['auto', 'Automático (segue o sistema)']].map(function (o) { return '<option value="' + o[0] + '"' + (THEME === o[0] ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select>',
          'Vale só para o seu usuário e é salvo na hora. Atalho: o botão da lua no topo de cada tela.') +
        '</div></section>' +
        '<div class="iwt-savebar"><button type="submit" class="iwt-btn iwt-btn--primary">Salvar configurações</button></div>' +
        '</form>';
      var form = app.querySelector('#st-form');
      app.querySelector('#st-theme').addEventListener('change', function (e) { setTheme(e.target.value).then(function () { toast('Tema salvo.', 'success'); }); });
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var data = { view_roles: [] };
        form.querySelectorAll('input, select, textarea').forEach(function (el) {
          if (!el.name || el.disabled) { return; }
          if (el.name === 'view_roles') { if (el.checked) { data.view_roles.push(el.value); } return; }
          data[el.name] = el.type === 'checkbox' ? el.checked : el.value;
        });
        saveSettings(data).then(function () { toast('Configurações salvas.', 'success'); });
      });
      app.querySelector('#st-token').addEventListener('click', function () {
        confirmDialog('Gerar token da API?', 'Se já existir um token, ele deixa de funcionar.', 'Gerar').then(function (ok) {
          if (!ok) { return; }
          api('/admin/settings/api-token', { method: 'POST' }).then(function (r2) {
            modal({ title: 'Token gerado', body: '<p>Copie agora: ele <strong>não</strong> será mostrado de novo.</p><div class="iwt-copyrow"><code>' + esc(r2.token) + '</code></div>' +
              '<p class="iwt-help">Uso: <code>Authorization: Bearer ' + esc(r2.token.slice(0, 10)) + '…</code> em ' + esc(CFG.api) + '/api/overview, /api/breakdown, /api/funnels, /api/conversions</p>',
              actions: [{ label: 'Copiar token', primary: true, onClick: function (close) { copy(r2.token, 'Token copiado'); close(); renderSettings(); } }] });
          });
        });
      });
    }).catch(function (err) { app.innerHTML = errorBox(err); });
  }

  /* =================================================================== AJUDA */

  function updateCheck(d) {
    var u = d.update_check || {};
    var when = u.at ? fmtDateTime(new Date(u.at * 1000).toISOString()) : '';
    if (u.at && u.error) {
      return [false, 'Atualizações', 'A última consulta (' + when + ') falhou: ' + u.error + '. O WordPress tenta de novo sozinho; o link "Verificar atualizações" em Plugins força agora.'];
    }
    var text = u.at ? 'Última consulta: ' + when + ' · versão publicada: ' + (u.version || '?') + (u.version && u.version !== d.version ? ' (há atualização em Plugins)' : ' (este site está em dia)') + '.'
      : 'Ainda não consultado. O WordPress procura novas versões a cada 12 h; o link "Verificar atualizações" em Plugins força agora.';
    return [true, 'Atualizações', text];
  }

  function renderHelp() {
    var manualUrl = 'https://raw.githubusercontent.com/equipe-ux/inovaweb-tracking-dist/main/Manual-INOVAWEB-Tracking.pdf';
    app.innerHTML = header('Ajuda e diagnóstico', 'Como o plugin funciona e se está tudo certo neste site.',
      '<a class="iwt-btn iwt-btn--primary" href="' + manualUrl + '" target="_blank" rel="noopener">' + icon('download') + 'Baixar o manual (PDF)</a>') +
      '<section class="iwt-card"><div class="iwt-card-head"><h2>Diagnóstico</h2></div><div class="iwt-card-body" id="hp-diag"></div></section>' +
      '<section class="iwt-card"><div class="iwt-card-head"><h2>Como funciona</h2></div><div class="iwt-card-body iwt-pad iwt-prose">' +
      '<ol><li><strong>Visitas e fontes:</strong> o script do plugin roda em todas as páginas do site e registra cada visita com a origem (UTMs, Google, Instagram, anúncios, direto…).</li>' +
      '<li><strong>Funis:</strong> em Funis você desenha o caminho (fonte → página → checkout/obrigado/WhatsApp). Cada conexão vira um link <code>' + esc(BOOT.link_base) + '123</code>. O link da fonte vai no anúncio; o link que sai de uma página vai no botão dela.</li>' +
      '<li><strong>Conversões:</strong> o objetivo do funil define o que conta — venda (pelo webhook do checkout), chegada na página de obrigado ou clique no WhatsApp.</li>' +
      '<li><strong>Atribuição:</strong> cada conversão guarda o primeiro contato, o último clique e a última mídia paga do visitante. Os relatórios deixam escolher o modelo.</li></ol>' +
      '<h3>Variáveis nas URLs do funil</h3><table class="iwt-table iwt-table--compact"><tbody>' +
      [['{utm_source}, {utm_campaign}…', 'qualquer parâmetro que chegou no link'], ['{iwt_vid}', 'ID do visitante'], ['{iwt_token}', 'código de rastreio (o mesmo que vai para o checkout)'], ['{iwt_click}', 'código do clique']]
        .map(function (r) { return '<tr><td><code>' + esc(r[0]) + '</code></td><td>' + esc(r[1]) + '</td></tr>'; }).join('') + '</tbody></table>' +
      '<h3>Testar um funil sem sujar os números</h3><p>Acrescente <code>?iwt_test=1</code> ao link: o redirecionamento acontece normalmente, mas nada é registrado.</p>' +
      '</div></section>' +
      '<section class="iwt-card"><div class="iwt-card-head"><h2>Landing page fora deste WordPress</h2></div><div class="iwt-card-body iwt-pad">' +
      '<p>Cole este código antes do <code>&lt;/body&gt;</code> da página externa para registrar visitas, cliques em WhatsApp e marcar os links de checkout:</p>' +
      '<div class="iwt-copyrow iwt-copyrow--block"><pre class="iwt-pre">' + esc(BOOT.snippet) + '</pre><button type="button" class="iwt-icon-btn" id="hp-snippet" aria-label="Copiar código">' + icon('copy') + '</button></div>' +
      '</div></section>';
    app.querySelector('#hp-snippet').addEventListener('click', function () { copy(BOOT.snippet, 'Código copiado'); });
    var box = app.querySelector('#hp-diag');
    if (!BOOT.can_manage) { box.innerHTML = '<p class="iwt-muted iwt-pad">Diagnóstico disponível para administradores.</p>'; return; }
    loading(box);
    api('/admin/diagnostics').then(function (d) {
      var checks = [
        [!d.missing_tables.length, 'Tabelas do banco', d.missing_tables.length ? 'Faltando: ' + d.missing_tables.join(', ') + '. Desative e ative o plugin.' : 'Todas as 10 tabelas existem (versão ' + d.db_version + ').'],
        [d.permalinks, 'Links permanentes', d.permalinks ? 'Ativos: links no formato ' + d.link_example : 'Desligados: os links usam ' + d.link_example + ' (funciona, mas é menos bonito). Ative em Configurações → Links permanentes.'],
        [!d.cron_disabled, 'Tarefas agendadas', d.cron_disabled ? 'DISABLE_WP_CRON está ligado: garanta um cron do servidor chamando wp-cron.php.' : 'WP-Cron ativo. Próxima execução: ' + fmtDateTime(d.cron_next)],
        [!!d.last_pageview, 'Script de rastreamento', d.last_pageview ? 'Última visita registrada: ' + fmtDateTime(d.last_pageview) : 'Nenhuma visita registrada ainda (visitas de administradores logados não contam).'],
        [d.https, 'HTTPS', d.https ? 'Site em HTTPS.' : 'Sem HTTPS: navegadores podem descartar o cookie do visitante.'],
        [true, 'Plugins de cache', d.cache_plugins.length ? d.cache_plugins.join(', ') + ' detectado. Os links de funil já pedem para não ser guardados em cache; se algum link redirecionar errado, exclua ' + BOOT.link_base + '* do cache.' : 'Nenhum detectado.'],
        [true, 'Webhooks', d.last_webhook ? 'Último recebido: ' + fmtDateTime(d.last_webhook) : 'Nenhum recebido ainda.'],
        [true, 'Meta CAPI', d.capi ? 'Configurada.' : 'Não configurada (opcional).'],
        [true, 'Ambiente', 'PHP ' + d.php + ' · WordPress ' + d.wp + ' · fuso ' + d.tz + ' · plugin ' + d.version],
        updateCheck(d)
      ];
      box.innerHTML = '<ul class="iwt-checks">' + checks.map(function (c) {
        return '<li class="' + (c[0] ? 'is-ok' : 'is-bad') + '">' + icon(c[0] ? 'check' : 'alert') + '<div><strong>' + esc(c[1]) + '</strong><span>' + esc(c[2]) + '</span></div></li>';
      }).join('') + '</ul><p class="iwt-help iwt-pad">Registros: ' + fmtInt(d.counts.visitors) + ' visitantes · ' + fmtInt(d.counts.sessions) + ' visitas · ' + fmtInt(d.counts.hits) + ' acontecimentos · ' + fmtInt(d.counts.conversions) + ' conversões.</p>';
    }).catch(function (err) { box.innerHTML = errorBox(err); });
  }

  /* =================================================================== início */

  var VIEWS = {
    dashboard: renderDashboard,
    funnels: renderFunnels,
    conversions: renderConversions,
    reports: renderReports,
    costs: renderCosts,
    integrations: renderIntegrations,
    settings: renderSettings,
    help: renderHelp
  };

  api('/admin/bootstrap').then(function (b) {
    BOOT = b;
    initRange();
    (VIEWS[VIEW] || renderDashboard)();
  }).catch(function (err) {
    app.innerHTML = errorBox(err);
  });
})();
